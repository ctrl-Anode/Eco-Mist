<template>
  <footer class="w-full px-4 py-4 relative z-10">
    <div
      class="backdrop-blur-md bg-white/10 border border-white/20 shadow-lg p-6 rounded-2xl max-w-3xl mx-auto"
    >
      <div class="text-center">
        <p class="text-gray-100">© 2025 Eco-Mist. All rights reserved.</p>
        <div class="flex justify-center space-x-6 mt-4">
          <a
            href="#"
            class="text-gray-200 hover:text-green-400 transition-colors text-sm"
            >Privacy Policy</a
          >
          <a
            href="#"
            class="text-gray-200 hover:text-green-400 transition-colors text-sm"
            >Terms of Service</a
          >
          <a
            href="#"
            class="text-gray-200 hover:text-green-400 transition-colors text-sm"
            >Contact Support</a
          >
        </div>
      </div>
    </div>
  </footer>
</template>
