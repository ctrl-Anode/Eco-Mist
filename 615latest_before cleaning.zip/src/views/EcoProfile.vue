<template>
  <div class="min-h-screen bg-gray-50 flex flex-col">
    <!-- Top Navigation Bar -->
    <header class="bg-gradient-to-r from-emerald-700 to-green-600 shadow-lg z-10">
      <div class="container mx-auto px-4 py-3">
        <div class="flex items-center justify-between">
          <!-- Logo and Mobile Menu Button -->
          <div class="flex items-center">
            <button @click="toggleSidebar" class="mr-3 md:hidden text-white">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
            <div class="flex items-center">
              <img src="/eco-mist-logo.png" alt="Eco-Mist Logo" class="h-7 w-7 mr-3 rounded-lg shadow-md bg-white p-1.5" @error="handleLogoError">
              <div>
                <h1 class="text-xl font-bold text-white">Eco-Mist</h1>
                <p class="text-green-100 text-xs hidden sm:block">User Profile</p>
              </div>
            </div>
          </div>

          <!-- User Profile -->
          <div class="flex items-center space-x-3">
            <!-- Feedback Button -->
            <button @click="openFeedbackModal" class="text-white p-2 rounded-full hover:bg-white hover:bg-opacity-10 focus:outline-none hidden md:flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 8h10M7 12h4m1 8l-4-4H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4z" />
              </svg>
            </button>
            <!-- Notification Bell -->
            <div class="relative">
              <button class="text-white p-1 rounded-full hover:bg-white hover:bg-opacity-10 focus:outline-none">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                </svg>
                <span v-if="notificationCount > 0" class="absolute top-0 right-0 bg-red-500 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
                  {{ notificationCount }}
                </span>
              </button>
            </div>

            <!-- User Profile Dropdown -->
            <div class="relative" ref="userMenuRef">
              <button @click="toggleUserMenu" class="flex items-center space-x-2 focus:outline-none">
                <div class="bg-white text-emerald-700 h-8 w-8 rounded-full flex items-center justify-center font-bold text-sm shadow">
                  <img 
                    v-if="profileImageUrl" 
                    :src="profileImageUrl" 
                    :alt="`${username}'s profile picture`" 
                    class="h-full w-full object-cover rounded-full"
                    @error="handleImageError"
                  />
                  <template v-else>{{ getInitials(username) }}</template>
                </div>
                <span class="text-white hidden md:block">{{ username }}</span>
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-white hidden md:block" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="m6 9 6 6 6-6"></path>
                </svg>
              </button>

              <!-- User Menu Dropdown -->
              <div v-if="userMenuOpen" class="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-20">
                <router-link to="/profile-display" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Profile</router-link>
                <router-link to="/settings" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Settings</router-link>
                <a @click="confirmLogout" href="#" class="block px-4 py-2 text-sm text-red-600 hover:bg-gray-100">Logout</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>

    <!-- Main Content Area with Sidebar -->
    <div class="flex flex-1 overflow-hidden">
      <!-- Sidebar Navigation -->
      <aside :class="[
        'bg-white shadow-lg z-20 transition-all duration-300 ease-in-out',
        sidebarOpen ? 'translate-x-0' : '-translate-x-full',
        'md:translate-x-0 fixed md:relative inset-y-0 left-0 w-64 overflow-y-auto'
      ]">
        <!-- Sidebar Header -->
        <div class="p-4 border-b">
          <div class="flex items-center justify-between">
            <h2 class="text-lg font-semibold text-gray-800">Navigation</h2>
            <button @click="toggleSidebar" class="md:hidden text-gray-500 hover:text-gray-700">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>

        <!-- Navigation Sections -->
        <nav class="p-4">
          <div v-for="(section, sectionIndex) in navigationSections" :key="sectionIndex" class="mb-6">
            <h3 class="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">{{ section.title }}</h3>
            <ul class="space-y-1">
              <li v-for="(route, routeIndex) in getFilteredRoutes(section)" :key="routeIndex">
                <router-link 
                  :to="route.path" 
                  :class="[
                    'flex items-center px-3 py-2 text-sm rounded-md',
                    currentRoute === route.path 
                      ? 'bg-emerald-100 text-emerald-700 font-medium' 
                      : 'text-gray-700 hover:bg-gray-100'
                  ]"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" :class="currentRoute === route.path ? 'text-emerald-600' : 'text-gray-500'" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path v-if="getIconForRoute(route) === 'layout-dashboard'" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM4 13a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6zM16 13a1 1 0 011-1h2a1 1 0 011 1v6a1 1 0 01-1 1h-2a1 1 0 01-1-1v-6z" />
                    <path v-else-if="getIconForRoute(route) === 'user'" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    <path v-else-if="getIconForRoute(route) === 'user-cog'" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5.121 17.804A13.937 13.937 0 0112 16c2.5 0 4.847.655 6.879 1.804M15 10a3 3 0 11-6 0 3 3 0 016 0zm6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    <path v-else-if="getIconForRoute(route) === 'cpu'" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z" />
                    <path v-else-if="getIconForRoute(route) === 'bar-chart'" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                    <path v-else-if="getIconForRoute(route) === 'message-circle'" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                    <path v-else-if="getIconForRoute(route) === 'microscope'" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                    <path v-else stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
                  </svg>
                  {{ route.name }}
                </router-link>
              </li>
            </ul>
          </div>
        </nav>

        <!-- System Info -->
        <div class="p-4 border-t">
          <div class="bg-gray-50 rounded-lg p-3">
            <div class="flex items-center justify-between mb-2">
              <span class="text-xs font-medium text-gray-500">System Status</span>
              <span class="bg-green-100 text-green-800 text-xs px-2 py-0.5 rounded-full">Online</span>
            </div>
            <div class="text-xs text-gray-500 flex flex-col space-y-1">
              <div class="flex justify-between">
                <span>Last Login:</span>
                <span class="font-medium text-gray-700">{{ formatDate(lastLogin) }}</span>
              </div>
              <div class="flex justify-between">
                <span>Account Type:</span>
                <span class="font-medium text-gray-700 capitalize">{{ role }}</span>
              </div>
            </div>
          </div>
        </div>
      </aside>

      <!-- Main Content -->
      <main class="flex-1 overflow-y-auto bg-gray-50 p-4 md:p-6">
        <!-- Page Header -->
        <div class="mb-6">
          <h1 class="text-2xl font-bold text-gray-800">My Profile</h1>
          <p class="text-gray-600">View and manage your personal information.</p>
        </div>

        <!-- Profile Content -->
        <div class="bg-white rounded-lg shadow-sm mb-6 overflow-hidden">
          <!-- Profile Header/Banner -->
          <div class="h-48 bg-gradient-to-r from-emerald-700 to-green-600 relative">
            <div class="absolute inset-0 bg-pattern opacity-10"></div>
            <div class="absolute bottom-0 left-0 w-full h-24 bg-gradient-to-t from-white to-transparent"></div>
          </div>
          
          <!-- Loading State -->
          <div v-if="loading" class="p-8 flex flex-col items-center justify-center">
            <div class="spinner mb-4">
              <div></div>
              <div></div>
              <div></div>
              <div></div>
              <div></div>
              <div></div>
            </div>
            <p class="text-gray-700 text-base">Loading your profile information...</p>
          </div>

          <!-- Error State -->
          <div v-else-if="errorMessage" class="p-8 flex flex-col items-center justify-center">
            <div class="bg-red-100 text-red-600 p-3 rounded-full mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <h3 class="text-lg font-semibold text-red-700 mb-2">Error Loading Profile</h3>
            <p class="text-red-600 text-center mb-4">{{ errorMessage }}</p>
            <button 
              @click="fetchUserProfile" 
              class="px-4 py-2 bg-red-100 text-red-700 rounded-md hover:bg-red-200 transition-colors flex items-center"
            >
              <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
              </svg>
              Try Again
            </button>
          </div>

          <!-- Profile Information -->
          <div v-else class="px-6 pt-0 pb-6 relative">
            <div class="flex flex-col md:flex-row md:items-end gap-6 -mt-16 mb-8">
              <!-- Profile Image -->
              <div class="flex-shrink-0">
                <div class="relative">
                  <div class="w-32 h-32 rounded-full overflow-hidden border-4 border-white shadow-lg bg-white">
                    <img 
                      v-if="profileImageUrl" 
                      :src="profileImageUrl" 
                      :alt="`${username}'s profile picture`" 
                      class="w-full h-full object-cover"
                      @error="handleImageError"
                    />
                    <div v-else class="w-full h-full bg-emerald-600 flex items-center justify-center text-white text-3xl font-bold">
                      {{ getInitials(username) }}
                    </div>
                  </div>
                  <div class="absolute -bottom-2 -right-2 px-3 py-1 bg-green-100 text-green-800 border border-green-200 rounded-full text-xs font-medium shadow-sm">
                    {{ status }}
                  </div>
                </div>
              </div>
              
              <!-- Profile Header Info -->
              <div class="flex-1 md:pb-4">
                <h2 class="text-3xl font-bold text-gray-800 mb-1">{{ username || "Not available" }}</h2>
                <div class="flex flex-wrap items-center gap-x-4 gap-y-2 text-gray-600">
                  <div class="flex items-center gap-1">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-emerald-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                    </svg>
                    <span>{{ email || "Email not provided" }}</span>
                  </div>
                  <div v-if="cellphone" class="flex items-center gap-1">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-emerald-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                    </svg>
                    <span>{{ cellphone }}</span>
                  </div>
                  <div class="flex items-center gap-1">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-emerald-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    </svg>
                    <span class="capitalize">{{ role }}</span>
                  </div>
                </div>
              </div>
              
              <!-- Action Buttons -->
              <div class="flex flex-wrap gap-3 mt-2 md:mt-0">
                <router-link 
                  to="/edit-profile" 
                  class="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700 transition-colors shadow-sm hover:shadow-md"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                  </svg>
                  Edit Profile
                </router-link>
                <router-link 
                  to="/reset-password" 
                  class="inline-flex items-center gap-2 px-4 py-2 bg-white text-emerald-700 border border-emerald-200 rounded-md hover:bg-emerald-50 transition-colors shadow-sm hover:shadow"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" />
                  </svg>
                  Change Password
                </router-link>
              </div>
            </div>

            <!-- Profile Sections -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <!-- Personal Information -->
              <section class="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
                <div class="bg-emerald-50 border-b border-emerald-100 px-5 py-3">
                  <h3 class="text-lg font-semibold text-gray-800 flex items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-emerald-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    </svg>
                    Personal Information
                  </h3>
                </div>
                <div class="p-5">
                  <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div class="bg-gray-50 rounded-md p-3">
                      <p class="text-sm text-gray-500 mb-1">Full Name</p>
                      <p class="font-medium text-gray-900">{{ completeName || "Not provided" }}</p>
                    </div>
                    <div class="bg-gray-50 rounded-md p-3">
                      <p class="text-sm text-gray-500 mb-1">Age</p>
                      <p class="font-medium text-gray-900">{{ age || "Not provided" }}</p>
                    </div>
                    <div class="bg-gray-50 rounded-md p-3">
                      <p class="text-sm text-gray-500 mb-1">Birthday</p>
                      <p class="font-medium text-gray-900">{{ birthday || "Not provided" }}</p>
                    </div>
                    <div class="bg-gray-50 rounded-md p-3">
                      <p class="text-sm text-gray-500 mb-1">Gender</p>
                      <p class="font-medium text-gray-900 capitalize">{{ gender || "Not provided" }}</p>
                    </div>
                  </div>
                </div>
              </section>

              <!-- Contact Information -->
              <section class="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
                <div class="bg-emerald-50 border-b border-emerald-100 px-5 py-3">
                  <h3 class="text-lg font-semibold text-gray-800 flex items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-emerald-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                    </svg>
                    Contact Information
                  </h3>
                </div>
                <div class="p-5">
                  <div class="space-y-5">
                    <div class="bg-gray-50 rounded-md p-3">
                      <p class="text-sm text-gray-500 mb-1">Email Address</p>
                      <div class="flex items-center gap-2">
                        <p class="font-medium text-gray-900">{{ email || "Not provided" }}</p>
                        <a 
                          v-if="email" 
                          :href="`mailto:${email}`" 
                          class="text-xs text-emerald-600 hover:text-emerald-700 transition-colors flex items-center"
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                          </svg>
                          Email
                        </a>
                      </div>
                    </div>
                    <div class="bg-gray-50 rounded-md p-3">
                      <p class="text-sm text-gray-500 mb-1">Phone Number</p>
                      <div class="flex items-center gap-2">
                        <p class="font-medium text-gray-900">{{ cellphone || "Not provided" }}</p>
                        <a 
                          v-if="cellphone" 
                          :href="`tel:${cellphone}`" 
                          class="text-xs text-emerald-600 hover:text-emerald-700 transition-colors flex items-center"
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                          </svg>
                          Call
                        </a>
                      </div>
                    </div>
                    <div class="bg-gray-50 rounded-md p-3">
                      <p class="text-sm text-gray-500 mb-1">Address</p>
                      <p class="font-medium text-gray-900">{{ address || "Not provided" }}</p>
                    </div>
                  </div>
                </div>
              </section>
            </div>
          </div>
        </div>
        
        <!-- Account Activity -->
        <div class="bg-white rounded-lg shadow-sm p-6">
          <h2 class="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-emerald-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            Recent Account Activity
          </h2>
          <div class="overflow-hidden rounded-lg border border-gray-200">
            <table class="min-w-full divide-y divide-gray-200">
              <thead class="bg-gray-50">
                <tr>
                  <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Activity</th>
                  <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Location</th>
                  <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date & Time</th>
                  <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                </tr>
              </thead>
              <tbody class="bg-white divide-y divide-gray-200">
                <tr v-for="(activity, index) in recentActivities" :key="index">
                  <td class="px-6 py-4 whitespace-nowrap">
                    <div class="flex items-center">
                      <div :class="[
                        'flex-shrink-0 h-8 w-8 rounded-full flex items-center justify-center',
                        activity.type === 'login' ? 'bg-blue-100' : 
                        activity.type === 'password_change' ? 'bg-yellow-100' : 
                        activity.type === 'profile_update' ? 'bg-green-100' : 'bg-gray-100'
                      ]">
                        <svg 
                          xmlns="http://www.w3.org/2000/svg" 
                          class="h-4 w-4" 
                          :class="[
                            activity.type === 'login' ? 'text-blue-600' : 
                            activity.type === 'password_change' ? 'text-yellow-600' : 
                            activity.type === 'profile_update' ? 'text-green-600' : 'text-gray-600'
                          ]"
                          fill="none" 
                          viewBox="0 0 24 24" 
                          stroke="currentColor"
                        >
                          <path 
                            v-if="activity.type === 'login'" 
                            stroke-linecap="round" 
                            stroke-linejoin="round" 
                            stroke-width="2" 
                            d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" 
                          />
                          <path 
                            v-else-if="activity.type === 'password_change'" 
                            stroke-linecap="round" 
                            stroke-linejoin="round" 
                            stroke-width="2" 
                            d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" 
                          />
                          <path 
                            v-else-if="activity.type === 'profile_update'" 
                            stroke-linecap="round" 
                            stroke-linejoin="round" 
                            stroke-width="2" 
                            d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" 
                          />
                          <path 
                            v-else 
                            stroke-linecap="round" 
                            stroke-linejoin="round" 
                            stroke-width="2" 
                            d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" 
                          />
                        </svg>
                      </div>
                      <div class="ml-4">
                        <div class="text-sm font-medium text-gray-900">{{ activity.title }}</div>
                        <div class="text-sm text-gray-500">{{ activity.device || 'Unknown device' }}</div>
                      </div>
                    </div>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap">
                    <div class="text-sm text-gray-900">{{ activity.location }}</div>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap">
                    <div class="text-sm text-gray-900">{{ formatDate(activity.timestamp, true) }}</div>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap">
                    <span :class="[
                      'px-2 inline-flex text-xs leading-5 font-semibold rounded-full',
                      activity.success ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                    ]">
                      {{ activity.success ? 'Successful' : 'Failed' }}
                    </span>
                  </td>
                </tr>
                <tr v-if="recentActivities.length === 0">
                  <td colspan="4" class="px-6 py-8 text-center text-gray-500">
                    No recent activity to display
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>

    <!-- Feedback Modal with Blurred Background -->
    <div v-if="showFeedbackModal" class="fixed inset-0 z-50 flex items-center justify-center">
      <!-- Blurred backdrop -->
      <div class="absolute inset-0 backdrop-blur-sm" @click="closeFeedbackModal"></div>
      
      <!-- Modal content -->
      <div class="bg-white rounded-lg p-6 max-w-md mx-auto w-full relative z-10 shadow-xl">
        <h3 class="text-lg font-medium text-gray-900 mb-4">Give Feedback</h3>
        <p class="text-gray-500 mb-4">We value your feedback! Please let us know how we can improve your experience.</p>
        <div class="space-y-4">
          <div>
            <label for="feedback-type" class="block text-sm font-medium text-gray-700 mb-1">Feedback Type</label>
            <select 
              id="feedback-type" 
              v-model="feedbackType"
              class="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm"
            >
              <option value="suggestion">Suggestion</option>
              <option value="bug">Bug Report</option>
              <option value="question">Question</option>
              <option value="other">Other</option>
            </select>
          </div>
          <div>
            <label for="feedback-message" class="block text-sm font-medium text-gray-700 mb-1">Your Feedback</label>
            <textarea 
              id="feedback-message" 
              v-model="feedbackMessage" 
              rows="4"
              class="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm"
              placeholder="Please describe your feedback in detail..."
            ></textarea>
          </div>
        </div>
        <div class="flex justify-end gap-2 mt-6">
          <button @click="closeFeedbackModal" class="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300">
            Cancel
          </button>
          <button 
            @click="submitFeedback" 
            class="px-4 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700 relative"
            :disabled="submittingFeedback"
          >
            <span v-if="!submittingFeedback">Submit Feedback</span>
            <div v-else class="flex items-center justify-center">
              <div class="spinner spinner-sm">
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
              </div>
              <span class="ml-2">Submitting...</span>
            </div>
          </button>
        </div>
      </div>
    </div>

    <!-- Logout Confirmation Modal -->
    <div v-if="showLogoutModal" class="fixed inset-0 z-50 flex items-center justify-center">
      <!-- Blurred backdrop -->
      <div class="absolute inset-0 backdrop-blur-sm bg-black bg-opacity-50" @click="showLogoutModal = false"></div>
      
      <!-- Modal content -->
      <div class="bg-white rounded-lg p-6 max-w-sm mx-auto w-full relative z-10 shadow-xl">
        <h3 class="text-lg font-semibold text-gray-900 mb-4">Confirm Logout</h3>
        <p class="text-gray-600 mb-6">Are you sure you want to log out of your account?</p>
        <div class="flex justify-end gap-3">
          <button 
            @click="showLogoutModal = false" 
            class="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 transition-colors"
          >
            Cancel
          </button>
          <button 
            @click="logout" 
            class="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors flex items-center justify-center"
            :disabled="loggingOut"
          >
            <span v-if="!loggingOut">Logout</span>
            <div v-else class="flex items-center">
              <div class="spinner spinner-sm mr-2">
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
              </div>
              <span>Logging out...</span>
            </div>
          </button>
        </div>
      </div>
    </div>

    <!-- Toast Notification -->
    <div 
      v-if="toast.show" 
      class="fixed bottom-4 right-4 px-4 py-3 rounded-lg shadow-lg z-50 flex items-center"
      :class="{
        'bg-green-100 text-green-800 border-l-4 border-green-500': toast.type === 'success',
        'bg-red-100 text-red-800 border-l-4 border-red-500': toast.type === 'error'
      }"
    >
      <svg 
        v-if="toast.type === 'success'" 
        class="h-5 w-5 mr-2" 
        xmlns="http://www.w3.org/2000/svg" 
        viewBox="0 0 20 20" 
        fill="currentColor"
      >
        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
      </svg>
      <svg 
        v-if="toast.type === 'error'" 
        class="h-5 w-5 mr-2" 
        xmlns="http://www.w3.org/2000/svg" 
        viewBox="0 0 20 20" 
        fill="currentColor"
      >
        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd" />
      </svg>
      <span>{{ toast.message }}</span>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, watch, onMounted, onBeforeUnmount } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { getAuth, signOut, onAuthStateChanged } from "firebase/auth";
import { doc, getDoc } from "firebase/firestore";
import { db } from "../../firebase";

// Router
const router = useRouter();
const route = useRoute();
const currentRoute = computed(() => route.path);

// State variables
const username = ref("User");
const email = ref("");
const completeName = ref("");
const age = ref("");
const birthday = ref("");
const cellphone = ref("");
const gender = ref("");
const address = ref("");
const profileImageUrl = ref("");
const role = ref("user");
const status = ref("active");
const lastLogin = ref(new Date());
const sidebarOpen = ref(true);
const userMenuOpen = ref(false);
const notificationCount = ref(2);
const isMobile = ref(false);
const userMenuRef = ref(null);
const showLogoutModal = ref(false);
const loggingOut = ref(false);
const loading = ref(true);
const errorMessage = ref("");
const toast = ref({ show: false, message: '', type: 'success' });

// Sample recent activities
const recentActivities = ref([
  {
    type: 'login',
    title: 'Account Login',
    device: 'Chrome on Windows',
    location: 'Los Angeles, US',
    timestamp: new Date(Date.now() - 1000 * 60 * 30), // 30 minutes ago
    success: true
  },
  {
    type: 'password_change',
    title: 'Password Changed',
    device: 'Mobile App on Android',
    location: 'Los Angeles, US',
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2), // 2 days ago
    success: true
  },
  {
    type: 'profile_update',
    title: 'Profile Updated',
    device: 'Firefox on macOS',
    location: 'Los Angeles, US',
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 5), // 5 days ago
    success: true
  }
]);

// Navigation sections
const navigationSections = computed(() => {
  return [
    {
      title: 'GENERAL',
      routes: routes.filter(r => 
        r.path === '/dashboard' || 
        r.path === '/profile-display' ||
        r.path === '/messenger'
      )
    },
    {
      title: 'USER MANAGEMENT',
      routes: routes.filter(r => 
        r.path === '/edit-profile' || 
        r.path === '/reset-password'
      )
    },
    {
      title: 'DATA & TOOLS',
      routes: routes.filter(r => 
        r.path === '/financial-management' || 
        r.path === '/sensor_data' || 
        r.path === '/model'
      )
    },
    {
      title: 'ADMIN CONTROLS',
      routes: routes.filter(r => 
        r.path === '/admin-dashboard' || 
        r.path === '/admin-management'
      )
    }
  ];
});

// Routes configuration
const routes = [
  { path: '/dashboard', name: 'Dashboard', component: 'UserDashboard', meta: { requiresAuth: true } },
  { path: '/profile-display', name: 'Profile', component: 'UserProfileDisplay', meta: { requiresAuth: true, role: 'user' } },
  { path: '/messenger', name: 'Messenger', component: 'MessengerChat', meta: { requiresAuth: true } },
  { path: '/edit-profile', name: 'Edit Profile', component: 'EditUserProfile', meta: { requiresAuth: true, role: 'user' } },
  { path: '/reset-password', name: 'Reset Password', component: 'ResetPassword', badge: null },
  { path: '/admin-dashboard', name: 'Admin Dashboard', component: 'AdminDashboard', meta: { requiresAuth: true, role: 'admin' } },
  { path: '/admin-management', name: 'Admin Management', component: 'AdminManagement', meta: { requiresAuth: true, role: "admin" } },
  { path: '/financial-management', name: 'Financial Management', component: 'FinancialManagement', meta: { requiresAuth: true, role: 'user' } },
  { path: '/sensor_data', name: 'Sensor Data', component: 'SensorData', meta: { requiresAuth: true, role: 'user' } },
  { path: '/model', name: 'Crop Analysis', component: 'CropDiseaseDetector', meta: { requiresAuth: true, role: 'user' } },
  { path: '/settings', name: 'Settings', component: 'Settings', meta: { requiresAuth: true } },
];

// Methods
const getInitials = (name) => {
  if (!name) return "U";
  return name.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2);
};

const formatDate = (date, includeTime = false) => {
  if (!date) return '';
  
  const now = new Date();
  const diff = now - new Date(date);
  
  if (!includeTime) {
    // Less than a minute
    if (diff < 60000) {
      return 'Just now';
    }
    
    // Less than an hour
    if (diff < 3600000) {
      return `${Math.floor(diff / 60000)}m ago`;
    }
    
    // Less than a day
    if (diff < 86400000) {
      return `${Math.floor(diff / 3600000)}h ago`;
    }
    
    // Less than a week
    if (diff < 604800000) {
      return `${Math.floor(diff / 86400000)}d ago`;
    }
  }
  
  // Format as date with time if includeTime is true
  const options = {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    ...(includeTime && { hour: '2-digit', minute: '2-digit' })
  };
  
  return new Date(date).toLocaleDateString('en-US', options);
};

const toggleUserMenu = () => {
  userMenuOpen.value = !userMenuOpen.value;
};

const handleClickOutside = (event) => {
  if (userMenuRef.value && !userMenuRef.value.contains(event.target)) {
    userMenuOpen.value = false;
  }
};

const checkIfMobile = () => {
  isMobile.value = window.innerWidth < 768;
  if (isMobile.value) {
    sidebarOpen.value = false;
  } else {
    // Get saved sidebar state or default to open on desktop
    const savedState = localStorage.getItem('sidebarOpen');
    sidebarOpen.value = savedState !== null ? savedState === 'true' : true;
  }
};

const toggleSidebar = () => {
  sidebarOpen.value = !sidebarOpen.value;
  localStorage.setItem('sidebarOpen', sidebarOpen.value.toString());
};

const getFilteredRoutes = (section) => {
  return section.routes.filter(route => shouldShowRoute(route));
};

const shouldShowRoute = (route) => {
  if (route.meta?.requiresAuth) {
    if (route.meta.role && route.meta.role !== role.value.toLowerCase()) {
      return false;
    }
  }
  return true;
};

const getIconForRoute = (route) => {
  const iconMap = {
    '/dashboard': 'layout-dashboard',
    '/profile-display': 'user',
    '/edit-profile': 'user-cog',
    '/reset-password': 'key',
    '/admin-dashboard': 'shield',
    '/admin-management': 'users',
    '/financial-management': 'bar-chart',
    '/messenger': 'message-circle',
    '/sensor_data': 'cpu',
    '/model': 'microscope',
    '/settings': 'settings'
  };

  return iconMap[route.path] || 'link';
};

const handleImageError = (e) => {
  e.target.style.display = 'none';
  e.target.parentNode.classList.add('bg-emerald-600');
  const initials = document.createElement('div');
  initials.className = 'flex items-center justify-center h-full w-full text-white text-3xl font-bold';
  initials.textContent = getInitials(username.value);
  e.target.parentNode.appendChild(initials);
};

const handleLogoError = (e) => {
  e.target.src = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="%2316a34a" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12a10 10 0 1 1 20 0 10 10 0 0 1-20 0Z"/><path d="M2 12h20"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>';
};

const showToast = (message, type = 'success') => {
  toast.value = { show: true, message, type };
  setTimeout(() => {
    toast.value.show = false;
  }, 3000);
};

const fetchUserProfile = async () => {
  loading.value = true;
  errorMessage.value = "";

  try {
    const auth = getAuth();
    const user = auth.currentUser;
    
    if (!user) {
      throw new Error("Please log in to view your profile");
    }
    
    // Fetch user data from Firestore
    const userRef = doc(db, "users", user.uid);
    const userSnap = await getDoc(userRef);
    
    if (userSnap.exists()) {
      const userData = userSnap.data();
      username.value = userData.username || user.displayName || "User";
      email.value = userData.email || user.email || "";
      completeName.value = userData.completeName || "";
      age.value = userData.age || "";
      birthday.value = userData.birthday || "";
      cellphone.value = userData.cellphone || "";
      gender.value = userData.gender || "";
      address.value = userData.address || "";
      profileImageUrl.value = userData.profileImageUrl || user.photoURL || "";
      role.value = userData.role || "user";
      status.value = userData.status || "active";
      
      // Update last login date
      lastLogin.value = user.metadata.lastSignInTime ? new Date(user.metadata.lastSignInTime) : new Date();
    } else {
      throw new Error("User profile not found. Please complete your profile setup.");
    }
  } catch (error) {
    console.error("Error fetching user profile:", error);
    errorMessage.value = error.message || "Failed to load profile information.";
  } finally {
    loading.value = false;
  }
};

const confirmLogout = () => {
  showLogoutModal.value = true;
};

const logout = async () => {
  loggingOut.value = true;
  try {
    await signOut(getAuth());
    
    // Simulate a delay to show the spinner
    setTimeout(() => {
      router.push('/auth');
      loggingOut.value = false;
      showLogoutModal.value = false;
    }, 1000);
  } catch (error) {
    console.error("Error logging out:", error);
    loggingOut.value = false;
    showToast("Failed to log out. Please try again.", "error");
  }
};

// Feedback state variables
const showFeedbackModal = ref(false);
const feedbackType = ref('suggestion');
const feedbackMessage = ref('');
const submittingFeedback = ref(false);

// Methods for feedback
const openFeedbackModal = () => {
  showFeedbackModal.value = true;
};

const closeFeedbackModal = () => {
  showFeedbackModal.value = false;
  feedbackMessage.value = '';
  feedbackType.value = 'suggestion';
};

const submitFeedback = async () => {
  if (!feedbackMessage.value.trim()) {
    showToast('Please enter your feedback message', 'error');
    return;
  }

  submittingFeedback.value = true;

  try {
    // Simulate feedback submission
    setTimeout(() => {
      showToast('Thank you for your feedback!', 'success');
      closeFeedbackModal();
      submittingFeedback.value = false;
    }, 1000);
  } catch (error) {
    console.error("Error submitting feedback:", error);
    showToast('Failed to submit feedback. Please try again.', 'error');
    submittingFeedback.value = false;
  }
};

// Watch for route changes to close sidebar on mobile
watch(currentRoute, () => {
  if (isMobile.value) {
    sidebarOpen.value = false;
  }
  // Close user menu when route changes
  userMenuOpen.value = false;
});

// Handle window resize
const handleResize = () => {
  checkIfMobile();
};

// Initialize component
onMounted(() => {
  // Check if mobile on initial load
  checkIfMobile();
  
  // Add resize event listener
  window.addEventListener('resize', handleResize);
  
  // Add click outside listener for user menu
  document.addEventListener('click', handleClickOutside);
  
  // Fetch the logged-in user's profile
  fetchUserProfile();
  
  // Listen for auth state changes
  const unsubscribeAuth = onAuthStateChanged(getAuth(), (user) => {
    if (!user) {
      router.push('/auth');
    }
  });
  
  // Cleanup on component unmount
  onBeforeUnmount(() => {
    window.removeEventListener('resize', handleResize);
    document.removeEventListener('click', handleClickOutside);
    unsubscribeAuth();
  });
});

const isMobileDevice = ref(false);

onMounted(() => {
  const checkIsMobile = () => {
    isMobileDevice.value = window.innerWidth <= 768;
  };

  checkIsMobile();
  window.addEventListener('resize', checkIsMobile);

  onBeforeUnmount(() => {
    window.removeEventListener('resize', checkIsMobile);
  });
});
</script>

<style>
/* Background Pattern */
.bg-pattern {
  background-image: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.2'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
}

/* 3D Cube Spinner */
.spinner {
  width: 44px;
  height: 44px;
  animation: spinner-rotation 2s infinite ease;
  transform-style: preserve-3d;
}

.spinner > div {
  background-color: rgba(16, 185, 129, 0.2);
  height: 100%;
  position: absolute;
  width: 100%;
  border: 2px solid #10b981;
}

.spinner div:nth-of-type(1) {
  transform: translateZ(-22px) rotateY(180deg);
}

.spinner div:nth-of-type(2) {
  transform: rotateY(-270deg) translateX(50%);
  transform-origin: top right;
}

.spinner div:nth-of-type(3) {
  transform: rotateY(270deg) translateX(-50%);
  transform-origin: center left;
}

.spinner div:nth-of-type(4) {
  transform: rotateX(90deg) translateY(-50%);
  transform-origin: top center;
}

.spinner div:nth-of-type(5) {
  transform: rotateX(-90deg) translateY(50%);
  transform-origin: bottom center;
}

.spinner div:nth-of-type(6) {
  transform: translateZ(22px);
}

/* Smaller spinner for buttons */
.spinner-sm {
  width: 24px;
  height: 24px;
}

@keyframes spinner-rotation {
  0% {
    transform: rotate(45deg) rotateX(-25deg) rotateY(25deg);
  }

  50% {
    transform: rotate(45deg) rotateX(-385deg) rotateY(25deg);
  }

  100% {
    transform: rotate(45deg) rotateX(-385deg) rotateY(385deg);
  }
}

/* Focus styles for accessibility */
button:focus-visible,
a:focus-visible {
  outline: 2px solid #10b981;
  outline-offset: 2px;
}

/* Responsive Styles */
@media (prefers-reduced-motion: reduce) {
  .spinner, .spinner-sm {
    animation-duration: 0.001ms !important;
    animation-iteration-count: 1 !important;
  }
  
  .transition-all, .transition-colors {
    transition-duration: 0.001ms !important;
  }
}
</style>