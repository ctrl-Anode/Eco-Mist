<template>
  <div class="min-h-screen relative overflow-x-hidden">
    <!-- Background with improved gradient -->
    <div class="fixed inset-0 bg-gradient-to-br from-green-900 to-green-800 z-0">
      <div class="absolute inset-0 bg-[url('/farm-pattern.png')] opacity-15 mix-blend-overlay"></div>
      <div class="absolute w-[800px] h-[800px] rounded-full filter blur-[80px] opacity-20 bg-gradient-to-br from-green-400 to-green-600 -top-[300px] -left-[300px]"></div>
      <div class="absolute w-[700px] h-[700px] rounded-full filter blur-[80px] opacity-20 bg-gradient-to-br from-green-600 to-green-700 -bottom-[250px] -right-[250px]"></div>
    </div>

    <!-- Navigation - Improved with better spacing and transitions -->
    <nav class="sticky top-0 z-50 w-full max-w-full px-3 sm:px-4 md:px-6 lg:px-8 my-3 sm:my-4 mx-auto bg-white/95 backdrop-blur-md rounded-xl border border-green-100 shadow-xl" role="navigation" aria-label="Primary navigation" tabindex="0"> 
      <div class="flex justify-between items-center p-2 sm:p-3 md:p-4"> 
        <div class="flex items-center gap-2 sm:gap-3"> 
          <img src="/eco-mist-logo.png" alt="Eco-Mist Logo" class="w-8 h-8 sm:w-10 sm:h-10 object-contain" loading="lazy" /> 
          <span class="text-green-800 text-lg sm:text-xl md:text-2xl font-bold">Eco-Mist</span> 
        </div> 
        <div class="hidden md:flex items-center gap-4 lg:gap-8" role="menubar" aria-label="Main menu"> 
          <a href="#features" class="text-green-800 hover:text-green-600 transition-colors font-medium text-sm lg:text-base relative after:absolute after:bottom-0 after:left-0 after:h-0.5 after:w-0 after:bg-green-600 after:transition-all hover:after:w-full" @click.prevent="scrollToSection('features')" role="menuitem" tabindex="0">Features</a> 
          <a href="#how-it-works" class="text-green-800 hover:text-green-600 transition-colors font-medium text-sm lg:text-base relative after:absolute after:bottom-0 after:left-0 after:h-0.5 after:w-0 after:bg-green-600 after:transition-all hover:after:w-full" @click.prevent="scrollToSection('how-it-works')" role="menuitem" tabindex="0">How It Works</a> 
          <a href="#benefits" class="text-green-800 hover:text-green-600 transition-colors font-medium text-sm lg:text-base relative after:absolute after:bottom-0 after:left-0 after:h-0.5 after:w-0 after:bg-green-600 after:transition-all hover:after:w-full" @click.prevent="scrollToSection('benefits')" role="menuitem" tabindex="0">Benefits</a> 
          <a href="#contact" class="text-green-800 hover:text-green-600 transition-colors font-medium text-sm lg:text-base relative after:absolute after:bottom-0 after:left-0 after:h-0.5 after:w-0 after:bg-green-600 after:transition-all hover:after:w-full" @click.prevent="scrollToSection('contact')" role="menuitem" tabindex="0">Contact</a> 
          <router-link to="/auth" class="bg-gradient-to-r from-green-600 to-green-500 text-white px-4 sm:px-6 py-2 sm:py-2.5 rounded-lg border border-green-500/20 hover:-translate-y-0.5 transition-all shadow-lg shadow-green-600/20 active:scale-95 touch-manipulation font-medium text-sm lg:text-base whitespace-nowrap" role="menuitem" tabindex="0">Login</router-link> 
        </div> 
        <button class="md:hidden w-8 h-8 sm:w-10 sm:h-10 flex items-center justify-center text-green-800 bg-green-100 rounded-lg active:bg-green-200 touch-manipulation" @click="toggleMobileMenu" aria-label="Toggle menu" aria-expanded="false" aria-controls="mobile-menu" tabindex="0"> 
          <svg v-if="!mobileMenuOpen" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-5 h-5"><line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/></svg>
          <svg v-else xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-5 h-5"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
        </button> 
      </div> 
      <transition 
        name="mobile-menu"
        enter-active-class="transition duration-300 ease-out"
        enter-from-class="transform -translate-y-8 opacity-0"
        enter-to-class="transform translate-y-0 opacity-100"
        leave-active-class="transition duration-200 ease-in"
        leave-from-class="transform translate-y-0 opacity-100"
        leave-to-class="transform -translate-y-8 opacity-0"
      >
        <div v-if="mobileMenuOpen" id="mobile-menu" class="md:hidden border-t border-green-100 p-4" role="menu" aria-label="Mobile menu">
          <div class="flex flex-col space-y-4"> 
            <a href="#features" @click="closeMobileMenu" class="text-green-800 py-2 hover:text-green-600 transition-colors font-medium active:bg-green-50 rounded-lg px-3 touch-manipulation" role="menuitem" tabindex="0">Features</a> 
            <a href="#how-it-works" @click="closeMobileMenu" class="text-green-800 py-2 hover:text-green-600 transition-colors font-medium active:bg-green-50 rounded-lg px-3 touch-manipulation" role="menuitem" tabindex="0">How It Works</a> 
            <a href="#benefits" @click="closeMobileMenu" class="text-green-800 py-2 hover:text-green-600 transition-colors font-medium active:bg-green-50 rounded-lg px-3 touch-manipulation" role="menuitem" tabindex="0">Benefits</a> 
            <a href="#contact" @click="closeMobileMenu" class="text-green-800 py-2 hover:text-green-600 transition-colors font-medium active:bg-green-50 rounded-lg px-3 touch-manipulation" role="menuitem" tabindex="0">Contact</a> 
            <router-link to="/auth" @click="closeMobileMenu" class="bg-gradient-to-r from-green-600 to-green-500 text-white px-4 py-3 rounded-lg border border-green-500/20 flex items-center justify-center active:scale-95 touch-manipulation font-medium" role="menuitem" tabindex="0">Login</router-link> 
          </div>
        </div>
      </transition>
    </nav>

    <!-- Hero Section - Improved layout and visual appeal -->
    <section class="px-4 sm:px-6 py-12 sm:py-16 md:py-20 relative z-10">
      <div class="max-w-7xl mx-auto bg-white/95 backdrop-blur-sm rounded-2xl sm:rounded-3xl border border-green-100 shadow-xl overflow-hidden relative">
        <div class="absolute inset-0 bg-gradient-to-r from-transparent via-green-50/30 to-transparent animate-shine"></div>
        <div class="flex flex-col md:flex-row items-center justify-between p-6 sm:p-10 md:p-12 gap-8 md:gap-12">
          <!-- Left Content -->
          <div class="w-full md:w-1/2 text-center md:text-left">
            <h1 class="text-4xl sm:text-5xl md:text-6xl font-bold text-green-800 leading-tight mb-4">
              <span class="bg-clip-text text-transparent bg-gradient-to-r from-green-800 to-green-600">IoT-Driven</span> Aeroponics Farming
            </h1>
            <p class="text-green-600 text-lg sm:text-xl font-medium mb-6">
              Web-based System for Automated Management and Monitoring of Aeroponics Farming
            </p>
            <p class="text-gray-700 mb-8 max-w-xl mx-auto md:mx-0 text-lg">
              Revolutionize your farming with our cutting-edge IoT solution that optimizes growth, 
              reduces resource consumption, and delivers real-time insights for maximum yield.
            </p>
            <div class="flex flex-col sm:flex-row gap-6 justify-center md:justify-start">
              <router-link to="/auth" class="bg-gradient-to-r from-green-700 to-green-600 text-white font-semibold px-8 py-4 rounded-xl hover:-translate-y-1 transition-transform shadow-lg shadow-green-600/20 active:scale-95 touch-manipulation text-lg">
                Get Started
              </router-link>
              <a href="#how-it-works" @click.prevent="scrollToSection('how-it-works')" class="px-8 py-4 rounded-xl border-2 border-green-600 text-green-700 hover:bg-green-50 transition-all font-semibold flex items-center justify-center gap-2 text-lg">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-5 h-5"><circle cx="12" cy="12" r="10"/><polygon points="10 8 16 12 10 16 10 8"/></svg>
                Watch Demo
              </a>
            </div>
          </div>

          <!-- Right Content - Improved visual -->
          <div class="w-full md:w-1/2 flex justify-center">
            <div class="relative">
              <div class="absolute inset-0 bg-gradient-to-br from-green-400/20 to-green-600/20 rounded-full blur-3xl"></div>
              <div class="bg-white p-6 rounded-2xl shadow-2xl relative">
                <img src="/eco-mist-logo.png" alt="Eco-Mist System" class="w-64 h-64 sm:w-72 sm:h-72 md:w-80 md:h-80 filter drop-shadow-[0_0_30px_rgba(22,163,74,0.5)] animate-float-logo" loading="lazy" />
              </div>
            </div>
          </div>
        </div>
        
        <!-- Social sharing - Improved with modern icons -->
        <div class="flex justify-center py-6 space-x-6 border-t border-green-100/50">
          <a href="https://www.facebook.com/sharer/sharer.php?u=https://yourdomain.com" target="_blank" rel="noopener noreferrer" class="text-gray-500 hover:text-blue-600 transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" class="w-6 h-6">
              <path d="M22.675 0H1.325C.593 0 0 .593 0 1.325v21.351C0 23.407.593 24 1.325 24h11.495v-9.294H9.691v-3.622h3.129V8.413c0-3.1 1.893-4.788 4.659-4.788 1.325 0 2.464.099 2.795.143v3.24h-1.918c-1.504 0-1.796.715-1.796 1.763v2.31h3.587l-.467 3.622h-3.12V24h6.116c.73 0 1.324-.593 1.324-1.324V1.325C24 .593 23.407 0 22.675 0z"/>
            </svg>
          </a>
          <a href="https://twitter.com/intent/tweet?url=https://yourdomain.com&text=Check%20out%20Eco-Mist%20-%20IoT-Driven%20Aeroponics%20Farming%20System!" target="_blank" rel="noopener noreferrer" class="text-gray-500 hover:text-blue-400 transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" class="w-6 h-6">
              <path d="M23.954 4.569c-.885.392-1.83.656-2.825.775 1.014-.611 1.794-1.574 2.163-2.723-.949.564-2.005.974-3.127 1.195-.896-.959-2.173-1.559-3.591-1.559-2.717 0-4.92 2.203-4.92 4.917 0 .39.045.765.127 1.124C7.691 8.094 4.066 6.13 1.64 3.161c-.427.722-.666 1.561-.666 2.475 0 1.71.87 3.213 2.188 4.096-.807-.026-1.566-.248-2.228-.616v.061c0 2.385 1.693 4.374 3.946 4.827-.413.111-.849.171-1.296.171-.314 0-.615-.03-.916-.086.631 1.953 2.445 3.377 4.604 3.417-1.68 1.319-3.809 2.105-6.102 2.105-.39 0-.779-.023-1.17-.067 2.189 1.394 4.768 2.209 7.557 2.209 9.054 0 14.002-7.496 14.002-13.986 0-.21 0-.423-.015-.634.961-.695 1.8-1.562 2.46-2.549z"/>
            </svg>
          </a>
          <a href="https://www.linkedin.com/shareArticle?mini=true&url=https://yourdomain.com&title=Eco-Mist%20-%20IoT-Driven%20Aeroponics%20Farming%20System&summary=Revolutionize%20your%20farming%20with%20our%20cutting-edge%20IoT%20solution!" target="_blank" rel="noopener noreferrer" class="text-gray-500 hover:text-blue-700 transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" class="w-6 h-6">
              <path d="M22.23 0H1.77C.792 0 0 .774 0 1.729v20.542C0 23.226.792 24 1.77 24h20.46C23.208 24 24 23.226 24 22.271V1.729C24 .774 23.208 0 22.23 0zM7.12 20.452H3.56V9h3.56v11.452zM5.34 7.452c-1.14 0-2.06-.92-2.06-2.06 0-1.14.92-2.06 2.06-2.06 1.14 0 2.06.92 2.06 2.06 0 1.14-.92 2.06-2.06 2.06zM20.452 20.452h-3.56v-5.6c0-1.34-.03-3.06-1.86-3.06-1.86 0-2.15 1.45-2.15 2.95v5.71h-3.56V9h3.42v1.56h.05c.48-.91 1.65-1.87 3.4-1.87 3.63 0 4.3 2.39 4.3 5.5v6.26z"/>
            </svg>
          </a>
        </div>
      </div>
    </section>

    <!-- Stats Section - Improved with better cards and animations -->
    <section class="px-4 sm:px-6 py-12 sm:py-16 relative z-10">
      <div class="max-w-7xl mx-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <div class="bg-white/95 backdrop-blur-sm rounded-2xl border border-green-100 shadow-xl p-8 text-center transition-all hover:-translate-y-2 duration-300 group">
          <div class="text-green-600 mb-6 flex justify-center">
            <div class="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center group-hover:bg-green-200 transition-colors">
              <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-8 h-8"><path d="M22 13V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v12c0 1.1.9 2 2 2h8"/><path d="m22 20-3-3-3 3"/><path d="M19 17v9"/><path d="M9 10l1 1 3-3"/></svg>
            </div>
          </div>
          <div class="text-green-800 text-4xl sm:text-5xl font-bold mb-2">95%</div>
          <div class="text-gray-600 font-medium">Water Savings</div>
        </div>
        <div class="bg-white/95 backdrop-blur-sm rounded-2xl border border-green-100 shadow-xl p-8 text-center transition-all hover:-translate-y-2 duration-300 group">
          <div class="text-green-600 mb-6 flex justify-center">
            <div class="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center group-hover:bg-green-200 transition-colors">
              <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-8 h-8"><path d="M13 2 3 14h9l-1 8 10-12h-9l1-8z"/></svg>
            </div>
          </div>
          <div class="text-green-800 text-4xl sm:text-5xl font-bold mb-2">40%</div>
          <div class="text-gray-600 font-medium">Energy Efficient</div>
        </div>
        <div class="bg-white/95 backdrop-blur-sm rounded-2xl border border-green-100 shadow-xl p-8 text-center transition-all hover:-translate-y-2 duration-300 group">
          <div class="text-green-600 mb-6 flex justify-center">
            <div class="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center group-hover:bg-green-200 transition-colors">
              <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-8 h-8"><path d="M12 10V5a3 3 0 1 1 3 3H5a3 3 0 0 1 3-3v5"/><path d="M12 14a3 3 0 1 0 3 3"/><path d="M12 14a3 3 0 1 1-3 3"/><path d="M7 21h10"/></svg>
            </div>
          </div>
          <div class="text-green-800 text-4xl sm:text-5xl font-bold mb-2">3x</div>
          <div class="text-gray-600 font-medium">Faster Growth</div>
        </div>
        <div class="bg-white/95 backdrop-blur-sm rounded-2xl border border-green-100 shadow-xl p-8 text-center transition-all hover:-translate-y-2 duration-300 group">
          <div class="text-green-600 mb-6 flex justify-center">
            <div class="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center group-hover:bg-green-200 transition-colors">
              <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-8 h-8"><line x1="18" x2="18" y1="20" y2="10"/><line x1="12" x2="12" y1="20" y2="4"/><line x1="6" x2="6" y1="20" y2="14"/></svg>
            </div>
          </div>
          <div class="text-green-800 text-4xl sm:text-5xl font-bold mb-2">24/7</div>
          <div class="text-gray-600 font-medium">Monitoring</div>
        </div>
      </div>
    </section>

    <!-- Features Section - Improved with better cards and visual hierarchy -->
    <section id="features" class="px-4 sm:px-6 py-20 sm:py-24 relative z-10">
      <div class="max-w-7xl mx-auto">
        <div class="text-center mb-16">
          <h2 class="text-3xl sm:text-4xl font-bold text-white mb-4">Advanced Features</h2>
          <div class="w-24 h-1.5 bg-gradient-to-r from-green-600 to-green-400 mx-auto rounded-full"></div>
        </div>
        
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          <div class="bg-white/95 backdrop-blur-sm rounded-2xl border border-green-100 shadow-xl p-8 text-center transition-all hover:-translate-y-2 duration-300 group">
            <div class="text-green-600 mb-6 flex justify-center">
              <div class="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center group-hover:bg-green-200 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-8 h-8"><path d="M5 12.55a11 11 0 0 1 14.08 0"/><path d="M1.42 9a16 16 0 0 1 21.16 0"/><path d="M8.53 16.11a6 6 0 0 1 6.95 0"/><line x1="12" x2="12.01" y1="20" y2="20"/></svg>
              </div>
            </div>
            <h3 class="text-green-800 text-xl font-semibold mb-3">WLAN Connectivity</h3>
            <p class="text-gray-600">Seamless wireless connectivity for all sensors and control systems with robust signal strength.</p>
          </div>
          <div class="bg-white/95 backdrop-blur-sm rounded-2xl border border-green-100 shadow-xl p-8 text-center transition-all hover:-translate-y-2 duration-300 group">
            <div class="text-green-600 mb-6 flex justify-center">
              <div class="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center group-hover:bg-green-200 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-8 h-8"><rect x="4" y="4" width="16" height="16" rx="2" ry="2"/><rect x="9" y="9" width="6" height="6"/><line x1="9" x2="9" y1="2" y2="4"/><line x1="15" x2="15" y1="2" y2="4"/><line x1="9" x2="9" y1="20" y2="22"/><line x1="15" x2="15" y1="20" y2="22"/><line x1="20" x2="22" y1="9" y2="9"/><line x1="20" x2="22" y1="14" y2="14"/><line x1="2" x2="4" y1="9" y2="9"/><line x1="2" x2="4" y1="14" y2="14"/></svg>
              </div>
            </div>
            <h3 class="text-green-800 text-xl font-semibold mb-3">IoT Sensors</h3>
            <p class="text-gray-600">High-precision sensors for temperature, humidity, pH, nutrient levels, and water flow monitoring.</p>
          </div>
          <div class="bg-white/95 backdrop-blur-sm rounded-2xl border border-green-100 shadow-xl p-8 text-center transition-all hover:-translate-y-2 duration-300 group">
            <div class="text-green-600 mb-6 flex justify-center">
              <div class="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center group-hover:bg-green-200 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-8 h-8"><path d="m12 14 4-4"/><path d="M3.34 19a10 10 0 1 1 17.32 0"/></svg>
              </div>
            </div>
            <h3 class="text-green-800 text-xl font-semibold mb-3">Real-time Analytics</h3>
            <p class="text-gray-600">Advanced analytics dashboard with real-time data visualization and historical trends.</p>
          </div>
          <div class="bg-white/95 backdrop-blur-sm rounded-2xl border border-green-100 shadow-xl p-8 text-center transition-all hover:-translate-y-2 duration-300 group">
            <div class="text-green-600 mb-6 flex justify-center">
              <div class="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center group-hover:bg-green-200 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-8 h-8"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/></svg>
              </div>
            </div>
            <h3 class="text-green-800 text-xl font-semibold mb-3">Automated Control</h3>
            <p class="text-gray-600">Smart automation for nutrient delivery, misting cycles, and environmental conditions.</p>
          </div>
          <div class="bg-white/95 backdrop-blur-sm rounded-2xl border border-green-100 shadow-xl p-8 text-center transition-all hover:-translate-y-2 duration-300 group">
            <div class="text-green-600 mb-6 flex justify-center">
              <div class="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center group-hover:bg-green-200 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-8 h-8"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>
              </div>
            </div>
            <h3 class="text-green-800 text-xl font-semibold mb-3">Alert System</h3>
            <p class="text-gray-600">Instant notifications for critical events, system anomalies, and maintenance requirements.</p>
          </div>
          <div class="bg-white/95 backdrop-blur-sm rounded-2xl border border-green-100 shadow-xl p-8 text-center transition-all hover:-translate-y-2 duration-300 group">
            <div class="text-green-600 mb-6 flex justify-center">
              <div class="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center group-hover:bg-green-200 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-8 h-8"><rect width="14" height="20" x="5" y="2" rx="2" ry="2"/><path d="M12 18h.01"/></svg>
              </div>
            </div>
            <h3 class="text-green-800 text-xl font-semibold mb-3">Responsive</h3>
            <p class="text-gray-600">Control your farm from anywhere with our intuitive responsive web application for desktop or mobile view.</p>
          </div>
        </div>
      </div>
    </section>

    <!-- How It Works Section - Improved with better visual flow -->
    <section id="how-it-works" class="px-4 sm:px-6 py-20 sm:py-24 relative z-10">
      <div class="max-w-7xl mx-auto">
        <div class="text-center mb-16">
          <h2 class="text-3xl sm:text-4xl font-bold text-white mb-4">How It Works</h2>
          <div class="w-24 h-1.5 bg-gradient-to-r from-green-600 to-green-400 mx-auto rounded-full"></div>
        </div>
        
        <div class="max-w-4xl mx-auto bg-white/95 backdrop-blur-sm rounded-2xl border border-green-100 shadow-xl p-8 sm:p-10">
          <div class="space-y-12">
            <div class="flex flex-col sm:flex-row gap-6 items-start">
              <div class="flex-shrink-0 w-16 h-16 bg-gradient-to-r from-green-600 to-green-500 rounded-full flex items-center justify-center text-white text-xl font-bold shadow-lg shadow-green-600/20">1</div>
              <div class="sm:pt-2">
                <h3 class="text-green-800 text-xl font-semibold mb-3">Install Sensors</h3>
                <p class="text-gray-600 text-lg">Our plug-and-play sensors are easily installed in your aeroponic system.</p>
              </div>
            </div>
            <div class="flex flex-col sm:flex-row gap-6 items-start">
              <div class="flex-shrink-0 w-16 h-16 bg-gradient-to-r from-green-600 to-green-500 rounded-full flex items-center justify-center text-white text-xl font-bold shadow-lg shadow-green-600/20">2</div>
              <div class="sm:pt-2">
                <h3 class="text-green-800 text-xl font-semibold mb-3">Connect to WLAN</h3>
                <p class="text-gray-600 text-lg">The system automatically connects to your wireless network for seamless data transmission.</p>
              </div>
            </div>
            <div class="flex flex-col sm:flex-row gap-6 items-start">
              <div class="flex-shrink-0 w-16 h-16 bg-gradient-to-r from-green-600 to-green-500 rounded-full flex items-center justify-center text-white text-xl font-bold shadow-lg shadow-green-600/20">3</div>
              <div class="sm:pt-2">
                <h3 class="text-green-800 text-xl font-semibold mb-3">Monitor & Control</h3>
                <p class="text-gray-600 text-lg">Access your dashboard to view real-time data and control your system remotely.</p>
              </div>
            </div>
            <div class="flex flex-col sm:flex-row gap-6 items-start">
              <div class="flex-shrink-0 w-16 h-16 bg-gradient-to-r from-green-600 to-green-500 rounded-full flex items-center justify-center text-white text-xl font-bold shadow-lg shadow-green-600/20">4</div>
              <div class="sm:pt-2">
                <h3 class="text-green-800 text-xl font-semibold mb-3">Optimize Growth</h3>
                <p class="text-gray-600 text-lg">Use AI-driven insights to optimize growing conditions and maximize yield.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Benefits Section - Improved with better cards and visual appeal -->
    <section id="benefits" class="px-4 sm:px-6 py-20 sm:py-24 relative z-10">
      <div class="max-w-7xl mx-auto">
        <div class="text-center mb-16">
          <h2 class="text-3xl sm:text-4xl font-bold text-white mb-4">Benefits of Eco-Mist</h2>
          <div class="w-24 h-1.5 bg-gradient-to-r from-green-600 to-green-400 mx-auto rounded-full"></div>
        </div>
        
        <div class="space-y-12">
          <div class="bg-white/95 backdrop-blur-sm rounded-2xl border border-green-100 shadow-xl p-8 sm:p-10 hover:shadow-2xl transition-shadow">
            <div class="flex flex-col lg:flex-row gap-8">
              <div class="lg:w-2/3">
                <h3 class="text-green-800 text-2xl font-semibold mb-4">Resource Efficiency</h3>
                <p class="text-gray-700 mb-6 text-lg">
                  Eco-Mist's precision control system reduces water usage by up to 95% compared to traditional farming methods. 
                  Our smart nutrient delivery ensures plants receive exactly what they need, minimizing waste and maximizing efficiency.
                </p>
                <ul class="space-y-3">
                  <li class="flex items-start gap-3 text-gray-600 text-lg">
                    <span class="text-green-600 mt-1 flex-shrink-0 bg-green-100 rounded-full p-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                    </span>
                    Reduced water consumption
                  </li>
                  <li class="flex items-start gap-3 text-gray-600 text-lg">
                    <span class="text-green-600 mt-1 flex-shrink-0 bg-green-100 rounded-full p-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                    </span>
                    Optimized nutrient usage
                  </li>
                  <li class="flex items-start gap-3 text-gray-600 text-lg">
                    <span class="text-green-600 mt-1 flex-shrink-0 bg-green-100 rounded-full p-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                    </span>
                    Lower energy requirements
                  </li>
                  <li class="flex items-start gap-3 text-gray-600 text-lg">
                    <span class="text-green-600 mt-1 flex-shrink-0 bg-green-100 rounded-full p-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                    </span>
                    Minimal environmental impact
                  </li>
                </ul>
              </div>
              <div class="lg:w-1/3 flex items-center justify-center">
                <div class="bg-green-50 p-6 rounded-full">
                  <svg xmlns="http://www.w3.org/2000/svg" width="128" height="128" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-32 h-32 text-green-600 filter drop-shadow-[0_0_10px_rgba(22,163,74,0.3)]"><path d="M2 22c1.25-1.25 2.5-2.5 3.5-4.5 1.5 1 2.5 1 4.5.5 2-2 3-4 3-6 0-1-.5-2.5-2-3 0 0 2 0 4 2 0-3.5-2-6.5-2-8 0-.5 0-1 .5-1 .5 0 1 .5 1.5 2 2-3 2.5-4 3-6 .5 2 1.5 3 2.5 5 1-1.5 1.5-3 1.5-4.5.5 1.5 1 3 1 4.5 1-1 2-2 3-2.5 0 1-1 2-1 3 1 .5 2 1 2.5 2-1 1-2 1.5-3 2 1 2 1 4.5 0 6.5-1.5 1-3 1.5-4.5 2 1 1.5 2 3 3 4.5-1.5-.5-3-1-4.5-1.5-1 1-2 2-3 2.5 0-1 .5-2.5 1-3.5-1.5-.5-3-1-4.5-1.5-1 1.5-2 3-3.5 4.5z"/></svg>
                </div>
              </div>
            </div>
          </div>
          
          <div class="bg-white/95 backdrop-blur-sm rounded-2xl border border-green-100 shadow-xl p-8 sm:p-10 hover:shadow-2xl transition-shadow">
            <div class="flex flex-col lg:flex-row-reverse gap-8">
              <div class="lg:w-2/3">
                <h3 class="text-green-800 text-2xl font-semibold mb-4">Increased Yield</h3>
                <p class="text-gray-700 mb-6 text-lg">
                  By maintaining optimal growing conditions at all times, Eco-Mist helps plants grow up to 3 times faster 
                  with higher nutrient density. Year-round production becomes possible regardless of external climate conditions.
                </p>
                <ul class="space-y-3">
                  <li class="flex items-start gap-3 text-gray-600 text-lg">
                    <span class="text-green-600 mt-1 flex-shrink-0 bg-green-100 rounded-full p-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                    </span>
                    Faster growth cycles
                  </li>
                  <li class="flex items-start gap-3 text-gray-600 text-lg">
                    <span class="text-green-600 mt-1 flex-shrink-0 bg-green-100 rounded-full p-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                    </span>
                    Higher crop density
                  </li>
                  <li class="flex items-start gap-3 text-gray-600 text-lg">
                    <span class="text-green-600 mt-1 flex-shrink-0 bg-green-100 rounded-full p-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                    </span>
                    Year-round production
                  </li>
                  <li class="flex items-start gap-3 text-gray-600 text-lg">
                    <span class="text-green-600 mt-1 flex-shrink-0 bg-green-100 rounded-full p-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                    </span>
                    Improved crop quality
                  </li>
                </ul>
              </div>
              <div class="lg:w-1/3 flex items-center justify-center">
                <div class="bg-green-50 p-6 rounded-full">
                  <svg xmlns="http://www.w3.org/2000/svg" width="128" height="128" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-32 h-32 text-green-600 filter drop-shadow-[0_0_10px_rgba(22,163,74,0.3)]"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"></polyline><polyline points="16 7 22 7 22 13"></polyline></svg>
                </div>
              </div>
            </div>
          </div>
          
          <div class="bg-white/95 backdrop-blur-sm rounded-2xl border border-green-100 shadow-xl p-8 sm:p-10 hover:shadow-2xl transition-shadow">
            <div class="flex flex-col lg:flex-row gap-8">
              <div class="lg:w-2/3">
                <h3 class="text-green-800 text-2xl font-semibold mb-4">Data-Driven Decisions</h3>
                <p class="text-gray-700 mb-6 text-lg">
                  Our advanced analytics platform provides actionable insights based on historical data and real-time monitoring. 
                  Make informed decisions to continuously improve your farming operation and adapt to changing conditions.
                </p>
                <ul class="space-y-3">
                  <li class="flex items-start gap-3 text-gray-600 text-lg">
                    <span class="text-green-600 mt-1 flex-shrink-0 bg-green-100 rounded-full p-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                    </span>
                    Real-time monitoring
                  </li>
                  <li class="flex items-start gap-3 text-gray-600 text-lg">
                    <span class="text-green-600 mt-1 flex-shrink-0 bg-green-100 rounded-full p-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                    </span>
                    Historical trend analysis
                  </li>
                  <li class="flex items-start gap-3 text-gray-600 text-lg">
                    <span class="text-green-600 mt-1 flex-shrink-0 bg-green-100 rounded-full p-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                    </span>
                    Predictive maintenance
                  </li>
                  <li class="flex items-start gap-3 text-gray-600 text-lg">
                    <span class="text-green-600 mt-1 flex-shrink-0 bg-green-100 rounded-full p-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                    </span>
                    Continuous optimization
                  </li>
                </ul>
              </div>
              <div class="lg:w-1/3 flex items-center justify-center">
                <div class="bg-green-50 p-6 rounded-full">
                  <svg xmlns="http://www.w3.org/2000/svg" width="128" height="128" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-32 h-32 text-green-600 filter drop-shadow-[0_0_10px_rgba(22,163,74,0.3)]"><path d="M3 3v18h18"/><path d="m19 9-5 5-4-4-3 3"/></svg>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- CTA Section - Improved with better form styling -->
    <section id="contact" class="px-4 sm:px-6 py-20 sm:py-24 relative z-10">
      <div class="max-w-7xl mx-auto">
        <div class="max-w-3xl mx-auto bg-white/95 backdrop-blur-sm rounded-2xl border border-green-100 shadow-xl p-8 sm:p-10 text-center">
          <h2 class="text-3xl sm:text-4xl font-bold text-green-800 mb-4">Ready to Transform Your Farming?</h2>
          <p class="text-gray-700 mb-8 text-lg">Get in touch with our team to schedule a demonstration or learn more about how Eco-Mist can revolutionize your aeroponic farming.</p>
          
          <form @submit.prevent="submitContactForm" class="text-left" aria-label="Contact form">
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-6">
              <div class="relative group">
                <input 
                  id="name"
                  type="text" 
                  v-model="contactForm.name" 
                  :class="{ 'pt-6': contactForm.name, 'border-red-500': formErrors.name, 'border-green-500 ring-1 ring-green-500': contactForm.name && !formErrors.name }"
                  aria-required="true"
                  aria-invalid="formErrors.name ? 'true' : 'false'"
                  aria-describedby="name-error"
                  required
                  class="w-full bg-white border-2 border-gray-200 rounded-xl px-4 py-3.5 text-gray-800 focus:border-green-500 focus:outline-none focus:ring-2 focus:ring-green-500/50 transition-all"
                />
                <label 
                  for="name"
                  :class="{ 'text-xs top-2': contactForm.name, 'top-1/2 -translate-y-1/2': !contactForm.name, 'text-green-600': contactForm.name && !formErrors.name, 'text-red-500': formErrors.name }"
                  class="absolute left-4 text-gray-500 transition-all pointer-events-none"
                >
                  Full Name
                </label>
                <p v-if="formErrors.name" id="name-error" class="text-red-600 text-sm mt-1">{{ formErrors.name }}</p>
              </div>
              <div class="relative group">
                <input 
                  id="email"
                  type="email" 
                  v-model="contactForm.email" 
                  :class="{ 'pt-6': contactForm.email, 'border-red-500': formErrors.email, 'border-green-500 ring-1 ring-green-500': contactForm.email && !formErrors.email }"
                  aria-required="true"
                  aria-invalid="formErrors.email ? 'true' : 'false'"
                  aria-describedby="email-error"
                  required
                  class="w-full bg-white border-2 border-gray-200 rounded-xl px-4 py-3.5 text-gray-800 focus:border-green-500 focus:outline-none focus:ring-2 focus:ring-green-500/50 transition-all"
                />
                <label 
                  for="email"
                  :class="{ 'text-xs top-2': contactForm.email, 'top-1/2 -translate-y-1/2': !contactForm.email, 'text-green-600': contactForm.email && !formErrors.email, 'text-red-500': formErrors.email }"
                  class="absolute left-4 text-gray-500 transition-all pointer-events-none"
                >
                  Email Address
                </label>
                <p v-if="formErrors.email" id="email-error" class="text-red-600 text-sm mt-1">{{ formErrors.email }}</p>
              </div>
            </div>
            <div class="relative mb-6 group">
              <textarea 
                id="message"
                v-model="contactForm.message" 
                :class="{ 'pt-8': contactForm.message, 'border-red-500': formErrors.message, 'border-green-500 ring-1 ring-green-500': contactForm.message && !formErrors.message }"
                aria-required="true"
                aria-invalid="formErrors.message ? 'true' : 'false'"
                aria-describedby="message-error"
                required
                rows="4"
                class="w-full bg-white border-2 border-gray-200 rounded-xl px-4 py-3.5 text-gray-800 focus:border-green-500 focus:outline-none focus:ring-2 focus:ring-green-500/50 transition-all resize-y"
              ></textarea>
              <label 
                for="message"
                :class="{ 'text-xs top-2': contactForm.message, 'top-4': !contactForm.message, 'text-green-600': contactForm.message && !formErrors.message, 'text-red-500': formErrors.message }"
                class="absolute left-4 text-gray-500 transition-all pointer-events-none"
              >
                Your Message
              </label>
              <p v-if="formErrors.message" id="message-error" class="text-red-600 text-sm mt-1">{{ formErrors.message }}</p>
            </div>
            <button 
              type="submit" 
              :disabled="submitting"
              aria-busy="submitting"
              class="w-full bg-gradient-to-r from-green-600 to-green-500 text-white font-semibold px-6 py-4 rounded-xl hover:-translate-y-1 transition-transform shadow-lg shadow-green-600/20 active:scale-95 touch-manipulation disabled:opacity-50 disabled:cursor-not-allowed text-lg"
            >
              <span v-if="!submitting">Send Message</span>
              <span v-else class="inline-flex items-center justify-center">
                <svg class="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                  <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Processing...
              </span>
            </button>
            <div class="mt-4">
              <p v-if="successMessage" class="text-green-600 text-center font-medium" role="alert">{{ successMessage }}</p>
              <p v-if="errorMessage" class="text-red-600 text-center font-medium" role="alert">{{ errorMessage }}</p>
            </div>
          </form>
        </div>
        
        <!-- Map section with improved search functionality -->
        <section id="location" class="px-4 sm:px-6 py-12 sm:py-16 relative z-10">
          <div class="max-w-7xl mx-auto">
            <div class="text-center mb-12">
              <h2 class="text-3xl sm:text-4xl font-bold text-white mb-4">Find Us</h2>
              <div class="w-24 h-1.5 bg-gradient-to-r from-green-600 to-green-400 mx-auto rounded-full mb-6"></div>
              <p class="text-white/80 text-lg max-w-2xl mx-auto">Search for a location to see our nearest service centers or enter your address to get directions.</p>
            </div>
            
            <div class="max-w-3xl mx-auto">
              <div class="mb-6">
                <div class="relative">
                  <input 
                    v-model="searchQuery" 
                    @keyup.enter="searchPlace"
                    type="text" 
                    placeholder="Search for a place or address..." 
                    class="w-full px-5 py-4 border-2 border-gray-200 rounded-xl shadow-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 pr-14 text-gray-700 bg-white/95 backdrop-blur-sm"
                  />
                  <button 
                    @click="searchPlace" 
                    class="absolute right-3 top-1/2 -translate-y-1/2 px-3 py-2 bg-gradient-to-r from-green-600 to-green-500 text-white rounded-lg hover:from-green-700 hover:to-green-600 transition-all shadow-md"
                    :disabled="isSearching"
                  >
                    <span v-if="isSearching" class="flex items-center">
                      <svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      <span class="sr-only">Searching...</span>
                    </span>
                    <svg v-else xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                  </button>
                </div>
                <div v-if="searchError" class="mt-2 text-red-500 text-sm bg-red-100 p-2 rounded-lg">
                  {{ searchError }}
                </div>
                <div v-if="suggestions.length > 0" class="mt-2 bg-white/95 backdrop-blur-sm rounded-xl border border-gray-200 shadow-lg overflow-hidden">
                  <ul>
                    <li v-for="(suggestion, index) in suggestions" :key="index" 
                        class="p-3 border-b border-gray-100 last:border-b-0 hover:bg-green-50 cursor-pointer transition-colors"
                        @click="selectSuggestion(suggestion)">
                      <div class="flex items-center gap-2">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-green-600"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
                        <span>{{ suggestion }}</span>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
              
              <div class="rounded-2xl overflow-hidden shadow-xl border-4 border-white relative">
                <div v-if="isMapLoading" class="absolute inset-0 bg-gray-100 flex items-center justify-center z-10">
                  <div class="flex flex-col items-center">
                    <svg class="animate-spin h-10 w-10 text-green-600 mb-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                      <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    <p class="text-gray-600">Loading map...</p>
                  </div>
                </div>
                <iframe 
                  ref="mapIframe"
                  :src="mapUrl" 
                  width="100%" 
                  height="450" 
                  style="border:0;" 
                  allowfullscreen="" 
                  loading="lazy" 
                  referrerpolicy="no-referrer-when-downgrade"
                  class="w-full"
                  @load="handleMapLoad"
                ></iframe>
              </div>
              
              <div class="mt-6 flex flex-col sm:flex-row gap-4 justify-center">
                <button @click="getCurrentLocation" class="flex items-center justify-center gap-2 bg-white/90 backdrop-blur-sm text-green-700 px-6 py-3 rounded-xl border border-green-200 hover:bg-green-50 transition-colors shadow-md">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-green-600"><circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/><path d="M2 12h20"/></svg>
                  Use My Location
                </button>
                <a :href="directionsUrl" target="_blank" class="flex items-center justify-center gap-2 bg-gradient-to-r from-green-600 to-green-500 text-white px-6 py-3 rounded-xl hover:from-green-700 hover:to-green-600 transition-all shadow-md">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s-8-4.5-8-11.8A8 8 0 0 1 12 2a8 8 0 0 1 8 8.2c0 7.3-8 11.8-8 11.8z"/><circle cx="12" cy="10" r="3"/></svg>
                  Get Directions
                </a>
              </div>
            </div>
          </div>
        </section>
      </div>
    </section>

    <!-- FAQ Section - Improved with better styling -->
    <section id="faq" class="px-4 sm:px-6 py-20 sm:py-24 relative z-10">
      <div class="max-w-7xl mx-auto">
        <div class="text-center mb-16">
          <h2 class="text-3xl sm:text-4xl font-bold text-white mb-4">Frequently Asked Questions</h2>
          <div class="w-24 h-1.5 bg-gradient-to-r from-green-600 to-green-400 mx-auto rounded-full"></div>
        </div>
        
        <div class="max-w-4xl mx-auto space-y-6">
          <div class="bg-white/95 backdrop-blur-sm rounded-2xl border border-green-100 shadow-xl p-6 hover:shadow-2xl transition-shadow">
            <h3 class="text-xl font-semibold text-green-800 mb-3">What is Eco-Mist?</h3>
            <p class="text-gray-600 text-lg">Eco-Mist is an IoT-driven aeroponics farming system designed to optimize growth, reduce resource consumption, and provide real-time insights for sustainable agriculture.</p>
          </div>
          <div class="bg-white/95 backdrop-blur-sm rounded-2xl border border-green-100 shadow-xl p-6 hover:shadow-2xl transition-shadow">
            <h3 class="text-xl font-semibold text-green-800 mb-3">How does Eco-Mist work?</h3>
            <p class="text-gray-600 text-lg">Eco-Mist uses IoT sensors to monitor environmental conditions and automate nutrient delivery and misting cycles for optimal plant growth. The system connects to your wireless network for seamless data transmission and control.</p>
          </div>
          <div class="bg-white/95 backdrop-blur-sm rounded-2xl border border-green-100 shadow-xl p-6 hover:shadow-2xl transition-shadow">
            <h3 class="text-xl font-semibold text-green-800 mb-3">Is Eco-Mist suitable for all crops?</h3>
            <p class="text-gray-600 text-lg">Eco-Mist is ideal for a wide range of crops, particularly those that thrive in aeroponic systems, such as leafy greens, herbs, strawberries, and many other high-value crops that benefit from precise environmental control.</p>
          </div>
          <div class="bg-white/95 backdrop-blur-sm rounded-2xl border border-green-100 shadow-xl p-6 hover:shadow-2xl transition-shadow">
            <h3 class="text-xl font-semibold text-green-800 mb-3">What kind of support do you offer?</h3>
            <p class="text-gray-600 text-lg">We provide comprehensive support including installation guidance, system training, regular software updates, and 24/7 technical assistance to ensure your Eco-Mist system operates at peak performance.</p>
          </div>
        </div>
      </div>
    </section>

    <!-- Footer Section - Improved with better styling -->
    <footer class="px-4 sm:px-6 py-16 relative z-10">
      <div class="max-w-7xl mx-auto bg-white/95 backdrop-blur-sm rounded-2xl border border-green-100 shadow-xl p-8 sm:p-10">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-10">
          <div class="md:col-span-1">
            <div class="flex items-center gap-3 mb-6">
              <img src="/eco-mist-logo.png" alt="Eco-Mist Logo" class="w-12 h-12" loading="lazy" />
              <span class="text-green-800 text-2xl font-bold">Eco-Mist</span>
            </div>
            <p class="text-gray-600 mb-6">
              Revolutionizing aeroponics farming with IoT technology for sustainable agriculture.
            </p>
            <div class="flex space-x-5">
              <a href="#" class="text-gray-500 hover:text-green-600 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path></svg>
              </a>
              <a href="#" class="text-gray-500 hover:text-green-600 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"></path></svg>
              </a>
              <a href="#" class="text-gray-500 hover:text-green-600 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line></svg>
              </a>
              <a href="#" class="text-gray-500 hover:text-green-600 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path><rect x="2" y="9" width="4" height="12"></rect><circle cx="4" cy="4" r="2"></circle></svg>
              </a>
            </div>
          </div>
          
          <div class="md:col-span-1">
            <h3 class="text-green-800 font-semibold text-lg mb-6">Quick Links</h3>
            <ul class="space-y-4">
              <li><a href="#features" class="text-gray-600 hover:text-green-600 transition-colors flex items-center gap-2"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-4 h-4"><polyline points="9 18 15 12 9 6"></polyline></svg> Features</a></li>
              <li><a href="#how-it-works" class="text-gray-600 hover:text-green-600 transition-colors flex items-center gap-2"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-4 h-4"><polyline points="9 18 15 12 9 6"></polyline></svg> How It Works</a></li>
              <li><a href="#benefits" class="text-gray-600 hover:text-green-600 transition-colors flex items-center gap-2"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-4 h-4"><polyline points="9 18 15 12 9 6"></polyline></svg> Benefits</a></li>
              <li><a href="#contact" class="text-gray-600 hover:text-green-600 transition-colors flex items-center gap-2"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-4 h-4"><polyline points="9 18 15 12 9 6"></polyline></svg> Contact Us</a></li>
              <li><router-link to="/auth" class="text-gray-600 hover:text-green-600 transition-colors flex items-center gap-2"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-4 h-4"><polyline points="9 18 15 12 9 6"></polyline></svg> Login</router-link></li>
            </ul>
          </div>
          
          <div class="md:col-span-1">
            <h3 class="text-green-800 font-semibold text-lg mb-6">Resources</h3>
            <ul class="space-y-4">
              <li><a href="#" class="text-gray-600 hover:text-green-600 transition-colors flex items-center gap-2"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-4 h-4"><polyline points="9 18 15 12 9 6"></polyline></svg> Documentation</a></li>
              <li><a href="#" class="text-gray-600 hover:text-green-600 transition-colors flex items-center gap-2"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-4 h-4"><polyline points="9 18 15 12 9 6"></polyline></svg> Knowledge Base</a></li>
              <li><a href="#" class="text-gray-600 hover:text-green-600 transition-colors flex items-center gap-2"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-4 h-4"><polyline points="9 18 15 12 9 6"></polyline></svg> API Reference</a></li>
              <li><a href="#" class="text-gray-600 hover:text-green-600 transition-colors flex items-center gap-2"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-4 h-4"><polyline points="9 18 15 12 9 6"></polyline></svg> Blog</a></li>
              <li><a href="#" class="text-gray-600 hover:text-green-600 transition-colors flex items-center gap-2"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-4 h-4"><polyline points="9 18 15 12 9 6"></polyline></svg> Support</a></li>
            </ul>
          </div>
          
          <div class="md:col-span-1">
            <h3 class="text-green-800 font-semibold text-lg mb-6">Contact</h3>
            <ul class="space-y-4">
              <li class="flex items-start gap-3">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-green-600 mt-1 flex-shrink-0"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
                <span class="text-gray-600">+63 923 4567 890</span>
              </li>
              <li class="flex items-start gap-3">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-green-600 mt-1 flex-shrink-0"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
                <span class="text-gray-600">ecomist111@gmail.com</span>
              </li>
              <li class="flex items-start gap-3">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-green-600 mt-1 flex-shrink-0"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
                <span class="text-gray-600">Masipit, Calapan City, Oriental Mindoro</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div class="border-t border-green-100 mt-10 pt-8 text-center">
          <p class="text-gray-600">© 2025 Eco-Mist. All rights reserved.</p>
          <div class="flex justify-center space-x-8 mt-4">
            <a href="#" class="text-gray-600 hover:text-green-600 transition-colors text-sm">Privacy Policy</a>
            <a href="#" class="text-gray-600 hover:text-green-600 transition-colors text-sm">Terms of Service</a>
            <a href="#" class="text-gray-600 hover:text-green-600 transition-colors text-sm">Cookie Policy</a>
          </div>
        </div>
      </div>
    </footer>
  </div>
  
  <div v-if="hasError" class="text-center py-16">
    <h2 class="text-2xl font-bold text-red-600">Something went wrong</h2>
    <p class="text-gray-600">Please try refreshing the page or contact support if the issue persists.</p>
  </div>

  <!-- Back-to-Top Button - Improved styling -->
  <button 
    v-show="showBackToTop" 
    @click="scrollToTop" 
    class="fixed bottom-8 right-8 bg-gradient-to-r from-green-600 to-green-500 text-white p-4 rounded-full shadow-lg hover:bg-green-700 transition-all hover:-translate-y-1 z-50"
    aria-label="Back to top"
  >
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-6 h-6">
      <path d="M18 15l-6-6-6 6"></path>
    </svg>
  </button>

  <!-- Cookie Consent Banner - Improved styling -->
  <div v-if="showCookieBanner" class="fixed bottom-0 left-0 right-0 bg-gray-800 text-white p-4 sm:p-6 flex flex-col sm:flex-row justify-between items-center z-50 shadow-xl">
    <p class="text-sm sm:text-base mb-4 sm:mb-0">We use cookies to improve your experience. By using our site, you agree to our <a href="#" class="underline hover:text-green-400 transition-colors">cookie policy</a>.</p>
    <div class="flex gap-4">
      <button @click="acceptCookies" class="bg-green-600 px-6 py-2 rounded-lg hover:bg-green-700 transition-all font-medium">Accept</button>
      <button @click="showCookieBanner = false" class="bg-gray-700 px-6 py-2 rounded-lg hover:bg-gray-600 transition-all font-medium">Decline</button>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted, watch } from 'vue';
import { collection, addDoc, Timestamp } from 'firebase/firestore';
import { getFirestore } from 'firebase/firestore';
import { initializeApp } from 'firebase/app';

// Ensure Firebase is initialized
const firebaseConfig = {
  apiKey: "AIzaSyDI4-BnlhJz5BQflocmopqpEIsc6WoHiE0",
  authDomain: "ecomist-3082f.firebaseapp.com",
  databaseURL: "https://ecomist-3082f-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "ecomist-3082f",
  storageBucket: "ecomist-3082f.firebasestorage.app",
  messagingSenderId: "1054000421761",
  appId: "1:1054000421761:web:4a79a37b3b2fef9b996680",
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const mobileMenuOpen = ref(false);
const submitting = ref(false);

const contactForm = reactive({
  name: '',
  email: '',
  message: ''
});

const formErrors = reactive({
  name: '',
  email: '',
  message: ''
});

let successMessage = ref('');
let errorMessage = ref('');

let hasError = ref(false);

const handleError = (error, vm, info) => {
  console.error('Error captured:', error, info);
  hasError.value = true;
};

onMounted(() => {
  // Global error handler
  window.addEventListener('error', (event) => {
    console.error('Global error:', event.error);
    hasError.value = true;
  });
});

// Basic email regex for validation
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const validateForm = () => {
  let valid = true;
  if (!contactForm.name.trim()) {
    formErrors.name = 'Full Name is required.';
    valid = false;
  } else if (contactForm.name.trim().length < 3) {
    formErrors.name = 'Full Name must be at least 3 characters.';
    valid = false;
  } else {
    formErrors.name = '';
  }

  if (!contactForm.email.trim()) {
    formErrors.email = 'Email Address is required.';
    valid = false;
  } else if (!emailRegex.test(contactForm.email)) {
    formErrors.email = 'Please enter a valid email address.';
    valid = false;
  } else {
    formErrors.email = '';
  }

  if (!contactForm.message.trim()) {
    formErrors.message = 'Message is required.';
    valid = false;
  } else if (contactForm.message.trim().length < 10) {
    formErrors.message = 'Message must be at least 10 characters.';
    valid = false;
  } else {
    formErrors.message = '';
  }

  return valid;
};

const toggleMobileMenu = () => {
  mobileMenuOpen.value = !mobileMenuOpen.value;
};

const closeMobileMenu = () => {
  mobileMenuOpen.value = false;
};

const submitContactForm = async () => {
  successMessage.value = '';
  errorMessage.value = '';

  if (!validateForm()) {
    return;
  }

  submitting.value = true;

  try {
    // Save contact form data to Firestore
    await addDoc(collection(db, 'contact_messages'), {
      name: contactForm.name,
      email: contactForm.email,
      message: contactForm.message,
      timestamp: Timestamp.now(),
    });

    // Reset form
    contactForm.name = '';
    contactForm.email = '';
    contactForm.message = '';

    successMessage.value = 'Thank you for your message! We will get back to you soon.';
    errorMessage.value = '';
  } catch (error) {
    console.error('Error submitting contact form:', error); // Log the full error
    errorMessage.value = 'Failed to send your message. Please check your internet connection or try again later.';
    successMessage.value = '';
  } finally {
    submitting.value = false;
  }
};

// Scroll to section with smooth behavior
const scrollToSection = (id) => {
  const el = document.getElementById(id);
  if (el) {
    el.scrollIntoView({ behavior: 'smooth' });
    closeMobileMenu();
  }
};

const showBackToTop = ref(false);
const showCookieBanner = ref(!localStorage.getItem('cookiesAccepted'));

const scrollToTop = () => {
  window.scrollTo({ top: 0, behavior: 'smooth' });
};

const acceptCookies = () => {
  localStorage.setItem('cookiesAccepted', 'true');
  showCookieBanner.value = false;
};

onMounted(() => {
  window.addEventListener('scroll', () => {
    showBackToTop.value = window.scrollY > 300;
  });
});

// Map functionality
const searchQuery = ref('');
const mapUrl = ref('https://www.google.com/maps/embed/v1/place?key=AIzaSyBFw0Qbyq9zTFTd-tUY6dZWTgaQzuU17R8&q=Eco-Mist+Headquarters&zoom=15');
const directionsUrl = ref('https://www.google.com/maps/dir/?api=1&destination=Eco-Mist+Headquarters');
const isSearching = ref(false);
const isMapLoading = ref(true);
const searchError = ref('');
const suggestions = ref([]);
const mapIframe = ref(null);

// Sample suggestions based on search query
const getSuggestions = (query) => {
  if (!query || query.length < 3) {
    suggestions.value = [];
    return;
  }
  
  // In a real app, you would call a places API here
  // This is just a simple simulation
  const samplePlaces = [
    'New York, NY',
    'Los Angeles, CA',
    'Chicago, IL',
    'Houston, TX',
    'Phoenix, AZ',
    'Philadelphia, PA',
    'San Antonio, TX',
    'San Diego, CA',
    'Dallas, TX',
    'San Jose, CA',
    'Austin, TX',
    'Jacksonville, FL',
    'San Francisco, CA',
    'Columbus, OH',
    'Indianapolis, IN',
    'Seattle, WA',
    'Denver, CO',
    'Washington, DC',
    'Boston, MA',
    'Nashville, TN'
  ];
  
  suggestions.value = samplePlaces
    .filter(place => place.toLowerCase().includes(query.toLowerCase()))
    .slice(0, 5);
};

// Watch for changes in the search query to update suggestions
watch(searchQuery, (newQuery) => {
  getSuggestions(newQuery);
});

const selectSuggestion = (suggestion) => {
  searchQuery.value = suggestion;
  suggestions.value = [];
  searchPlace();
};

const searchPlace = async () => {
  if (!searchQuery.value.trim()) {
    searchError.value = 'Please enter a location to search';
    return;
  }
  
  isSearching.value = true;
  searchError.value = '';
  isMapLoading.value = true;
  
  try {
    const query = encodeURIComponent(searchQuery.value.trim());
    
    // Using Google Maps Embed API
    mapUrl.value = `https://www.google.com/maps/embed/v1/place?key=AIzaSyBFw0Qbyq9zTFTd-tUY6dZWTgaQzuU17R8&q=${query}&zoom=15`;
    
    // Update directions URL
    directionsUrl.value = `https://www.google.com/maps/dir/?api=1&destination=${query}`;
    
    suggestions.value = [];
  } catch (error) {
    console.error('Error searching for place:', error);
    searchError.value = 'Unable to find the location. Please try a different search term.';
  } finally {
    isSearching.value = false;
  }
};

const getCurrentLocation = () => {
  if (!navigator.geolocation) {
    searchError.value = 'Geolocation is not supported by your browser';
    return;
  }
  
  isSearching.value = true;
  searchError.value = '';
  isMapLoading.value = true;
  
  navigator.geolocation.getCurrentPosition(
    (position) => {
      const { latitude, longitude } = position.coords;
      
      // Update map with coordinates
      mapUrl.value = `https://www.google.com/maps/embed/v1/view?key=AIzaSyBFw0Qbyq9zTFTd-tUY6dZWTgaQzuU17R8&center=${latitude},${longitude}&zoom=15`;
      
      // Update directions URL
      directionsUrl.value = `https://www.google.com/maps/dir/?api=1&destination=${latitude},${longitude}`;
      
      // Update search query with coordinates (optional)
      searchQuery.value = `${latitude.toFixed(6)}, ${longitude.toFixed(6)}`;
      
      isSearching.value = false;
    },
    (error) => {
      console.error('Error getting location:', error);
      searchError.value = 'Unable to get your location. Please make sure location services are enabled.';
      isSearching.value = false;
      isMapLoading.value = false;
    }
  );
};

const handleMapLoad = () => {
  isMapLoading.value = false;
};
</script>

<style>
@keyframes float-logo {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-20px); }
}

@keyframes shine {
  0% { transform: translateX(-100%); }
  100% { transform: translateX(100%); }
}

.animate-float-logo {
  animation: float-logo 6s infinite ease-in-out;
}

.animate-shine {
  animation: shine 6s infinite linear;
}

/* For better touch interactions */
.touch-manipulation {
  touch-action: manipulation;
}

@media (prefers-reduced-motion: reduce) {
  .animate-float-logo,
  .animate-shine {
    animation: none;
  }
  
  .active\:scale-95:active,
  .hover\:-translate-y-1:hover,
  .hover\:-translate-y-2:hover {
    transform: none;
  }
}

/* Smooth scrolling for anchor links */
html {
  scroll-behavior: smooth;
}

/* Smooth transition for Back-to-Top button */
button[aria-label="Back to top"] {
  transition: opacity 0.3s ease, transform 0.3s ease;
}
button[aria-label="Back to top"]:hover {
  transform: translateY(-4px);
}

/* Improved form focus states */
input:focus-visible,
textarea:focus-visible {
  outline: none;
  box-shadow: 0 0 0 2px rgba(22, 163, 74, 0.4);
}

/* Improved card hover effects */
.hover\:shadow-2xl {
  transition: box-shadow 0.3s ease, transform 0.3s ease;
}

/* Add these new styles for the map section */
.map-container {
  position: relative;
  overflow: hidden;
  border-radius: 1rem;
}

@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.5; }
}

.animate-pulse {
  animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
}
</style>