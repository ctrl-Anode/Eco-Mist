<template>
  <div class="min-h-screen relative overflow-x-hidden">
    <!-- Agricultural Background -->
    <div class="fixed inset-0 bg-green-900 z-0">
      <!-- Static agricultural background with farm pattern -->
      <div class="absolute inset-0 bg-[url('/farm-pattern.png')] opacity-10"></div>
      <div class="absolute w-[600px] h-[600px] rounded-full filter blur-[40px] opacity-20 bg-gradient-to-br from-green-500 to-green-600 -top-[200px] -left-[200px]"></div>
      <div class="absolute w-[500px] h-[500px] rounded-full filter blur-[40px] opacity-20 bg-gradient-to-br from-green-700 to-green-800 -bottom-[150px] -right-[150px]"></div>
    </div>

    <!-- Navigation -->
    <nav class="sticky top-0 z-50 mx-3 sm:mx-5 my-3 sm:my-5 bg-white/90 backdrop-blur-sm rounded-xl border border-green-100 shadow-lg"> 
      <div class="flex justify-between items-center p-3 sm:p-4"> 
        <div class="flex items-center gap-3"> 
          <img src="/eco-mist-logo.png" alt="Eco-Mist Logo" class="w-10 h-10" /> 
          <span class="text-green-800 text-xl sm:text-2xl font-bold">Eco-Mist</span> 
        </div> 
        <div class="hidden md:flex items-center gap-6"> 
          <a href="/#features" class="text-green-800 hover:text-green-600 transition-colors font-medium">Features</a> 
          <a href="/#how-it-works" class="text-green-800 hover:text-green-600 transition-colors font-medium">How It Works</a> 
          <a href="/#benefits" class="text-green-800 hover:text-green-600 transition-colors font-medium">Benefits</a> 
          <a href="/#contact" class="text-green-800 hover:text-green-600 transition-colors font-medium">Contact</a> 
        </div> 
        <button class="md:hidden w-10 h-10 flex items-center justify-center text-green-800 bg-green-100 rounded-lg active:bg-green-200 touch-manipulation" @click="toggleMobileMenu" aria-label="Toggle menu" > 
          <svg v-if="!mobileMenuOpen" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-5 h-5"><line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/></svg>
          <svg v-else xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-5 h-5"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
        </button> 
      </div> 
      <transition 
        name="mobile-menu"
        enter-active-class="transition duration-300 ease-out"
        enter-from-class="transform -translate-y-8 opacity-0"
        enter-to-class="transform translate-y-0 opacity-100"
        leave-active-class="transition duration-200 ease-in"
        leave-from-class="transform translate-y-0 opacity-100"
        leave-to-class="transform -translate-y-8 opacity-0"
      >
        <div v-if="mobileMenuOpen" class="md:hidden border-t border-green-100 p-4">
          <div class="flex flex-col space-y-4"> 
            <a href="/#features" @click="closeMobileMenu" class="text-green-800 py-2 hover:text-green-600 transition-colors font-medium active:bg-green-50 rounded-lg px-3 touch-manipulation">Features</a> 
            <a href="/#how-it-works" @click="closeMobileMenu" class="text-green-800 py-2 hover:text-green-600 transition-colors font-medium active:bg-green-50 rounded-lg px-3 touch-manipulation">How It Works</a> 
            <a href="/#benefits" @click="closeMobileMenu" class="text-green-800 py-2 hover:text-green-600 transition-colors font-medium active:bg-green-50 rounded-lg px-3 touch-manipulation">Benefits</a> 
            <a href="/#contact" @click="closeMobileMenu" class="text-green-800 py-2 hover:text-green-600 transition-colors font-medium active:bg-green-50 rounded-lg px-3 touch-manipulation">Contact</a> 
          </div>
        </div>
      </transition>
    </nav>

    <!-- Main Content -->
    <div class="container mx-auto px-4 py-8 relative z-10">
      <!-- Global Alert for System Messages -->
      <transition
        name="fade"
        enter-active-class="transition duration-300 ease-out"
        enter-from-class="transform -translate-y-4 opacity-0"
        enter-to-class="transform translate-y-0 opacity-100"
        leave-active-class="transition duration-200 ease-in"
        leave-from-class="transform translate-y-0 opacity-100"
        leave-to-class="transform -translate-y-4 opacity-0"
      >
        <div v-if="globalAlert.show" :class="`mb-6 p-4 rounded-lg flex items-start gap-3 ${globalAlert.type === 'error' ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'}`">
          <div class="flex-shrink-0 mt-0.5">
            <svg v-if="globalAlert.type === 'error'" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-red-500"><circle cx="12" cy="12" r="10"/><line x1="15" x2="9" y1="9" y2="15"/><line x1="9" x2="15" y1="9" y2="15"/></svg>
            <svg v-else xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-green-500"><circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/></svg>
          </div>
          <div class="flex-1">
            <h4 class="font-medium">{{ globalAlert.title }}</h4>
            <p class="text-sm">{{ globalAlert.message }}</p>
          </div>
          <button @click="closeGlobalAlert" class="text-gray-500 hover:text-gray-700">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
          </button>
        </div>
      </transition>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-8 items-stretch">
        <!-- Left Side - Switches between Login Card and Register Header -->
        <transition 
          name="slide-fade"
          mode="out-in"
          enter-active-class="transition duration-500 ease-out"
          enter-from-class="transform -translate-x-full opacity-0"
          enter-to-class="transform translate-x-0 opacity-100"
          leave-active-class="transition duration-500 ease-in"
          leave-from-class="transform translate-x-0 opacity-100"
          leave-to-class="transform -translate-x-full opacity-0"
        >
          <div v-if="isLoginView" key="login-card" class="bg-white/95 rounded-2xl border border-green-100 shadow-xl p-6 sm:p-8">
            <div class="flex flex-col h-full">
              <div class="flex items-center justify-center mb-6">
                <img src="/eco-mist-logo.png" alt="Eco-Mist Logo" class="w-16 h-16" />
              </div>
              
              <h3 class="text-xl font-semibold text-green-800 mb-6 text-center">Login to your account</h3>
              
              <!-- Login Form with Improved Validation -->
              <form @submit.prevent="loginUser" class="space-y-6 flex-grow" aria-label="Login Form">
                <div class="space-y-4">
                  <!-- Email Field -->
                  <div class="relative">
                    <label for="login-email" class="sr-only">Email</label>
                    <input 
                      id="login-email"
                      type="email"
                      v-model="loginForm.email"
                      :class="{ 'border-red-500 bg-red-50': loginErrors.email, 'border-green-500 bg-green-50': loginForm.email && !loginErrors.email && loginForm.email.includes('@') }"
                      required
                      class="w-full bg-white border border-green-200 rounded-lg px-4 py-3 text-gray-800 focus:border-green-500 focus:outline-none focus:ring-1 focus:ring-green-500 transition-all"
                      placeholder="Email"
                      aria-invalid="loginErrors.email ? true : false"
                      aria-describedby="login-email-error"
                      :disabled="loading"
                    />
                    <div v-if="loginForm.email && !loginErrors.email && loginForm.email.includes('@')" class="absolute right-3 top-1/2 -translate-y-1/2 text-green-500">
                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                    </div>
                    <p v-if="loginErrors.email" id="login-email-error" class="text-red-500 text-sm mt-1 flex items-center gap-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="flex-shrink-0"><circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/></svg>
                      <span>{{ loginErrors.email }}</span>
                    </p>
                  </div>
                  
                  <!-- Password Field -->
                  <div class="relative">
                    <input 
                      :type="showPassword ? 'text' : 'password'"
                      v-model="loginForm.password"
                      :class="{ 'border-red-500 bg-red-50': loginErrors.password, 'border-green-500 bg-green-50': loginForm.password && !loginErrors.password && loginForm.password.length >= 6 }"
                      required
                      class="w-full bg-white border border-green-200 rounded-lg px-4 py-3 text-gray-800 focus:border-green-500 focus:outline-none focus:ring-1 focus:ring-green-500 transition-all"
                      placeholder="Password"
                      :disabled="loading"
                    />
                    <button 
                      type="button"
                      class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-green-600"
                      @click="togglePassword"
                      :disabled="loading"
                    >
                      <svg v-if="showPassword" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"></path><path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"></path><path d="M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61"></path><line x1="2" x2="22" y1="2" y2="22"></line></svg>
                      <svg v-else xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                    </button>
                    <p v-if="loginErrors.password" class="text-red-500 text-sm mt-1 flex items-center gap-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="flex-shrink-0"><circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/></svg>
                      <span>{{ loginErrors.password }}</span>
                    </p>
                  </div>
                </div>

                <!-- Remember Me with Improved Tooltip -->
                <div class="flex items-center justify-between">
                  <div class="relative group">
                    <label class="flex items-center cursor-pointer">
                      <input type="checkbox" v-model="loginForm.rememberMe" class="w-4 h-4 text-green-600 border-gray-300 rounded focus:ring-green-500" :disabled="loading" />
                      <span class="ml-2 text-sm text-gray-600">Remember me</span>
                    </label>
                    <div class="absolute left-0 -bottom-20 w-64 bg-white text-gray-700 text-xs rounded-lg shadow-lg p-3 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-10 border border-gray-200">
                      <div class="absolute -top-2 left-4 w-4 h-4 bg-white border-t border-l border-gray-200 transform rotate-45"></div>
                      <p class="font-medium mb-1">Session Persistence:</p>
                      <p>When checked, you'll stay logged in even after closing your browser. Uncheck for enhanced security on shared devices.</p>
                    </div>
                  </div>
                  <a href="/reset-password" class="text-sm text-green-600 hover:text-green-800 hover:underline">Forgot password?</a>
                </div>

                <!-- Login Button with Loading State -->
                <button 
                  type="submit" 
                  class="w-full bg-gradient-to-r from-green-600 to-green-500 text-white font-semibold px-6 py-3 rounded-lg hover:-translate-y-1 transition-transform shadow-lg shadow-green-600/20 active:scale-95 touch-manipulation disabled:opacity-70 disabled:cursor-not-allowed disabled:transform-none"
                  :disabled="loading || !loginForm.email || !loginForm.password"
                >
                  <span v-if="!loading">Login</span>
                  <span v-else class="flex items-center justify-center">
                    <svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                      <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Logging in...
                  </span>
                </button>

                <!-- Email Verification Section -->
                <div v-if="showResendVerification" class="mt-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <h4 class="text-blue-800 font-medium mb-2">Email Verification Required</h4>
                  <p class="text-blue-700 text-sm mb-3">Please verify your email address to continue.</p>
                  <button 
                    @click="resendVerification"
                    class="w-full bg-blue-500 text-white font-medium px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors flex items-center justify-center"
                    :disabled="verificationLoading"
                  >
                    <span v-if="!verificationLoading">Resend Verification Email</span>
                    <span v-else class="flex items-center">
                      <svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Sending...
                    </span>
                  </button>
                </div>

                <!-- OAuth Login Options -->
                <div class="relative flex items-center justify-center my-6">
                  <div class="absolute inset-0 flex items-center">
                    <div class="w-full border-t border-gray-300"></div>
                  </div>
                  <div class="relative px-4 bg-white text-sm text-gray-500">Or continue with</div>
                </div>

                <div class="grid grid-cols-1 gap-3">
                  <button 
                    type="button" 
                    @click="loginWithGoogle"
                    class="flex items-center justify-center gap-3 w-full border border-gray-300 bg-white text-gray-700 px-6 py-3 rounded-lg hover:bg-gray-50 transition-colors"
                    :disabled="loading"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 48 48">
                      <path fill="#FFC107" d="M43.611 20.083H42V20H24v8h11.303c-1.649 4.657-6.08 8-11.303 8c-6.627 0-12-5.373-12-12s5.373-12 12-12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4C12.955 4 4 12.955 4 24s8.955 20 20 20s20-8.955 20-20c0-1.341-.138-2.65-.389-3.917z"/>
                      <path fill="#FF3D00" d="m6.306 14.691l6.571 4.819C14.655 15.108 18.961 12 24 12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4C16.318 4 9.656 8.337 6.306 14.691z"/>
                      <path fill="#4CAF50" d="M24 44c5.166 0 9.86-1.977 13.409-5.192l-6.19-5.238A11.91 11.91 0 0 1 24 36c-5.202 0-9.619-3.317-11.283-7.946l-6.522 5.025C9.505 39.556 16.227 44 24 44z"/>
                      <path fill="#1976D2" d="M43.611 20.083H42V20H24v8h11.303a12.04 12.04 0 0 1-4.087 5.571l.003-.002l6.19 5.238C36.971 39.205 44 34 44 24c0-1.341-.138-2.65-.389-3.917z"/>
                    </svg>
                    <span>Sign in with Google</span>
                  </button>
                </div>

                <div class="text-center">
                  <p class="text-sm text-gray-600">
                    Don't have an account? 
                    <button 
                      type="button" 
                      @click="toggleView" 
                      class="text-green-600 hover:text-green-800 font-medium hover:underline"
                      :disabled="loading"
                    >
                      Register
                    </button>
                  </p>
                </div>
              </form>
            </div>
          </div>
          <div v-else key="register-header" class="bg-white/95 rounded-2xl border border-green-100 shadow-xl p-6 sm:p-8 flex flex-col justify-center">
            <h2 class="text-3xl font-bold text-green-800 mb-6">Join Eco-Mist</h2>
            <p class="text-gray-600 mb-8">
              Create an account to access our IoT-driven aeroponics platform. Monitor and control your farming system, 
              optimize resource usage, and maximize your crop yield with our cutting-edge technology.
            </p>
              
            <div class="space-y-6">
              <div class="flex items-start gap-3">
                <div class="flex-shrink-0 w-10 h-10 bg-green-100 rounded-full flex items-center justify-center text-green-600">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 22c1.25-1.25 2.5-2.5 3.5-4.5 1.5 1 2.5 1 4.5.5 2-2 3-4 3-6 0-1-.5-2.5-2-3 0 0 2 0 4 2 0-3.5-2-6.5-2-8 0-.5 0-1 .5-1 .5 0 1 .5 1.5 2 2-3 2.5-4 3-6 .5 2 1.5 3 2.5 5 1-1.5 1.5-3 1.5-4.5.5 1.5 1 3 1 4.5 1-1 2-2 3-2.5 0 1-1 2-1 3 1 .5 2 1 2.5 2-1 1-2 1.5-3 2 1 2 1 4.5 0 6.5-1.5 1-3 1.5-4.5 2 1 1.5 2 3 3 4.5-1.5-.5-3-1-4.5-1.5-1 1-2 2-3 2.5 0-1 .5-2.5 1-3.5-1.5-.5-3-1-4.5-1.5-1 1.5-2 3-3.5 4.5z"></path></svg>
                </div>
                <div>
                  <h3 class="font-semibold text-green-800">Sustainable Farming</h3>
                  <p class="text-sm text-gray-600">Reduce water usage by up to 95% compared to traditional methods</p>
                </div>
              </div>
              
              <div class="flex items-start gap-3">
                <div class="flex-shrink-0 w-10 h-10 bg-green-100 rounded-full flex items-center justify-center text-green-600">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/></svg>
                </div>
                <div>
                  <h3 class="font-semibold text-green-800">Increased Yield</h3>
                  <p class="text-sm text-gray-600">Grow crops up to 3x faster with higher nutrient density</p>
                </div>
              </div>
              
              <div class="flex items-start gap-3">
                <div class="flex-shrink-0 w-10 h-10 bg-green-100 rounded-full flex items-center justify-center text-green-600">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3v18h18"></path><path d="m19 9-5 5-4-4-3 3"></path></svg>
                </div>
                <div>
                  <h3 class="font-semibold text-green-800">Data-Driven Decisions</h3>
                  <p class="text-sm text-gray-600">Make informed choices based on real-time analytics</p>
                </div>
              </div>
            </div>
            <div class="mt-8">
              <button 
                @click="toggleView" 
                class="text-green-600 hover:text-green-800 flex items-center gap-2 font-medium hover:underline"
                :disabled="loading"
              >
                <span>Already have an account? Login</span>
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
              </button>
            </div>
          </div>
        </transition>
        
        <!-- Right Side - Switches between Login Header and Register Card -->
        <transition 
          name="slide-fade"
          mode="out-in"
          enter-active-class="transition duration-500 ease-out"
          enter-from-class="transform translate-x-full opacity-0"
          enter-to-class="transform translate-x-0 opacity-100"
          leave-active-class="transition duration-500 ease-in"
          leave-from-class="transform translate-x-0 opacity-100"
          leave-to-class="transform translate-x-full opacity-0"
        >
          <div v-if="isLoginView" key="login-header" class="bg-white/95 rounded-2xl border border-green-100 shadow-xl p-6 sm:p-8 flex flex-col justify-center">
            <h2 class="text-3xl font-bold text-green-800 mb-6">Welcome Back</h2>
            <p class="text-gray-600 mb-8">
              Log in to access your Eco-Mist dashboard and monitor your aeroponics system in real-time. 
              Get insights, control your environment, and maximize your crop yield with our advanced IoT platform.
            </p>
              
            <div class="space-y-6">
              <div class="flex items-start gap-3">
                <div class="flex-shrink-0 w-10 h-10 bg-green-100 rounded-full flex items-center justify-center text-green-600">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3.34 19a10 10 0 1 1 17.32 0"></path><path d="M16.15 13.8a5.5 5.5 0 1 0-8.3 0"></path><path d="M12 3v4"></path><path d="M8 17v4"></path><path d="M16 17v4"></path></svg>
                </div>
                <div>
                  <h3 class="font-semibold text-green-800">Real-time Monitoring</h3>
                  <p class="text-sm text-gray-600">Access live data from your sensors and control systems</p>
                </div>
              </div>
              
              <div class="flex items-start gap-3">
                <div class="flex-shrink-0 w-10 h-10 bg-green-100 rounded-full flex items-center justify-center text-green-600">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                </div>
                <div>
                  <h3 class="font-semibold text-green-800">System Control</h3>
                  <p class="text-sm text-gray-600">Adjust settings and automate your growing environment</p>
                </div>
              </div>
              
              <div class="flex items-start gap-3">
                <div class="flex-shrink-0 w-10 h-10 bg-green-100 rounded-full flex items-center justify-center text-green-600">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3v18h18"></path><path d="m19 9-5 5-4-4-3 3"></path></svg>
                </div>
                <div>
                  <h3 class="font-semibold text-green-800">Analytics Dashboard</h3>
                  <p class="text-sm text-gray-600">View trends and insights to optimize your crop yield</p>
                </div>
              </div>
            </div>
            <div class="mt-8">
              <button 
                @click="toggleView" 
                class="text-green-600 hover:text-green-800 flex items-center gap-2 font-medium hover:underline"
                :disabled="loading"
              >
                <span>Need an account? Register now</span>
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
              </button>
            </div>
          </div>
          <div v-else key="register-card" class="bg-white/95 rounded-2xl border border-green-100 shadow-xl p-6 sm:p-8">
            <div class="flex flex-col h-full">
              <div class="flex items-center justify-center mb-6">
                <img src="/eco-mist-logo.png" alt="Eco-Mist Logo" class="w-16 h-16" />
              </div>
              
              <h3 class="text-xl font-semibold text-green-800 mb-6 text-center">Create your account</h3>
              
              <!-- Registration Form with Enhanced Validation -->
              <form @submit.prevent="registerUser" class="space-y-6 flex-grow">
                <div class="space-y-4">
                  <!-- Username Field -->
                  <div class="relative">
                    <input 
                      type="text" 
                      v-model="registerForm.username" 
                      :class="{ 'border-red-500 bg-red-50': registerErrors.username, 'border-green-500 bg-green-50': registerForm.username && !registerErrors.username && registerForm.username.length >= 3 }"
                      required
                      class="w-full bg-white border border-green-200 rounded-lg px-4 py-3 text-gray-800 focus:border-green-500 focus:outline-none focus:ring-1 focus:ring-green-500 transition-all"
                      placeholder="Username"
                      :disabled="loading"
                    />
                    <p v-if="registerErrors.username" class="text-red-500 text-sm mt-1 flex items-center gap-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="flex-shrink-0"><circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/></svg>
                      <span>{{ registerErrors.username }}</span>
                    </p>
                  </div>

                  <!-- Email Field -->
                  <div class="relative">
                    <input 
                      type="email" 
                      v-model="registerForm.email" 
                      :class="{ 'border-red-500 bg-red-50': registerErrors.email, 'border-green-500 bg-green-50': registerForm.email && !registerErrors.email && registerForm.email.includes('@') }"
                      required
                      class="w-full bg-white border border-green-200 rounded-lg px-4 py-3 text-gray-800 focus:border-green-500 focus:outline-none focus:ring-1 focus:ring-green-500 transition-all"
                      placeholder="Email"
                      :disabled="loading"
                    />
                    <p v-if="registerErrors.email" class="text-red-500 text-sm mt-1 flex items-center gap-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="flex-shrink-0"><circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/></svg>
                      <span>{{ registerErrors.email }}</span>
                    </p>
                  </div>

                  <!-- Profile Picture Upload -->
                  <div class="relative">
                    <div class="flex items-center gap-4">
                      <div class="relative w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center overflow-hidden border-2 border-green-200">
                        <img v-if="profileImagePreview" :src="profileImagePreview" alt="Profile Preview" class="w-full h-full object-cover" />
                        <svg v-else xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-gray-400"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                      </div>
                      <div class="flex-1">
                        <label for="profile-upload" class="block text-sm font-medium text-gray-700 mb-1">Profile Picture (Optional)</label>
                        <div class="flex items-center gap-2">
                          <label class="flex-1">
                            <span class="sr-only">Choose profile photo</span>
                            <input 
                              id="profile-upload" 
                              type="file" 
                              accept="image/*" 
                              @change="handleProfileImageChange" 
                              class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-medium file:bg-green-50 file:text-green-700 hover:file:bg-green-100"
                              :disabled="loading"
                            />
                          </label>
                          <button 
                            v-if="profileImagePreview" 
                            type="button" 
                            @click="clearProfileImage" 
                            class="p-1 rounded-md text-gray-400 hover:text-red-500"
                            :disabled="loading"
                          >
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"></path><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"></path><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"></path><line x1="10" x2="10" y1="11" y2="17"></line><line x1="14" x2="14" y1="11" y2="17"></line></svg>
                          </button>
                        </div>
                        <p class="text-xs text-gray-500 mt-1">JPG, PNG or GIF (Max. 2MB)</p>
                      </div>
                    </div>
                    <p v-if="profileImageError" class="text-red-500 text-sm mt-1">{{ profileImageError }}</p>
                  </div>

                  <!-- Password Field with Strength Meter -->
                  <div class="relative">
                    <input 
                      :type="showPassword ? 'text' : 'password'"
                      v-model="registerForm.password" 
                      :class="{ 'border-red-500 bg-red-50': registerErrors.password }"
                      required
                      class="w-full bg-white border border-green-200 rounded-lg px-4 py-3 text-gray-800 focus:border-green-500 focus:outline-none focus:ring-1 focus:ring-green-500 transition-all"
                      placeholder="Password"
                      :disabled="loading"
                    />
                    <button 
                      type="button"
                      class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-green-600"
                      @click="togglePassword"
                      :disabled="loading"
                    >
                      <svg v-if="showPassword" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"></path><path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"></path><path d="M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61"></path><line x1="2" x2="22" y1="2" y2="22"></line></svg>
                      <svg v-else xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                    </button>
                    <p v-if="registerErrors.password" class="text-red-500 text-sm mt-1 flex items-center gap-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="flex-shrink-0"><circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/></svg>
                      <span>{{ registerErrors.password }}</span>
                    </p>
                    
                    <!-- Enhanced Password Strength Meter -->
                    <div v-if="registerForm.password" class="mt-2">
                      <div class="flex items-center gap-2 mb-1">
                        <div class="h-2 flex-1 bg-gray-200 rounded-full overflow-hidden">
                          <div 
                            :class="[
                              'h-full rounded-full transition-all duration-300',
                              passwordStrength.score === 0 ? 'bg-red-500 w-[20%]' :
                              passwordStrength.score === 1 ? 'bg-orange-500 w-[40%]' :
                              passwordStrength.score === 2 ? 'bg-yellow-500 w-[60%]' :
                              passwordStrength.score === 3 ? 'bg-green-400 w-[80%]' : 'bg-green-600 w-full'
                            ]"
                          ></div>
                        </div>
                        <span class="text-xs font-medium" :class="{
                          'text-red-600': passwordStrength.score === 0,
                          'text-orange-600': passwordStrength.score === 1,
                          'text-yellow-600': passwordStrength.score === 2,
                          'text-green-600': passwordStrength.score >= 3
                        }">
                          {{ 
                            passwordStrength.score === 0 ? 'Very Weak' :
                            passwordStrength.score === 1 ? 'Weak' :
                            passwordStrength.score === 2 ? 'Fair' :
                            passwordStrength.score === 3 ? 'Good' : 'Strong'
                          }}
                        </span>
                      </div>
                      <p class="text-xs text-gray-600">{{ passwordStrength.feedback }}</p>
                    </div>
                  </div>

                  <!-- Confirm Password Field -->
                  <div class="relative">
                    <input 
                      :type="showPassword ? 'text' : 'password'"
                      v-model="registerForm.confirmPassword" 
                      :class="{ 'border-red-500 bg-red-50': registerErrors.confirmPassword, 'border-green-500 bg-green-50': registerForm.confirmPassword && !registerErrors.confirmPassword && registerForm.confirmPassword === registerForm.password }"
                      required
                      class="w-full bg-white border border-green-200 rounded-lg px-4 py-3 text-gray-800 focus:border-green-500 focus:outline-none focus:ring-1 focus:ring-green-500 transition-all"
                      placeholder="Confirm Password"
                      :disabled="loading"
                    />
                    <p v-if="registerErrors.confirmPassword" class="text-red-500 text-sm mt-1 flex items-center gap-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="flex-shrink-0"><circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/></svg>
                      <span>{{ registerErrors.confirmPassword }}</span>
                    </p>
                  </div>
                </div>

                <!-- Terms Agreement with Modal -->
                <div class="flex items-center">
                  <input 
                    type="checkbox" 
                    v-model="registerForm.agreeToTerms" 
                    id="terms" 
                    class="w-4 h-4 text-green-600 border-gray-300 rounded focus:ring-green-500"
                    :disabled="loading"
                  />
                  <label for="terms" class="ml-2 text-sm text-gray-600">
                    I agree to the 
                    <button 
                      type="button" 
                      @click="showTermsModal = true" 
                      class="text-green-600 hover:text-green-800 hover:underline"
                      :disabled="loading"
                    >
                      Terms of Service
                    </button> 
                    and 
                    <button 
                      type="button" 
                      @click="showPrivacyModal = true" 
                      class="text-green-600 hover:text-green-800 hover:underline"
                      :disabled="loading"
                    >
                      Privacy Policy
                    </button>
                  </label>
                </div>

                <!-- Register Button with Loading State -->
                <button 
                  type="submit" 
                  class="w-full bg-gradient-to-r from-green-600 to-green-500 text-white font-semibold px-6 py-3 rounded-lg hover:-translate-y-1 transition-transform shadow-lg shadow-green-600/20 active:scale-95 touch-manipulation disabled:opacity-70 disabled:cursor-not-allowed disabled:transform-none"
                  :disabled="loading || !registerForm.agreeToTerms"
                >
                  <span v-if="!loading">Create Account</span>
                  <span v-else class="flex items-center justify-center">
                    <svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                      <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Creating account...
                  </span>
                </button>

                <!-- OAuth Registration Options -->
                <div class="relative flex items-center justify-center my-6">
                  <div class="absolute inset-0 flex items-center">
                    <div class="w-full border-t border-gray-300"></div>
                  </div>
                  <div class="relative px-4 bg-white text-sm text-gray-500">Or sign up with</div>
                </div>

                <div class="grid grid-cols-1 gap-3">
                  <button 
                    type="button" 
                    @click="registerWithGoogle"
                    class="flex items-center justify-center gap-3 w-full border border-gray-300 bg-white text-gray-700 px-6 py-3 rounded-lg hover:bg-gray-50 transition-colors"
                    :disabled="loading"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 48 48">
                      <path fill="#FFC107" d="M43.611 20.083H42V20H24v8h11.303c-1.649 4.657-6.08 8-11.303 8c-6.627 0-12-5.373-12-12s5.373-12 12-12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4C12.955 4 4 12.955 4 24s8.955 20 20 20s20-8.955 20-20c0-1.341-.138-2.65-.389-3.917z"/>
                      <path fill="#FF3D00" d="m6.306 14.691l6.571 4.819C14.655 15.108 18.961 12 24 12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4C16.318 4 9.656 8.337 6.306 14.691z"/>
                      <path fill="#4CAF50" d="M24 44c5.166 0 9.86-1.977 13.409-5.192l-6.19-5.238A11.91 11.91 0 0 1 24 36c-5.202 0-9.619-3.317-11.283-7.946l-6.522 5.025C9.505 39.556 16.227 44 24 44z"/>
                      <path fill="#1976D2" d="M43.611 20.083H42V20H24v8h11.303a12.04 12.04 0 0 1-4.087 5.571l.003-.002l6.19 5.238C36.971 39.205 44 34 44 24c0-1.341-.138-2.65-.389-3.917z"/>
                    </svg>
                    <span>Sign up with Google</span>
                  </button>
                </div>

                <div class="text-center">
                  <p class="text-sm text-gray-600">
                    Already have an account? 
                    <button 
                      type="button" 
                      @click="toggleView" 
                      class="text-green-600 hover:text-green-800 font-medium hover:underline"
                      :disabled="loading"
                    >
                      Login
                    </button>
                  </p>
                </div>
              </form>
            </div>
          </div>
        </transition>
      </div>
    </div>

    <!-- Terms of Service Modal -->
    <transition
      enter-active-class="transition duration-300 ease-out"
      enter-from-class="transform scale-95 opacity-0"
      enter-to-class="transform scale-100 opacity-100"
      leave-active-class="transition duration-200 ease-in"
      leave-from-class="transform scale-100 opacity-100"
      leave-to-class="transform scale-95 opacity-0"
    >
      <div v-if="showTermsModal" class="fixed inset-0 z-50 overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
        <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
          <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" aria-hidden="true" @click="showTermsModal = false"></div>
          <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
          <div class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
            <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
              <div class="sm:flex sm:items-start">
                <div class="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left">
                  <h3 class="text-lg leading-6 font-medium text-gray-900" id="modal-title">Terms of Service</h3>
                  <div class="mt-4 max-h-96 overflow-y-auto pr-2">
                    <p class="text-sm text-gray-500 mb-4">Last updated: May 7, 2025</p>
                    <h4 class="text-md font-medium text-gray-800 mb-2">1. Acceptance of Terms</h4>
                    <p class="text-sm text-gray-600 mb-4">By accessing or using Eco-Mist's services, you agree to be bound by these Terms of Service and all applicable laws and regulations.</p>
                    
                    <h4 class="text-md font-medium text-gray-800 mb-2">2. Use of Service</h4>
                    <p class="text-sm text-gray-600 mb-4">You agree to use the service only for lawful purposes and in accordance with these Terms. You are responsible for maintaining the confidentiality of your account information.</p>
                    
                    <h4 class="text-md font-medium text-gray-800 mb-2">3. Data Collection and Privacy</h4>
                    <p class="text-sm text-gray-600 mb-4">We collect and process personal data as described in our Privacy Policy. By using our services, you consent to such processing and you warrant that all data provided by you is accurate.</p>
                    
                    <h4 class="text-md font-medium text-gray-800 mb-2">4. Intellectual Property</h4>
                    <p class="text-sm text-gray-600 mb-4">All content, features, and functionality of the Eco-Mist service are owned by Eco-Mist and are protected by international copyright, trademark, patent, trade secret, and other intellectual property laws.</p>
                    
                    <h4 class="text-md font-medium text-gray-800 mb-2">5. Termination</h4>
                    <p class="text-sm text-gray-600 mb-4">We may terminate or suspend your account and access to the service immediately, without prior notice or liability, for any reason whatsoever, including without limitation if you breach the Terms.</p>
                    
                    <h4 class="text-md font-medium text-gray-800 mb-2">6. Limitation of Liability</h4>
                    <p class="text-sm text-gray-600 mb-4">In no event shall Eco-Mist be liable for any indirect, incidental, special, consequential or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses.</p>
                    
                    <h4 class="text-md font-medium text-gray-800 mb-2">7. Changes to Terms</h4>
                    <p class="text-sm text-gray-600 mb-4">We reserve the right to modify or replace these Terms at any time. It is your responsibility to check the Terms periodically for changes.</p>
                    
                    <h4 class="text-md font-medium text-gray-800 mb-2">8. Governing Law</h4>
                    <p class="text-sm text-gray-600 mb-4">These Terms shall be governed by the laws of the jurisdiction in which Eco-Mist operates, without regard to its conflict of law provisions.</p>
                    
                    <h4 class="text-md font-medium text-gray-800 mb-2">9. Contact Us</h4>
                    <p class="text-sm text-gray-600">If you have any questions about these Terms, please contact us at support@eco-mist.com.</p>
                  </div>
                </div>
              </div>
            </div>
            <div class="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
              <button 
                type="button" 
                class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-green-600 text-base font-medium text-white hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 sm:ml-3 sm:w-auto sm:text-sm"
                @click="acceptTerms"
              >
                Accept
              </button>
              <button 
                type="button" 
                class="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm"
                @click="showTermsModal = false"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      </div>
    </transition>

    <!-- Privacy Policy Modal -->
    <transition
      enter-active-class="transition duration-300 ease-out"
      enter-from-class="transform scale-95 opacity-0"
      enter-to-class="transform scale-100 opacity-100"
      leave-active-class="transition duration-200 ease-in"
      leave-from-class="transform scale-100 opacity-100"
      leave-to-class="transform scale-95 opacity-0"
    >
      <div v-if="showPrivacyModal" class="fixed inset-0 z-50 overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
        <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
          <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" aria-hidden="true" @click="showPrivacyModal = false"></div>
          <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
          <div class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
            <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
              <div class="sm:flex sm:items-start">
                <div class="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left">
                  <h3 class="text-lg leading-6 font-medium text-gray-900" id="modal-title">Privacy Policy</h3>
                  <div class="mt-4 max-h-96 overflow-y-auto pr-2">
                    <p class="text-sm text-gray-500 mb-4">Last updated: May 7, 2025</p>
                    <h4 class="text-md font-medium text-gray-800 mb-2">1. Information We Collect</h4>
                    <p class="text-sm text-gray-600 mb-4">We collect personal information that you provide to us, including but not limited to your name, email address, and profile picture. We also collect data about your usage of our services and information from your device.</p>
                    
                    <h4 class="text-md font-medium text-gray-800 mb-2">2. How We Use Your Information</h4>
                    <p class="text-sm text-gray-600 mb-4">We use the information we collect to provide, maintain, and improve our services, to communicate with you, and to develop new products and services. We may also use your information to personalize your experience and to protect our services.</p>
                    
                    <h4 class="text-md font-medium text-gray-800 mb-2">3. Information Sharing</h4>
                    <p class="text-sm text-gray-600 mb-4">We do not share your personal information with companies, organizations, or individuals outside of Eco-Mist except in the following cases: with your consent, for legal reasons, or with our service providers who process data on our behalf.</p>
                    
                    <h4 class="text-md font-medium text-gray-800 mb-2">4. Data Security</h4>
                    <p class="text-sm text-gray-600 mb-4">We work hard to protect your information from unauthorized access, alteration, disclosure, or destruction. We implement security measures such as encryption, secure servers, and regular security reviews.</p>
                    
                    <h4 class="text-md font-medium text-gray-800 mb-2">5. Your Rights</h4>
                    <p class="text-sm text-gray-600 mb-4">Depending on your location, you may have certain rights regarding your personal data, such as the right to access, correct, delete, or restrict processing of your data. You may also have the right to object to processing and the right to data portability.</p>
                    
                    <h4 class="text-md font-medium text-gray-800 mb-2">6. Changes to This Policy</h4>
                    <p class="text-sm text-gray-600 mb-4">We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Last updated" date.</p>
                    
                    <h4 class="text-md font-medium text-gray-800 mb-2">7. Contact Us</h4>
                    <p class="text-sm text-gray-600">If you have any questions about this Privacy Policy, please contact us at privacy@eco-mist.com.</p>
                  </div>
                </div>
              </div>
            </div>
            <div class="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
              <button 
                type="button" 
                class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-green-600 text-base font-medium text-white hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 sm:ml-3 sm:w-auto sm:text-sm"
                @click="acceptPrivacy"
              >
                Accept
              </button>
              <button 
                type="button" 
                class="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm"
                @click="showPrivacyModal = false"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      </div>
    </transition>

    <!-- Footer -->
    <footer class="mt-12 px-4 sm:px-6 py-8 relative z-10">
      <div class="max-w-7xl mx-auto bg-white/95 rounded-2xl border border-green-100 shadow-lg p-6">
        <div class="text-center">
          <p class="text-gray-600">© 2025 Eco-Mist. All rights reserved.</p>
          <div class="flex justify-center space-x-6 mt-4">
            <a href="#" class="text-gray-600 hover:text-green-600 transition-colors text-sm">Privacy Policy</a>
            <a href="#" class="text-gray-600 hover:text-green-600 transition-colors text-sm">Terms of Service</a>
            <a href="#" class="text-gray-600 hover:text-green-600 transition-colors text-sm">Contact Support</a>
          </div>
        </div>
      </div>
    </footer>
  </div>
</template>

<script setup>
import { ref, reactive, watch, computed, onMounted } from "vue";
import { 
  getAuth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile,
  sendEmailVerification,
  signOut,
  GoogleAuthProvider,
  signInWithPopup,
  setPersistence, 
  browserLocalPersistence,
  browserSessionPersistence,
  updatePassword,
  EmailAuthProvider,
  reauthenticateWithCredential
} from "firebase/auth";
import { useRouter } from "vue-router";
import { db, storage } from "../../firebase";
import { doc, setDoc, getDoc, updateDoc, increment } from "firebase/firestore";
import { ref as storageRef, uploadBytes, getDownloadURL } from "firebase/storage";
import { useField, useForm } from "vee-validate";
import * as yup from "yup";
import { useToast } from "vue-toastification";
import zxcvbn from "zxcvbn"; // For password strength calculation

// Initialize toast
const toast = useToast();

// View state
const isLoginView = ref(true);
const loading = ref(false);
const verificationLoading = ref(false);
const showPassword = ref(false);
const showResendVerification = ref(false);
const mobileMenuOpen = ref(false);
const showTermsModal = ref(false);
const showPrivacyModal = ref(false);
const profileImagePreview = ref(null);
const profileImageFile = ref(null);
const profileImageError = ref('');
const loginAttempts = ref(0);
const lastLoginAttempt = ref(null);
const accountLocked = ref(false);
const lockoutEndTime = ref(null);

// Global alert system
const globalAlert = reactive({
  show: false,
  type: 'success', // 'success' or 'error'
  title: '',
  message: '',
  timeout: null
});

// Login form
const loginForm = reactive({
  email: "",
  password: "",
  rememberMe: false
});

// Register form
const registerForm = reactive({
  username: "",
  email: "",
  password: "",
  confirmPassword: "",
  agreeToTerms: false
});

// Form errors
const loginErrors = reactive({
  email: "",
  password: ""
});

const registerErrors = reactive({
  username: "",
  email: "",
  password: "",
  confirmPassword: ""
});

// Router and Auth
const router = useRouter();
const auth = getAuth();

// Toggle between login and register views
const toggleView = () => {
  isLoginView.value = !isLoginView.value;
  // Reset errors when switching views
  loginErrors.email = "";
  loginErrors.password = "";
  registerErrors.username = "";
  registerErrors.email = "";
  registerErrors.password = "";
  registerErrors.confirmPassword = "";
  showResendVerification.value = false;
  
  // Reset forms
  if (isLoginView.value) {
    loginForm.email = "";
    loginForm.password = "";
  } else {
    registerForm.username = "";
    registerForm.email = "";
    registerForm.password = "";
    registerForm.confirmPassword = "";
    registerForm.agreeToTerms = false;
    profileImagePreview.value = null;
    profileImageFile.value = null;
    profileImageError.value = '';
  }
};

// Toggle password visibility
const togglePassword = () => {
  showPassword.value = !showPassword.value;
};

// Mobile menu functions
const toggleMobileMenu = () => {
  mobileMenuOpen.value = !mobileMenuOpen.value;
  if (mobileMenuOpen.value) {
    document.querySelector("#mobile-menu").focus();
  }
};

const closeMobileMenu = () => {
  mobileMenuOpen.value = false;
};

// Global alert functions
const showAlert = (type, title, message, duration = 5000) => {
  // Clear any existing timeout
  if (globalAlert.timeout) {
    clearTimeout(globalAlert.timeout);
  }
  
  // Set alert data
  globalAlert.type = type;
  globalAlert.title = title;
  globalAlert.message = message;
  globalAlert.show = true;
  
  // Auto-hide after duration
  globalAlert.timeout = setTimeout(() => {
    closeGlobalAlert();
  }, duration);
};

const closeGlobalAlert = () => {
  globalAlert.show = false;
};

// Check for account lockout
const checkAccountLockout = () => {
  if (!accountLocked.value) return false;
  
  const now = new Date();
  if (now < lockoutEndTime.value) {
    const remainingMinutes = Math.ceil((lockoutEndTime.value - now) / 60000);
    loginErrors.email = `Account temporarily locked. Try again in ${remainingMinutes} minute${remainingMinutes > 1 ? 's' : ''}.`;
    return true;
  } else {
    // Reset lockout if time has passed
    accountLocked.value = false;
    loginAttempts.value = 0;
    return false;
  }
};

// Login function with improved error handling and lockout
const loginUser = async () => {
  // Reset errors
  loginErrors.email = "";
  loginErrors.password = "";
  
  // Check for account lockout
  if (checkAccountLockout()) return;
  
  // Basic validation
  if (!loginForm.email) {
    loginErrors.email = "Email is required";
    return;
  }
  
  if (!loginForm.password) {
    loginErrors.password = "Password is required";
    return;
  }
  
  loading.value = true;
  try {
    // Track login attempts
    loginAttempts.value++;
    lastLoginAttempt.value = new Date();
    
    // Set persistence based on remember me option
    await setPersistence(auth, 
      loginForm.rememberMe ? browserLocalPersistence : browserSessionPersistence
    );
    
    const userCredential = await signInWithEmailAndPassword(
      auth, 
      loginForm.email, 
      loginForm.password
    );
    const user = userCredential.user;

    // Reset login attempts on successful login
    loginAttempts.value = 0;

    if (!user.emailVerified) {
      loginErrors.email = "Please verify your email before logging in.";
      showResendVerification.value = true;
      await signOut(auth);
      showAlert('error', 'Email Not Verified', 'Please check your inbox and verify your email address before logging in.');
      return;
    }

    const userRef = doc(db, "users", user.uid);
    const userSnap = await getDoc(userRef);

    if (userSnap.exists()) {
      const userData = userSnap.data();
      
      if (userData.status === "deactivated") {
        loginErrors.email = "Your account has been deactivated. Please contact support.";
        await signOut(auth);
        showAlert('error', 'Account Deactivated', 'Your account has been deactivated. Please contact our support team for assistance.');
        return;
      }

      // Update last login timestamp
      await updateDoc(userRef, {
        lastLogin: new Date().toISOString(),
        loginCount: increment(1)
      });

      localStorage.setItem('userRole', userData.role);
      showAlert('success', 'Login Successful', 'Welcome back! Redirecting to your dashboard...');
      
      // Redirect after a short delay to show the success message
      setTimeout(() => {
        router.push(userData.role === "admin" ? "/admin-dashboard" : "/dashboard");
      }, 1500);
    } else {
      loginErrors.email = "User data not found. Please contact support.";
      showAlert('error', 'Account Error', 'We couldn\'t find your account data. Please contact support.');
    }
  } catch (error) {
    handleLoginError(error);
    
    // Implement account lockout after multiple failed attempts
    if (loginAttempts.value >= 5) {
      accountLocked.value = true;
      // Lock account for 15 minutes
      const lockoutTime = new Date();
      lockoutTime.setMinutes(lockoutTime.getMinutes() + 15);
      lockoutEndTime.value = lockoutTime;
      
      loginErrors.email = `Too many failed attempts. Account locked for 15 minutes.`;
      showAlert('error', 'Account Temporarily Locked', 'Too many failed login attempts. Your account has been temporarily locked for 15 minutes for security reasons.');
    }
  } finally {
    loading.value = false;
  }
};

const handleLoginError = (error) => {
  console.error("Login error:", error.code, error.message);
  
  switch (error.code) {
    case 'auth/user-not-found':
      loginErrors.email = "No account found with this email. Please register.";
      showAlert('error', 'Account Not Found', 'We couldn\'t find an account with this email address. Please check your email or register for a new account.');
      break;
    case 'auth/wrong-password':
      loginErrors.password = "Incorrect password. Please try again.";
      showAlert('error', 'Authentication Failed', 'The password you entered is incorrect. Please try again or reset your password.');
      break;
    case 'auth/too-many-requests':
      loginErrors.email = "Too many failed login attempts. Please try again later.";
      showAlert('error', 'Too Many Attempts', 'Access to this account has been temporarily disabled due to many failed login attempts. Try again later or reset your password.');
      break;
    case 'auth/network-request-failed':
      showAlert('error', 'Network Error', 'A network error occurred. Please check your internet connection and try again.');
      break;
    default:
      loginErrors.email = "An unexpected error occurred. Please try again later.";
      showAlert('error', 'Login Failed', 'An unexpected error occurred. Please try again later.');
      console.error("Server Error:", error); // Log the error for debugging
  }
};

// Google login with improved error handling and profile data fetching
const loginWithGoogle = async () => {
  loading.value = true;
  try {
    const provider = new GoogleAuthProvider();
    // Request additional scopes for more profile data
    provider.addScope('https://www.googleapis.com/auth/userinfo.profile');
    
    const result = await signInWithPopup(auth, provider);
    const user = result.user;
    
    // Get the OAuth access token
    const credential = GoogleAuthProvider.credentialFromResult(result);
    const token = credential.accessToken;

    const userRef = doc(db, "users", user.uid);
    const userSnap = await getDoc(userRef);

    if (userSnap.exists()) {
      const userData = userSnap.data();
      
      if (userData.status === "deactivated") {
        loginErrors.email = "Your account has been deactivated. Please contact support.";
        await signOut(auth);
        showAlert('error', 'Account Deactivated', 'Your account has been deactivated. Please contact our support team for assistance.');
        return;
      }

      // Update last login and profile data if needed
      await updateDoc(userRef, {
        lastLogin: new Date().toISOString(),
        loginCount: increment(1),
        // Update profile picture if it exists and is different
        ...(user.photoURL && user.photoURL !== userData.photoURL ? { photoURL: user.photoURL } : {})
      });
      
      localStorage.setItem('userRole', userData.role);
      showAlert('success', 'Login Successful', 'Welcome back! Redirecting to your dashboard...');
      
      setTimeout(() => {
        router.push(userData.role === "admin" ? "/admin-dashboard" : "/dashboard");
      }, 1500);
    } else {
      // If user doesn't exist in Firestore yet, create a new record
      await setDoc(userRef, {
        username: user.displayName || 'User',
        email: user.email,
        photoURL: user.photoURL || null,
        role: "user",
        status: "active",
        createdAt: new Date().toISOString(),
        lastLogin: new Date().toISOString(),
        loginCount: 1,
        authProvider: "google"
      });
      
      localStorage.setItem('userRole', "user");
      showAlert('success', 'Account Created', 'Your account has been created successfully! Redirecting to your dashboard...');
      
      setTimeout(() => {
        router.push("/dashboard");
      }, 1500);
    }
  } catch (error) {
    console.error("Google Sign-In Error:", error);
    
    if (error.code === 'auth/popup-closed-by-user') {
      showAlert('error', 'Authentication Cancelled', 'The Google sign-in was cancelled. Please try again.');
    } else if (error.code === 'auth/popup-blocked') {
      showAlert('error', 'Popup Blocked', 'The sign-in popup was blocked by your browser. Please allow popups for this site and try again.');
    } else {
      loginErrors.email = "Google Sign-In failed. Please try again.";
      showAlert('error', 'Authentication Failed', 'Google sign-in failed. Please try again or use email login.');
    }
  } finally {
    loading.value = false;
  }
};

// Handle profile image upload
const handleProfileImageChange = (event) => {
  const file = event.target.files[0];
  profileImageError.value = '';
  
  if (!file) {
    profileImageFile.value = null;
    profileImagePreview.value = null;
    return;
  }
  
  // Validate file type
  const validTypes = ['image/jpeg', 'image/png', 'image/gif'];
  if (!validTypes.includes(file.type)) {
    profileImageError.value = 'Please select a valid image file (JPEG, PNG, or GIF)';
    event.target.value = null;
    return;
  }
  
  // Validate file size (max 2MB)
  if (file.size > 2 * 1024 * 1024) {
    profileImageError.value = 'Image size must be less than 2MB';
    event.target.value = null;
    return;
  }
  
  profileImageFile.value = file;
  
  // Create preview
  const reader = new FileReader();
  reader.onload = (e) => {
    profileImagePreview.value = e.target.result;
  };
  reader.readAsDataURL(file);
};

const clearProfileImage = () => {
  profileImageFile.value = null;
  profileImagePreview.value = null;
  profileImageError.value = '';
  // Clear the file input
  const fileInput = document.getElementById('profile-upload');
  if (fileInput) fileInput.value = '';
};

// Register function with improved validation and profile image upload
const validateRegisterForm = () => {
  let isValid = true;
  registerErrors.username = "";
  registerErrors.email = "";
  registerErrors.password = "";
  registerErrors.confirmPassword = "";
  
  // Username validation
  if (!registerForm.username || registerForm.username.trim().length < 3) {
    registerErrors.username = "Username must be at least 3 characters";
    isValid = false;
  } else if (registerForm.username.trim().length > 30) {
    registerErrors.username = "Username must be less than 30 characters";
    isValid = false;
  }
  
  // Email validation
  if (!registerForm.email || !/^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$/.test(registerForm.email)) {
    registerErrors.email = "Please enter a valid email";
    isValid = false;
  }
  
  // Password validation
  if (!registerForm.password) {
    registerErrors.password = "Password is required";
    isValid = false;
  } else if (registerForm.password.length < 8) {
    registerErrors.password = "Password must be at least 8 characters";
    isValid = false;
  } else if (!/[A-Z]/.test(registerForm.password)) {
    registerErrors.password = "Password must contain at least one uppercase letter";
    isValid = false;
  } else if (!/[0-9]/.test(registerForm.password)) {
    registerErrors.password = "Password must contain at least one number";
    isValid = false;
  } else if (!/[!@#$%^&*(),.?":{}|<>]/.test(registerForm.password)) {
    registerErrors.password = "Password must contain at least one special character";
    isValid = false;
  }
  
  // Confirm password validation
  if (registerForm.password !== registerForm.confirmPassword) {
    registerErrors.confirmPassword = "Passwords do not match";
    isValid = false;
  }
  
  // Terms agreement validation
  if (!registerForm.agreeToTerms) {
    showAlert('error', 'Terms Required', 'You must agree to the Terms of Service and Privacy Policy to create an account.');
    isValid = false;
  }
  
  return isValid;
};

const registerUser = async () => {
  if (!validateRegisterForm()) return;
  
  loading.value = true;
  try {
    // Create user account
    const userCredential = await createUserWithEmailAndPassword(auth, registerForm.email, registerForm.password);
    const user = userCredential.user;
    
    // Upload profile image if provided
    let photoURL = null;
    if (profileImageFile.value) {
      const imageRef = storageRef(storage, `profile_images/${user.uid}`);
      await uploadBytes(imageRef, profileImageFile.value);
      photoURL = await getDownloadURL(imageRef);
    }
    
    // Update user profile
    await updateProfile(user, { 
      displayName: registerForm.username,
      photoURL: photoURL
    });
    
    // Send email verification
    await sendEmailVerification(user);
    
    // Create user document in Firestore
    await setDoc(doc(db, "users", user.uid), {
      username: registerForm.username,
      email: registerForm.email,
      photoURL: photoURL,
      role: "user",
      status: "active",
      createdAt: new Date().toISOString(),
      emailVerified: false,
      authProvider: "email",
      loginCount: 0
    });
    
    await signOut(auth);
    toggleView(); // Switch to login view
    showAlert('success', 'Registration Successful', 'Your account has been created! Please check your email to verify your account before logging in.');
  } catch (error) {
    handleRegisterError(error);
  } finally {
    loading.value = false;
  }
};

const handleRegisterError = (error) => {
  console.error("Registration error:", error.code, error.message);
  
  switch (error.code) {
    case 'auth/email-already-in-use':
      registerErrors.email = "Email is already registered";
      showAlert('error', 'Email Already Registered', 'This email address is already in use. Please try logging in or use a different email.');
      break;
    case 'auth/invalid-email':
      registerErrors.email = "Invalid email format";
      showAlert('error', 'Invalid Email', 'Please enter a valid email address.');
      break;
    case 'auth/weak-password':
      registerErrors.password = "Password is too weak";
      showAlert('error', 'Weak Password', 'Please choose a stronger password with at least 8 characters, including uppercase letters, numbers, and special characters.');
      break;
    case 'auth/network-request-failed':
      showAlert('error', 'Network Error', 'A network error occurred. Please check your internet connection and try again.');
      break;
    default:
      registerErrors.email = error.message;
      showAlert('error', 'Registration Failed', 'An unexpected error occurred. Please try again later.');
  }
};

// Google registration with improved error handling
const registerWithGoogle = async () => {
  loading.value = true;
  try {
    const provider = new GoogleAuthProvider();
    // Request additional scopes for more profile data
    provider.addScope('https://www.googleapis.com/auth/userinfo.profile');
    
    const result = await signInWithPopup(auth, provider);
    const user = result.user;
    
    // Get the OAuth access token
    const credential = GoogleAuthProvider.credentialFromResult(result);
    const token = credential.accessToken;
    
    const userRef = doc(db, "users", user.uid);
    const userSnap = await getDoc(userRef);
    
    if (!userSnap.exists()) {
      // Create new user document
      await setDoc(userRef, {
        username: user.displayName || 'User',
        email: user.email,
        photoURL: user.photoURL || null,
        role: "user",
        status: "active",
        createdAt: new Date().toISOString(),
        lastLogin: new Date().toISOString(),
        loginCount: 1,
        authProvider: "google",
        emailVerified: true
      });
      
      showAlert('success', 'Account Created', 'Your account has been created successfully! Redirecting to your dashboard...');
    } else {
      // Update existing user
      await updateDoc(userRef, {
        lastLogin: new Date().toISOString(),
        loginCount: increment(1)
      });
      
      showAlert('success', 'Login Successful', 'Welcome back! Redirecting to your dashboard...');
    }
    
    localStorage.setItem('userRole', "user");
    
    // Redirect after a short delay to show the success message
    setTimeout(() => {
      router.push("/dashboard");
    }, 1500);
  } catch (error) {
    console.error("Google Sign-Up Error:", error);
    
    if (error.code === 'auth/popup-closed-by-user') {
      showAlert('error', 'Authentication Cancelled', 'The Google sign-up was cancelled. Please try again.');
    } else if (error.code === 'auth/popup-blocked') {
      showAlert('error', 'Popup Blocked', 'The sign-up popup was blocked by your browser. Please allow popups for this site and try again.');
    } else {
      registerErrors.email = "Google Sign-Up failed. Please try again.";
      showAlert('error', 'Authentication Failed', 'Google sign-up failed. Please try again or use email registration.');
    }
  } finally {
    loading.value = false;
  }
};

// Email verification resend with improved feedback
const resendVerification = async () => {
  verificationLoading.value = true;
  try {
    // Try to sign in with the provided credentials to get the current user
    const userCredential = await signInWithEmailAndPassword(
      auth, 
      loginForm.email, 
      loginForm.password
    );
    const user = userCredential.user;
    
    await sendEmailVerification(user);
    await signOut(auth);
    
    loginErrors.email = "Verification email sent! Please check your inbox.";
    showAlert('success', 'Verification Email Sent', 'A new verification email has been sent to your email address. Please check your inbox and spam folder.');
  } catch (error) {
    console.error("Verification email error:", error);
    loginErrors.email = "Failed to send verification email. Please try again.";
    showAlert('error', 'Verification Failed', 'We couldn\'t send a verification email. Please try again later or contact support.');
  } finally {
    verificationLoading.value = false;
  }
};

// Retry login after failure
const retryLogin = async () => {
  if (!loginForm.email || !loginForm.password) {
    showAlert('error', 'Missing Information', 'Please fill in your email and password.');
    return;
  }
  
  // Reset errors
  loginErrors.email = "";
  loginErrors.password = "";
  
  await loginUser();
};

// Password strength calculation
const passwordStrength = computed(() => {
  if (!registerForm.password) return { score: 0, feedback: "Enter a password" };
  
  const result = zxcvbn(registerForm.password);
  let feedback = '';
  
  if (result.score < 2) {
    feedback = result.feedback.suggestions.join(" ") || "Your password is too weak. Try adding numbers, symbols, and uppercase letters.";
  } else if (result.score === 2) {
    feedback = "Fair password, but you can make it stronger.";
  } else if (result.score === 3) {
    feedback = "Good password! Consider adding more complexity for extra security.";
  } else {
    feedback = "Strong password!";
  }
  
  return { score: result.score, feedback };
});

// Terms and Privacy acceptance
const acceptTerms = () => {
  registerForm.agreeToTerms = true;
  showTermsModal.value = false;
};

const acceptPrivacy = () => {
  registerForm.agreeToTerms = true;
  showPrivacyModal.value = false;
};

// Form validation schema using yup and vee-validate
const loginSchema = yup.object({
  email: yup.string().email("Invalid email format").required("Email is required"),
  password: yup.string().min(6, "Password must be at least 6 characters").required("Password is required"),
});

const registerSchema = yup.object({
  username: yup.string().min(3, "Username must be at least 3 characters").max(30, "Username must be less than 30 characters").required("Username is required"),
  email: yup.string().email("Invalid email format").required("Email is required"),
  password: yup.string()
    .min(8, "Password must be at least 8 characters")
    .matches(/[A-Z]/, "Password must contain at least one uppercase letter")
    .matches(/[0-9]/, "Password must contain at least one number")
    .matches(/[!@#$%^&*(),.?":{}|<>]/, "Password must contain at least one special character")
    .required("Password is required"),
  confirmPassword: yup.string()
    .oneOf([yup.ref('password')], "Passwords must match")
    .required("Please confirm your password"),
  agreeToTerms: yup.boolean().oneOf([true], "You must agree to the terms")
});

// Focus management
const focusFirstInput = () => {
  setTimeout(() => {
    const firstInput = document.querySelector(isLoginView.value ? "#login-email" : "input[type='text']");
    if (firstInput) firstInput.focus();
  }, 500); // Delay to allow for transitions
};

// Watch for view changes to focus the first input
watch(isLoginView, focusFirstInput);

// Initialize component
onMounted(() => {
  focusFirstInput();
  
  // Check for any stored login attempts
  const storedAttempts = localStorage.getItem('loginAttempts');
  const storedTime = localStorage.getItem('lastLoginAttempt');
  const storedLockout = localStorage.getItem('accountLocked');
  const storedLockoutEnd = localStorage.getItem('lockoutEndTime');
  
  if (storedAttempts) {
    loginAttempts.value = parseInt(storedAttempts);
  }
  
  if (storedTime) {
    lastLoginAttempt.value = new Date(storedTime);
  }
  
  if (storedLockout === 'true' && storedLockoutEnd) {
    accountLocked.value = true;
    lockoutEndTime.value = new Date(storedLockoutEnd);
    
    // Check if lockout period has expired
    checkAccountLockout();
  }
});

// Store login attempts and lockout status
watch([loginAttempts, accountLocked, lockoutEndTime], () => {
  localStorage.setItem('loginAttempts', loginAttempts.value);
  
  if (lastLoginAttempt.value) {
    localStorage.setItem('lastLoginAttempt', lastLoginAttempt.value.toISOString());
  }
  
  localStorage.setItem('accountLocked', accountLocked.value);
  
  if (lockoutEndTime.value) {
    localStorage.setItem('lockoutEndTime', lockoutEndTime.value.toISOString());
  }
});
</script>

<style>
@keyframes float-logo {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-20px); }
}

@keyframes shine {
  0% { transform: translateX(-100%); }
  100% { transform: translateX(100%); }
}

/* Disable animations for reduced motion */
@media (prefers-reduced-motion: reduce) {
  .transition-all {
    transition: none;
  }
  .active\:scale-95:active,
  .hover\:-translate-y-1:hover {
    transform: none;
  }
}

/* For better touch interactions */
.touch-manipulation {
  touch-action: manipulation;
}

/* Mobile responsiveness */
@media (max-width: 640px) {
  .container {
    padding: 1rem;
  }
  .flex {
    flex-direction: column;
  }
}

/* Spinner for loading state */
[aria-busy="true"] {
  opacity: 0.6;
  pointer-events: none;
}

/* Fade animation for alerts */
.fade-enter-active, .fade-leave-active {
  transition: opacity 0.3s ease;
}
.fade-enter-from, .fade-leave-to {
  opacity: 0;
}

/* Improved focus styles for accessibility */
input:focus, button:focus, a:focus {
  outline: 2px solid rgba(22, 163, 74, 0.5);
  outline-offset: 2px;
}

/* Skeleton loading animation */
@keyframes pulse {
  0%, 100% { opacity: 0.6; }
  50% { opacity: 0.3; }
}
.skeleton-loading {
  animation: pulse 1.5s ease-in-out infinite;
  background-color: #e5e7eb;
}
</style>