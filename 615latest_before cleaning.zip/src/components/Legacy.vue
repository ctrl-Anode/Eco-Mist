<template>
  <div class="min-h-screen bg-gray-50 flex flex-col">
    <!-- Top Navigation Bar -->
    <header class="bg-gradient-to-r from-emerald-700 to-green-600 shadow-lg z-10">
      <div class="container mx-auto px-4 py-3">
        <div class="flex items-center justify-between">
          <!-- Logo and Mobile Menu Button -->
          <div class="flex items-center">
            <button @click="toggleSidebar" class="mr-3 md:hidden text-white">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
            <div class="flex items-center">
              <div class="bg-white p-1.5 rounded-lg shadow-md mr-3">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-7 w-7 text-emerald-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M12 2v8"></path>
                  <path d="M4.93 10.93l1.41 1.41"></path>
                  <path d="M2 18h2"></path>
                  <path d="M20 18h2"></path>
                  <path d="M19.07 10.93l-1.41 1.41"></path>
                  <path d="M22 22H2"></path>
                  <path d="M16 16a4 4 0 0 1-8 0"></path>
                  <path d="M12 12a2 2 0 0 0-2 2"></path>
                </svg>
              </div>
              <div>
                <h1 class="text-xl font-bold text-white">Eco-Mist</h1>
                <p class="text-green-100 text-xs hidden sm:block">IoT Aeroponics Monitoring</p>
              </div>
            </div>
          </div>

          <!-- System Status and User Profile -->
          <div class="flex items-center space-x-3">
            <!-- System Status Badge -->
            <div :class="[getSystemStatusClass(), 'px-2 py-1 rounded-full text-xs font-medium hidden sm:block']">
              {{ getSystemStatus() }}
            </div>

            <!-- Notification Bell -->
            <div class="relative">
              <button class="text-white p-1 rounded-full hover:bg-white hover:bg-opacity-10 focus:outline-none">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                </svg>
                <span v-if="alerts.length > 0" class="absolute top-0 right-0 bg-red-500 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
                  {{ alerts.length }}
                </span>
              </button>
            </div>

            <!-- User Profile Dropdown -->
            <div class="relative" ref="userMenuRef">
              <button @click="toggleUserMenu" class="flex items-center space-x-2 focus:outline-none">
                <div class="bg-white text-emerald-700 h-8 w-8 rounded-full flex items-center justify-center font-bold text-sm shadow">
                  {{ getInitials(username) }}
                </div>
                <span class="text-white hidden md:block">{{ username }}</span>
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-white hidden md:block" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="m6 9 6 6 6-6"></path>
                </svg>
              </button>

              <!-- User Menu Dropdown -->
              <div v-if="userMenuOpen" class="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-20">
                <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Profile</a>
                <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Settings</a>
                <a @click="confirmLogout" href="#" class="block px-4 py-2 text-sm text-red-600 hover:bg-gray-100">Logout</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>

    <!-- Main Content Area with Sidebar -->
    <div class="flex flex-1 overflow-hidden">
      <!-- Sidebar Navigation -->
      <aside :class="[
        'bg-white shadow-lg z-20 transition-all duration-300 ease-in-out',
        sidebarOpen ? 'translate-x-0' : '-translate-x-full',
        'md:translate-x-0 fixed md:relative inset-y-0 left-0 w-64 overflow-y-auto'
      ]">
        <!-- Sidebar Header -->
        <div class="p-4 border-b">
          <div class="flex items-center justify-between">
            <h2 class="text-lg font-semibold text-gray-800">Navigation</h2>
            <button @click="toggleSidebar" class="md:hidden text-gray-500 hover:text-gray-700">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>

        <!-- Navigation Sections -->
        <nav class="p-4">
          <div v-for="(section, sectionIndex) in navigationSections" :key="sectionIndex" class="mb-6">
            <h3 class="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">{{ section.title }}</h3>
            <ul class="space-y-1">
              <li v-for="(route, routeIndex) in getFilteredRoutes(section)" :key="routeIndex">
                <a 
                  :href="route.path" 
                  :class="[
                    'flex items-center px-3 py-2 text-sm rounded-md',
                    currentRoute === route.path 
                      ? 'bg-emerald-100 text-emerald-700 font-medium' 
                      : 'text-gray-700 hover:bg-gray-100'
                  ]"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" :class="currentRoute === route.path ? 'text-emerald-600' : 'text-gray-500'" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path v-if="getIconForRoute(route) === 'layout-dashboard'" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM4 13a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6zM16 13a1 1 0 011-1h2a1 1 0 011 1v6a1 1 0 01-1 1h-2a1 1 0 01-1-1v-6z" />
                    <path v-else-if="getIconForRoute(route) === 'user'" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    <path v-else-if="getIconForRoute(route) === 'user-cog'" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5.121 17.804A13.937 13.937 0 0112 16c2.5 0 4.847.655 6.879 1.804M15 10a3 3 0 11-6 0 3 3 0 016 0zm6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    <path v-else-if="getIconForRoute(route) === 'cpu'" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z" />
                    <path v-else-if="getIconForRoute(route) === 'bar-chart'" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                    <path v-else-if="getIconForRoute(route) === 'message-circle'" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                    <path v-else-if="getIconForRoute(route) === 'microscope'" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                    <path v-else-if="getIconForRoute(route) === 'settings'" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                    <path v-else-if="getIconForRoute(route) === 'shield'" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                    <path v-else-if="getIconForRoute(route) === 'users'" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                    <path v-else stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
                  </svg>
                  {{ route.name }}
                </a>
              </li>
            </ul>
          </div>
        </nav>

        <!-- System Info -->
        <div class="p-4 border-t">
          <div class="bg-gray-50 rounded-lg p-3">
            <div class="flex items-center justify-between mb-2">
              <span class="text-xs font-medium text-gray-500">System Status</span>
              <span :class="[
                isConnected ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800',
                'text-xs px-2 py-0.5 rounded-full'
              ]">
                {{ isConnected ? 'Connected' : 'Offline' }}
              </span>
            </div>
            <div class="text-xs text-gray-500 flex flex-col space-y-1">
              <div class="flex justify-between">
                <span>Uptime:</span>
                <span class="font-medium text-gray-700">{{ uptime }}</span>
              </div>
              <div class="flex justify-between">
                <span>Last Updated:</span>
                <span class="font-medium text-gray-700">{{ lastUpdated }}</span>
              </div>
              <div class="flex justify-between">
                <span>Alerts:</span>
                <span class="font-medium text-gray-700">{{ alerts.length }}</span>
              </div>
            </div>
          </div>
        </div>
      </aside>

      <!-- Main Content -->
      <main class="flex-1 overflow-y-auto bg-gray-50 p-4 md:p-6">
        <!-- Page Header -->
        <div class="mb-6">
          <h1 class="text-2xl font-bold text-gray-800">Sensor Data</h1>
          <p class="text-gray-600">Monitor and analyze your aeroponics system in real-time</p>
        </div>

        <!-- Cards View -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          <div v-for="param in chartParams" :key="param.key" class="bg-white rounded-lg shadow-sm overflow-hidden">
            <div class="p-4 border-b">
              <div class="flex justify-between items-center">
                <h3 class="font-medium text-gray-800">{{ param.title }}</h3>
                <div :class="[
                  getStatusClass(sensorData[param.key], param.min, param.max),
                  'text-xs text-white px-2 py-0.5 rounded-full'
                ]">
                  {{ getStatusText(sensorData[param.key], param.min, param.max) }}
                </div>
              </div>
            </div>
            <div class="p-4">
              <div class="flex items-end justify-between">
                <div>
                  <div class="text-3xl font-bold text-gray-800">
                    {{ formatValue(sensorData[param.key], param.unit) }}
                  </div>
                  <div class="mt-1 flex items-center text-sm">
                    <span :class="[
                      getTrend(param.key) > 0 ? 'text-green-600' : 
                      getTrend(param.key) < 0 ? 'text-red-600' : 
                      'text-gray-600'
                    ]" class="font-medium">
                      {{ formatTrend(param.key) }}
                    </span>
                    <span class="text-gray-500 ml-1">since last reading</span>
                  </div>
                </div>
              </div>
              <div class="mt-4">
                <div class="flex justify-between text-xs text-gray-500 mb-1">
                  <span>Min: {{ param.min }}{{ param.unit }}</span>
                  <span>Optimal Range</span>
                  <span>Max: {{ param.max }}{{ param.unit }}</span>
                </div>
                <div class="h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div class="h-full bg-emerald-500 rounded-full" :style="{
                    width: `${Math.min(100, Math.max(0, ((sensorData[param.key] - param.min) / (param.max - param.min)) * 100))}%`
                  }"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <!-- Alerts Sidebar -->
      <aside class="hidden lg:block w-80 bg-white border-l overflow-y-auto">
        <div class="p-4 border-b">
          <div class="flex items-center justify-between">
            <h2 class="text-lg font-semibold text-gray-800">Alerts & Notifications</h2>
            <span class="bg-red-100 text-red-800 text-xs px-2 py-0.5 rounded-full">
              {{ alerts.length }}
            </span>
          </div>
        </div>
        <div class="p-4">
          <div v-if="alerts.length === 0" class="text-gray-500 text-sm italic text-center py-8">
            No alerts at this time
          </div>
          <div v-else class="space-y-3">
            <div v-for="(alert, index) in alerts" :key="index" :class="[
              'p-3 rounded-md relative',
              alert.severity === 'critical' ? 'bg-red-50' :
              alert.severity === 'warning' ? 'bg-yellow-50' :
              'bg-blue-50'
            ]">
              <button @click="dismissAlert(index)" class="absolute top-2 right-2 text-gray-400 hover:text-gray-600">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
              <div :class="[
                'text-sm font-medium mb-1',
                alert.severity === 'critical' ? 'text-red-800' :
                alert.severity === 'warning' ? 'text-yellow-800' :
                'text-blue-800'
              ]">
                {{ alert.title }}
              </div>
              <div class="text-xs text-gray-600 mb-2">{{ alert.message }}</div>
              <div class="text-xs text-gray-500">{{ formatAlertTime(alert.timestamp) }}</div>
            </div>
          </div>
        </div>
      </aside>
    </div>

    <!-- Logout Confirmation Modal -->
    <div v-if="showLogoutModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div class="bg-white rounded-lg p-6 max-w-sm mx-auto">
        <h3 class="text-lg font-medium text-gray-900 mb-4">Confirm Logout</h3>
        <p class="text-gray-500 mb-4">Are you sure you want to log out of your account?</p>
        <div class="flex justify-end gap-2">
          <button @click="showLogoutModal = false" class="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300">
            Cancel
          </button>
          <button @click="logout" class="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700">
            Logout
          </button>
        </div>
      </div>
    </div>

    <!-- Confirmation Modal -->
    <div v-if="showConfirmModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div class="bg-white rounded-lg p-6 max-w-sm mx-auto">
        <h3 class="text-lg font-medium text-gray-900 mb-4">{{ confirmModal.title }}</h3>
        <p class="text-gray-500 mb-4">{{ confirmModal.message }}</p>
        <div class="flex justify-end gap-2">
          <button @click="showConfirmModal = false" class="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300">
            Cancel
          </button>
          <button @click="confirmAction" class="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700">
            {{ confirmModal.confirmText }}
          </button>
        </div>
      </div>
    </div>

    <!-- Notification Toast -->
    <div v-if="showNotification" class="fixed bottom-4 right-4 max-w-md z-50">
      <div :class="[
        'rounded-lg shadow-lg p-4 flex items-start',
        notificationData.type === 'success' ? 'bg-green-100 text-green-800 border-l-4 border-green-500' :
        notificationData.type === 'warning' ? 'bg-yellow-100 text-yellow-800 border-l-4 border-yellow-500' :
        notificationData.type === 'error' ? 'bg-red-100 text-red-800 border-l-4 border-red-500' :
        'bg-blue-100 text-blue-800 border-l-4 border-blue-500'
      ]">
        <div class="flex-shrink-0 mr-3">
          <svg v-if="notificationData.type === 'success'" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
          </svg>
          <svg v-else-if="notificationData.type === 'warning' || notificationData.type === 'error'" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd" />
          </svg>
          <svg v-else class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd" />
          </svg>
        </div>
        <div>
          <h3 class="font-medium">{{ notificationData.title }}</h3>
          <p class="text-sm mt-1">{{ notificationData.message }}</p>
        </div>
        <button @click="showNotification = false" class="ml-auto">
          <svg class="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
            <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd" />
          </svg>
        </button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, watch, onMounted, onBeforeUnmount, nextTick } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { getAuth, signOut, onAuthStateChanged } from "firebase/auth";
import { doc, getDoc, updateDoc, onSnapshot, Timestamp } from "firebase/firestore";
import { db, rdb } from "../firebase";
import { ref as dbRef, onValue, query, limitToLast, get, orderByChild, push, set } from 'firebase/database';

// State variables
const username = ref("Paranode");
const role = ref("user");
const showLogoutModal = ref(false);
const sidebarOpen = ref(true);
const userMenuOpen = ref(false);
const isMobile = ref(false);
const userMenuRef = ref(null);
const currentRoute = ref('/sensor_data');

// Sensor data state
const sensorData = ref({
  air_temperature: 0,
  water_temperature: 0,
  humidity: 0,
  water_level: 0,
  ph: 0,
  tds: 0
});

// UI state variables
const isLoading = ref(false);
const isExporting = ref(false);
const lastUpdated = ref('--');
const historicalData = ref([]);
const previousData = ref(null);
const showDebug = ref(false);
const isConnected = ref(true);
const uptime = ref('0h 0m');
const notificationsEnabled = ref(true);
const autoRefreshEnabled = ref(true);
const refreshInterval = ref(30000);
const alerts = ref([]);
const showNotification = ref(false);
const notificationData = ref({ title: '', message: '', type: 'info' });
const startTime = ref(Date.now());
const showConfirmModal = ref(false);
const confirmModal = ref({
  title: '',
  message: '',
  confirmText: 'Confirm',
  action: null
});

// Chart parameters
const chartParams = [
  { key: 'air_temperature', title: 'Air Temperature (°C)', min: 15, max: 35, unit: '°C' },
  { key: 'water_temperature', title: 'Water Temperature (°C)', min: 18, max: 32, unit: '°C' },
  { key: 'humidity', title: 'Humidity (%)', min: 30, max: 70, unit: '%' },
  { key: 'water_level', title: 'Water Level (cm)', min: 5, max: 25, unit: 'cm' },
  { key: 'ph', title: 'pH Level', min: 5.5, max: 8.5, unit: '' },
  { key: 'tds', title: 'TDS Level (ppm)', min: 50, max: 600, unit: 'ppm' }
];

// Navigation sections
const navigationSections = [
  {
    title: 'GENERAL',
    routes: [
      { path: '/dashboard', name: 'Dashboard' },
      { path: '/profile-display', name: 'Profile' },
      { path: '/messenger', name: 'Messenger' }
    ]
  },
  {
    title: 'DATA & TOOLS',
    routes: [
      { path: '/sensor_data', name: 'Sensor Data' },
      { path: '/financial-management', name: 'Financial Management' },
      { path: '/model', name: 'Crop Disease Detector' }
    ]
  },
  {
    title: 'SETTINGS',
    routes: [
      { path: '/edit-profile', name: 'Edit Profile' },
      { path: '/settings', name: 'Settings' }
    ]
  },
  {
    title: 'ADMIN CONTROLS',
    routes: [
      { path: '/admin-dashboard', name: 'Admin Dashboard' },
      { path: '/admin-management', name: 'Admin Management' }
    ]
  }
];

// Helper Functions
const getInitials = (name) => {
  if (!name) return "U";
  return name.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2);
};

// Format date with timezone
const formatTimezoneDate = (date) => {
  if (!date) return '';
  try {
    return new Date(date).toLocaleString('en-US', {
      timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      dateStyle: 'short',
      timeStyle: 'medium'
    });
  } catch (error) {
    console.error('Error formatting date with timezone:', error);
    return new Date(date).toLocaleString();
  }
};

// Format value with unit
const formatValue = (value, unit) => {
  if (value === undefined || value === null) return 'N/A';
  if (typeof value === 'number') {
    return `${value.toFixed(2)}${unit}`;
  }
  return `${value}${unit}`;
};

// Status functions
const getStatusClass = (value, min, max) => {
  if (!value) return 'bg-gray-300';
  if (value >= min && value <= max) return 'bg-green-500';
  if (value >= min - (min * 0.2) && value <= max + (max * 0.2)) return 'bg-yellow-500';
  return 'bg-red-500';
};

const getStatusText = (value, min, max) => {
  if (!value) return 'No Data';
  if (value >= min && value <= max) return 'Optimal';
  if (value >= min - (min * 0.2) && value <= max + (max * 0.2)) return 'Warning';
  return 'Critical';
};

// System status functions
const getSystemStatus = () => {
  const statuses = Object.entries(sensorData.value).map(([key, value]) => {
    const param = chartParams.find(p => p.key === key);
    if (!param) return 'optimal';
    
    const min = param.min;
    const max = param.max;
    
    if (!value) return 'no-data';
    if (value >= min && value <= max) return 'optimal';
    if (value >= min - (min * 0.2) && value <= max + (max * 0.2)) return 'warning';
    return 'critical';
  });
  
  if (statuses.includes('critical')) return 'Critical Alert';
  if (statuses.includes('warning')) return 'Warning';
  return 'All Systems Normal';
};

const getSystemStatusClass = () => {
  const status = getSystemStatus();
  if (status === 'Critical Alert') return 'bg-red-100 text-red-800';
  if (status === 'Warning') return 'bg-yellow-100 text-yellow-800';
  return 'bg-green-100 text-green-800';
};

const getTrend = (key) => {
  if (!previousData.value || !sensorData.value[key] || !previousData.value[key]) return 0;
  return sensorData.value[key] - previousData.value[key];
};

const formatTrend = (key) => {
  const trend = getTrend(key);
  if (Math.abs(trend) < 0.01) return 'Stable';
  
  const param = chartParams.find(p => p.key === key);
  const unit = param ? param.unit : '';
  
  return trend > 0 ? `+${trend.toFixed(2)}${unit}` : `${trend.toFixed(2)}${unit}`;
};

// UI Interaction Functions
const toggleSidebar = () => {
  sidebarOpen.value = !sidebarOpen.value;
  localStorage.setItem('sidebarOpen', sidebarOpen.value.toString());
  
  if (isMobile.value && sidebarOpen.value) {
    document.body.style.overflow = 'hidden';
  } else {
    document.body.style.overflow = '';
  }
};

const toggleUserMenu = () => {
  userMenuOpen.value = !userMenuOpen.value;
};

const confirmLogout = () => {
  showLogoutModal.value = true;
};

const logout = async () => {
  try {
    const auth = getAuth();
    await signOut(auth);
    window.location.href = '/auth';
  } catch (error) {
    console.error("Error logging out:", error);
  }
};

const getFilteredRoutes = (section) => {
  return section.routes.filter(route => {
    if (route.path === '/admin-dashboard' || route.path === '/admin-management') {
      return role.value === 'admin';
    }
    return true;
  });
};

const getIconForRoute = (route) => {
  const iconMap = {
    '/dashboard': 'layout-dashboard',
    '/profile-display': 'user',
    '/edit-profile': 'user-cog',
    '/reset-password': 'key',
    '/admin-dashboard': 'shield',
    '/admin-management': 'users',
    '/financial-management': 'bar-chart',
    '/messenger': 'message-circle',
    '/sensor_data': 'cpu',
    '/model': 'microscope',
    '/settings': 'settings'
  };
  
  return iconMap[route.path] || 'link';
};

// Data Management Functions
const refreshData = async () => {
  if (isLoading.value) return;
  
  isLoading.value = true;
  try {
    const sensorRef = query(dbRef(rdb, 'sensor_data'), limitToLast(1));
    const snapshot = await get(sensorRef);
    
    if (snapshot.exists()) {
      previousData.value = { ...sensorData.value };
      
      snapshot.forEach((childSnapshot) => {
        sensorData.value = childSnapshot.val();
      });
      
      lastUpdated.value = formatTimezoneDate(new Date());
      checkAlerts();
      
      // Add to historical data
      historicalData.value.push({
        timestamp: Date.now(),
        ...sensorData.value
      });
    }
  } catch (error) {
    console.error('Error refreshing data:', error);
    isConnected.value = false;
    showNotification.value = true;
    notificationData.value = {
      title: 'Connection Error',
      message: 'Failed to refresh sensor data. Check your connection.',
      type: 'error'
    };
  } finally {
    isLoading.value = false;
  }
};

// Alert and notification functions
const checkAlerts = () => {
  const criticalSensors = [];
  const warningSensors = [];
  
  // First collect all sensors that are in critical or warning state
  chartParams.forEach(param => {
    const value = sensorData.value[param.key];
    const min = param.min;
    const max = param.max;
    
    if (!value) return;
    
    // Critical threshold
    if (value < min - (min * 0.3) || value > max + (max * 0.3)) {
      criticalSensors.push({
        name: param.title,
        value: value,
        unit: param.unit
      });
      
      // Still add individual alerts to the alerts panel
      addAlertToPanel('critical', `Critical ${param.title}`, 
        `${param.title} is at ${value}${param.unit}, which is outside safe range.`);
    } 
    // Warning threshold
    else if (value < min || value > max) {
      warningSensors.push({
        name: param.title,
        value: value,
        unit: param.unit
      });
      
      // Still add individual alerts to the alerts panel
      addAlertToPanel('warning', `${param.title} Warning`, 
        `${param.title} is at ${value}${param.unit}, outside optimal range.`);
    }
  });
  
  // If there are any critical sensors, show a grouped notification
  if (criticalSensors.length > 0 && notificationsEnabled.value) {
    showGroupedNotification('critical', criticalSensors);
  }
  // Otherwise, if there are warning sensors, show a grouped warning
  else if (warningSensors.length > 0 && notificationsEnabled.value) {
    showGroupedNotification('warning', warningSensors);
  }
};

const addAlertToPanel = (severity, title, message) => {
  // Check if similar alert already exists
  const existingAlert = alerts.value.find(a => a.title === title);
  if (existingAlert) return;
  
  const alert = {
    severity,
    title,
    message,
    timestamp: Date.now()
  };
  
  alerts.value.unshift(alert);
  
  // Keep only last 10 alerts
  if (alerts.value.length > 10) {
    alerts.value = alerts.value.slice(0, 10);
  }
};

const showGroupedNotification = (severity, sensors) => {
  if (!notificationsEnabled.value) return;
  
  let title = '';
  let message = '';
  
  if (severity === 'critical') {
    title = `Critical Alert: ${sensors.length} sensor${sensors.length > 1 ? 's' : ''} in critical state`;
    message = sensors.map(s => `${s.name}: ${s.value}${s.unit}`).join(', ');
  } else {
    title = `Warning: ${sensors.length} sensor${sensors.length > 1 ? 's' : ''} outside optimal range`;
    message = sensors.map(s => `${s.name}: ${s.value}${s.unit}`).join(', ');
  }
  
  showNotification.value = true;
  notificationData.value = {
    title,
    message,
    type: severity
  };
  
  // Auto-hide notification after 5 seconds
  setTimeout(() => {
    if (notificationData.value.title === title) {
      showNotification.value = false;
    }
  }, 5000);
};

const dismissAlert = (index) => {
  alerts.value.splice(index, 1);
};

const formatAlertTime = (timestamp) => {
  const now = Date.now();
  const diff = now - timestamp;
  
  if (diff < 60000) return 'Just now';
  if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
  return `${Math.floor(diff / 3600000)}h ago`;
};

// Export functions
const exportData = () => {
  if (historicalData.value.length === 0) {
    showNotification.value = true;
    notificationData.value = {
      title: 'Export Failed',
      message: 'No data available to export',
      type: 'error'
    };
    return;
  }
  
  try {
    // Create CSV content
    const headers = ['timestamp', ...Object.keys(sensorData.value)];
    let csvContent = headers.join(',') + '\n';
    
    historicalData.value.forEach(data => {
      // Format timestamp safely with timezone
      let timestampStr = formatTimezoneDate(new Date(data.timestamp));
      
      // Get all sensor values, ensuring proper CSV formatting
      const sensorValues = Object.keys(sensorData.value).map(key => {
        const value = data[key];
        // Handle undefined or null values
        if (value === undefined || value === null) return '';
        
        // Convert to string and escape if contains commas or quotes
        const stringValue = String(value);
        if (stringValue.includes(',') || stringValue.includes('"')) {
          return `"${stringValue.replace(/"/g, '""')}"`;
        }
        return stringValue;
      });
      
      // Combine timestamp and sensor values into a row
      const row = [timestampStr, ...sensorValues];
      csvContent += row.join(',') + '\n';
    });
    
    // Create download link
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    
    // Set download attributes
    link.setAttribute('href', url);
    link.setAttribute('download', `eco-mist-session-data-${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    
    // Add to document, trigger download, and clean up
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    // Show success notification
    showNotification.value = true;
    notificationData.value = {
      title: 'Export Successful',
      message: `Exported ${historicalData.value.length} data points as CSV`,
      type: 'success'
    };
  } catch (error) {
    console.error('Error exporting data:', error);
    showNotification.value = true;
    notificationData.value = {
      title: 'Export Failed',
      message: `Error: ${error.message}`,
      type: 'error'
    };
  }
};

const exportAllData = async () => {
  if (isExporting.value) return;
  
  isExporting.value = true;
  showNotification.value = true;
  notificationData.value = {
    title: 'Export Started',
    message: 'Fetching all sensor data from database. This may take a moment...',
    type: 'info'
  };
  
  try {
    // Get all sensor data from Firebase
    const sensorRef = dbRef(rdb, 'sensor_data');
    const snapshot = await get(sensorRef);
    
    if (!snapshot.exists()) {
      showNotification.value = true;
      notificationData.value = {
        title: 'Export Failed',
        message: 'No data available in the database',
        type: 'error'
      };
      isExporting.value = false;
      return;
    }
    
    // Convert snapshot to array of data points
    const allData = [];
    snapshot.forEach((childSnapshot) => {
      const key = childSnapshot.key;
      const data = childSnapshot.val();
      allData.push({
        timestamp: key,
        ...data
      });
    });
    
    // Sort data by timestamp
    allData.sort((a, b) => {
      // Try to parse timestamps as numbers first
      const aTime = Number(a.timestamp);
      const bTime = Number(b.timestamp);
      
      if (!isNaN(aTime) && !isNaN(bTime)) {
        return aTime - bTime;
      }
      
      // Fall back to string comparison
      return String(a.timestamp).localeCompare(String(b.timestamp));
    });
    
    // Create CSV content
    const headers = ['timestamp', ...Object.keys(sensorData.value)];
    let csvContent = headers.join(',') + '\n';
    
    allData.forEach(data => {
      // Format timestamp safely with timezone
      let timestampStr = formatTimezoneDate(new Date(Number(data.timestamp) || data.timestamp));
      
      // Get all sensor values, ensuring proper CSV formatting
      const sensorValues = Object.keys(sensorData.value).map(key => {
        const value = data[key];
        // Handle undefined or null values
        if (value === undefined || value === null) return '';
        
        // Convert to string and escape if contains commas or quotes
        const stringValue = String(value);
        if (stringValue.includes(',') || stringValue.includes('"')) {
          return `"${stringValue.replace(/"/g, '""')}"`;
        }
        return stringValue;
      });
      
      // Combine timestamp and sensor values into a row
      const row = [timestampStr, ...sensorValues];
      csvContent += row.join(',') + '\n';
    });
    
    // Create download link
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    
    // Set download attributes
    link.setAttribute('href', url);
    link.setAttribute('download', `eco-mist-full-database-${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    
    // Add to document, trigger download, and clean up
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    // Show success notification
    showNotification.value = true;
    notificationData.value = {
      title: 'Export Successful',
      message: `Exported ${allData.length} data points from database as CSV`,
      type: 'success'
    };
  } catch (error) {
    console.error('Error exporting all data:', error);
    showNotification.value = true;
    notificationData.value = {
      title: 'Export Failed',
      message: `Error: ${error.message}`,
      type: 'error'
    };
  } finally {
    isExporting.value = false;
  }
};

// Clear data confirmation
const confirmClearData = () => {
  showConfirmModal.value = true;
  confirmModal.value = {
    title: 'Clear Data',
    message: 'Are you sure you want to clear all historical data? This action cannot be undone.',
    confirmText: 'Clear Data',
    action: clearData
  };
};

// Clear all historical data
const clearData = () => {
  historicalData.value = [];
  
  showNotification.value = true;
  notificationData.value = {
    title: 'Data Cleared',
    message: 'All historical data has been cleared',
    type: 'success'
  };
};

// Confirm action handler
const confirmAction = () => {
  if (confirmModal.value.action) {
    confirmModal.value.action();
  }
  showConfirmModal.value = false;
};

// Chart functions
// Removed all chart-related functions and logic as per the change request

// Update uptime every minute
const updateUptime = () => {
  const now = Date.now();
  const diff = now - startTime.value;
  const hours = Math.floor(diff / 3600000);
  const minutes = Math.floor((diff % 3600000) / 60000);
  uptime.value = `${hours}h ${minutes}m`;
};

// Check if device is mobile
const checkIfMobile = () => {
  isMobile.value = window.innerWidth < 768;
  if (isMobile.value) {
    sidebarOpen.value = false;
  } else {
    // Get saved sidebar state or default to open on desktop
    const savedState = localStorage.getItem('sidebarOpen');
    sidebarOpen.value = savedState !== null ? savedState === 'true' : true;
  }
};

// Handle window resize
const handleResize = () => {
  checkIfMobile();
};

// Auto-refresh timer
let refreshTimer = null;

const setupAutoRefresh = () => {
  clearInterval(refreshTimer);
  if (autoRefreshEnabled.value) {
    refreshTimer = setInterval(refreshData, refreshInterval.value);
  }
};

// Watch for changes to auto-refresh settings
watch(autoRefreshEnabled, setupAutoRefresh);
watch(refreshInterval, setupAutoRefresh);

// Initialize component
onMounted(() => {
  // Check if mobile on initial load
  checkIfMobile();
  
  // Add resize event listener
  window.addEventListener('resize', handleResize);
  
  // Add click outside listener for user menu
  document.addEventListener('click', handleClickOutside);
  
  // Initial data load
  const sensorRef = query(dbRef(rdb, 'sensor_data'), limitToLast(1));
  
  const unsubscribe = onValue(sensorRef, (snapshot) => {
    if (snapshot.exists()) {
      previousData.value = { ...sensorData.value };
      
      snapshot.forEach((childSnapshot) => {
        sensorData.value = childSnapshot.val();
      });
      
      lastUpdated.value = formatTimezoneDate(new Date());
      isConnected.value = true;
      
      // Add to historical data
      historicalData.value.push({
        timestamp: Date.now(),
        ...sensorData.value
      });
      
      checkAlerts();
    } else {
      console.log('No data available');
    }
  }, (error) => {
    console.error('Error fetching data:', error);
    isConnected.value = false;
  });

  // Load historical data
  const historicalRef = query(dbRef(rdb, 'sensor_data'), limitToLast(20));
  get(historicalRef).then((snapshot) => {
    if (snapshot.exists()) {
      const histData = [];
      snapshot.forEach((childSnapshot) => {
        histData.push({
          timestamp: childSnapshot.key,
          ...childSnapshot.val()
        });
      });
      historicalData.value = histData.sort((a, b) => a.timestamp - b.timestamp);
      
      checkAlerts();
    }
  }).catch((error) => {
    console.error('Error fetching historical data:', error);
  });

  // Set up auto-refresh
  setupAutoRefresh();
  
  // Set up uptime counter
  const uptimeInterval = setInterval(updateUptime, 60000);
  
  onBeforeUnmount(() => {
    unsubscribe();
    clearInterval(refreshTimer);
    clearInterval(uptimeInterval);
    window.removeEventListener('resize', handleResize);
    document.removeEventListener('click', handleClickOutside);
  });
});
</script>
