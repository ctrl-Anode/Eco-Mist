<template>
  <div class="p-6 max-w-xl mx-auto">
    <h2 class="text-2xl font-semibold mb-4">Register or Unregister Your Device</h2>

    <form @submit.prevent="registerDevice" class="space-y-4">
      <div>
        <label class="block font-medium mb-1">Device ID (Machine ID)</label>
        <input v-model="deviceId" class="w-full border px-3 py-2 rounded" required />
      </div>

      <div>
        <label class="block font-medium mb-1">Device Name</label>
        <input v-model="deviceName" class="w-full border px-3 py-2 rounded" required />
      </div>

      <div>
        <label class="block font-medium mb-1">Your Email</label>
        <input v-model="userEmail" type="email" class="w-full border px-3 py-2 rounded" required />
      </div>

      <div>
        <label class="block font-medium mb-1">Your Password</label>
        <input v-model="userPassword" type="password" class="w-full border px-3 py-2 rounded" required />
      </div>

      <div class="flex space-x-2">
        <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
          Register Device
        </button>
        <button type="button" @click="unregisterDevice" class="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700">
          Unregister Device
        </button>
      </div>
    </form>

    <p v-if="error" class="text-red-600 mt-4">{{ error }}</p>
    <p v-if="success" class="text-green-600 mt-4">{{ success }}</p>
  </div>
</template>

<script>
import { getDatabase, ref, get, update } from 'firebase/database';
import { getAuth, EmailAuthProvider, reauthenticateWithCredential } from 'firebase/auth';

export default {
  name: 'UserDeviceRegistration',
  data() {
    return {
      deviceId: '',
      deviceName: '',
      userEmail: '',
      userPassword: '',
      error: '',
      success: ''
    };
  },
  methods: {
    async registerDevice() {
      this.error = '';
      this.success = '';

      if (!this.deviceId || !this.deviceName || !this.userEmail || !this.userPassword) {
        this.error = 'All fields are required.';
        return;
      }

      const auth = getAuth();
      const user = auth.currentUser;

      if (!user) {
        this.error = 'You must be logged in to register a device.';
        return;
      }

      const credential = EmailAuthProvider.credential(this.userEmail, this.userPassword);

      try {
        await reauthenticateWithCredential(user, credential);
      } catch (err) {
        this.error = 'Re-authentication failed: ' + err.message;
        return;
      }

      const db = getDatabase();
      const deviceRef = ref(db, `devices/${this.deviceId}`);
      const snapshot = await get(deviceRef);

      if (!snapshot.exists()) {
        this.error = 'Device not found. Make sure the device is online and has sent initial data.';
        return;
      }

      const deviceData = snapshot.val();

      if (deviceData.registered) {
        if (deviceData.owner === user.uid) {
          this.error = 'This device is already registered to your account.';
        } else {
          this.error = 'This device is already registered to another account.';
        }
        return;
      }

      const updates = {
        owner: user.uid,
        devicename: this.deviceName,
        registered: true,
        status: "registered",
        credentials: {
          email: this.userEmail,
          password: this.userPassword
        }
      };

      try {
        await update(deviceRef, updates);
        this.success = 'Device registered successfully!';
      } catch (err) {
        this.error = 'Failed to register device: ' + err.message;
      }
    },

    async unregisterDevice() {
      this.error = '';
      this.success = '';

      if (!this.deviceId || !this.deviceName || !this.userEmail || !this.userPassword) {
        this.error = 'Device ID, Device Name, email, and password are required to unregister.';
        return;
      }

      const auth = getAuth();
      const user = auth.currentUser;

      if (!user) {
        this.error = 'You must be logged in to unregister a device.';
        return;
      }

      const credential = EmailAuthProvider.credential(this.userEmail, this.userPassword);

      try {
        await reauthenticateWithCredential(user, credential);
      } catch (err) {
        this.error = 'Re-authentication failed: ' + err.message;
        return;
      }

      const db = getDatabase();
      const deviceRef = ref(db, `devices/${this.deviceId}`);
      const snapshot = await get(deviceRef);

      if (!snapshot.exists()) {
        this.error = 'Device not found.';
        return;
      }

      const deviceData = snapshot.val();

      if (deviceData.owner !== user.uid) {
        this.error = 'You are not authorized to unregister this device.';
        return;
      }

      if (deviceData.devicename !== this.deviceName) {
        this.error = 'The device name you entered does not match.';
        return;
      }

      const updates = {
        owner: "Unregistered",
        devicename: "Device-" + this.deviceId,
        registered: false,
        status: "waiting_for_registration",
        credentials: {
          email: "",
          password: ""
        }
      };

      try {
        await update(deviceRef, updates);
        this.success = 'Device unregistered successfully!';
      } catch (err) {
        this.error = 'Failed to unregister device: ' + err.message;
      }
    }
  }
};
</script>

<style scoped>
input {
  outline: none;
}
</style>
