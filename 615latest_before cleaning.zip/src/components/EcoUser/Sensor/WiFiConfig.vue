<template>
  <div class="p-6 max-w-lg mx-auto">
    <h2 class="text-2xl font-semibold mb-4">Update WiFi Credentials</h2>

    <form @submit.prevent="updateWiFi" class="space-y-4">
      <div>
        <label class="block mb-1 font-medium">Device ID</label>
        <input v-model="deviceId" class="w-full border px-3 py-2 rounded" required />
      </div>

      <div>
        <label class="block mb-1 font-medium">New WiFi SSID</label>
        <input v-model="ssid" class="w-full border px-3 py-2 rounded" required />
      </div>

      <div>
        <label class="block mb-1 font-medium">New WiFi Password</label>
        <input v-model="password" type="password" class="w-full border px-3 py-2 rounded" required />
      </div>

      <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
        Update WiFi
      </button>

      <p v-if="success" class="text-green-600 mt-2">{{ success }}</p>
      <p v-if="error" class="text-red-600 mt-2">{{ error }}</p>
    </form>
  </div>
</template>

<script>
import { getDatabase, ref, update } from 'firebase/database';

export default {
  name: 'WiFiUpdate',
  data() {
    return {
      deviceId: '',
      ssid: '',
      password: '',
      success: '',
      error: ''
    };
  },
  methods: {
    async updateWiFi() {
      this.success = '';
      this.error = '';

      if (!this.deviceId || !this.ssid || !this.password) {
        this.error = 'All fields are required.';
        return;
      }

      const db = getDatabase();
      const updates = {
        [`devices/${this.deviceId}/state/wifi_ssid`]: this.ssid,
        [`devices/${this.deviceId}/state/wifi_password`]: this.password
      };

      try {
        await update(ref(db), updates);
        this.success = 'WiFi credentials sent to device.';
      } catch (err) {
        this.error = 'Failed to update credentials: ' + err.message;
      }
    }
  }
};
</script>

<style scoped>
input {
  outline: none;
}
</style>
