<template>
  <div class="p-4 max-w-2xl mx-auto">
    <h2 class="text-xl font-semibold mb-4">Threshold Configuration</h2>

    <form @submit.prevent="updateThresholds">
      <div
        v-for="(value, key, index) in paginatedThresholds"
        :key="key"
        class="mb-4"
      >
        <label :for="key" class="block font-medium mb-1">{{ key.replaceAll('_', ' ') }}</label>
        <input
          :id="key"
          v-model.number="thresholds[key]"
          type="number"
          step="any"
          class="w-full p-2 border rounded"
        />
      </div>
      <div class="flex justify-between mb-4">
        <button
          type="button"
          @click="prevPage"
          :disabled="currentPage === 1"
          class="px-3 py-1 bg-gray-200 rounded disabled:opacity-50"
        >
          Prev
        </button>
        <span class="text-sm text-gray-700">Page {{ currentPage }} of {{ totalPages }}</span>
        <button
          type="button"
          @click="nextPage"
          :disabled="currentPage === totalPages"
          class="px-3 py-1 bg-gray-200 rounded disabled:opacity-50"
        >
          Next
        </button>
      </div>

      <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
        Save Thresholds
      </button>
      <button
        @click="restoreDefaults"
        type="button"
        class="ml-2 bg-gray-400 text-white px-4 py-2 rounded hover:bg-gray-500"
      >
        Restore Defaults
      </button>
    </form>

    <h2 class="text-xl font-semibold mt-8 mb-4">Live Sensor Data</h2>
    <div class="grid grid-cols-2 gap-4">
      <div v-for="(value, key) in sensorReadings" :key="key" class="p-4 bg-white rounded shadow">
        <p class="text-gray-600">{{ key.replaceAll('_', ' ') }}</p>
        <p class="text-lg font-bold">{{ value }}</p>
      </div>
    </div>
  </div>
</template>

<script>
import { getDatabase, ref, onValue, set, update } from "firebase/database";
import { getAuth } from "firebase/auth";

export default {
  data() {
    return {
      thresholds: {},
      sensorReadings: {},
      deviceId: null,
      currentPage: 1,
      itemsPerPage: 5,
    };
  },
  computed: {
    paginatedThresholds() {
      const keys = Object.keys(this.thresholds);
      const start = (this.currentPage - 1) * this.itemsPerPage;
      const end = start + this.itemsPerPage;
      return keys.slice(start, end).reduce((acc, key) => {
        acc[key] = this.thresholds[key];
        return acc;
      }, {});
    },
    totalPages() {
      return Math.ceil(Object.keys(this.thresholds).length / this.itemsPerPage);
    },
  },
  created() {
    const auth = getAuth();
    const user = auth.currentUser;
    if (!user) return;

    this.deviceId = "7335153";
    const db = getDatabase();

    onValue(ref(db, `/devices/${this.deviceId}/thresholds`), (snapshot) => {
      if (snapshot.exists()) {
        this.thresholds = snapshot.val();
      }
    });

    onValue(ref(db, `/devices/${this.deviceId}/sensor_readings`), (snapshot) => {
      if (snapshot.exists()) {
        this.sensorReadings = snapshot.val();
      }
    });
  },
  methods: {
    updateThresholds() {
      const db = getDatabase();
      update(ref(db, `/devices/${this.deviceId}/thresholds`), this.thresholds);
    },
    restoreDefaults() {
      const db = getDatabase();
      set(ref(db, `/devices/${this.deviceId}/thresholds/restore_defaults`), true);
    },
    nextPage() {
      if (this.currentPage < this.totalPages) this.currentPage++;
    },
    prevPage() {
      if (this.currentPage > 1) this.currentPage--;
    },
  },
};
</script>

<style scoped>
input[type="number"] {
  background-color: #f9fafb;
}
</style>
