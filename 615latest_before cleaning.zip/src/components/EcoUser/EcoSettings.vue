<template>
  <div class="settings-container">
    <h1 class="text-2xl font-bold text-gray-800 mb-6">Settings</h1>

    <!-- Profile Settings -->
    <section class="mb-8">
      <h2 class="text-xl font-semibold text-gray-700 mb-4">Profile Settings</h2>
      <div class="space-y-4">
        <div>
          <label for="username" class="block text-sm font-medium text-gray-700">Username</label>
          <input
            id="username"
            v-model="profile.username"
            type="text"
            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
          />
        </div>
        <div>
          <label for="email" class="block text-sm font-medium text-gray-700">Email</label>
          <input
            id="email"
            v-model="profile.email"
            type="email"
            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
          />
        </div>
        <div>
          <label for="profileImage" class="block text-sm font-medium text-gray-700">Profile Image</label>
          <input
            id="profileImage"
            type="file"
            @change="handleProfileImageUpload"
            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
          />
        </div>
      </div>
    </section>

    <!-- Notification Preferences -->
    <section class="mb-8">
      <h2 class="text-xl font-semibold text-gray-700 mb-4">Notification Preferences</h2>
      <div class="space-y-4">
        <div class="flex items-center">
          <input
            id="emailNotifications"
            type="checkbox"
            v-model="notifications.email"
            class="mr-2"
          />
          <label for="emailNotifications" class="text-sm font-medium text-gray-700">Email Notifications</label>
        </div>
        <div class="flex items-center">
          <input
            id="smsNotifications"
            type="checkbox"
            v-model="notifications.sms"
            class="mr-2"
          />
          <label for="smsNotifications" class="text-sm font-medium text-gray-700">SMS Notifications</label>
        </div>
        <div class="flex items-center">
          <input
            id="pushNotifications"
            type="checkbox"
            v-model="notifications.push"
            class="mr-2"
          />
          <label for="pushNotifications" class="text-sm font-medium text-gray-700">Push Notifications</label>
        </div>
      </div>
    </section>

    <!-- System Notifications -->
    <section class="mb-8">
      <h2 class="text-xl font-semibold text-gray-700 mb-4">System Notifications</h2>
      <div class="space-y-4">
        <div class="flex items-center justify-between">
          <label for="updateNotifications" class="text-sm font-medium text-gray-700">System Update Notifications</label>
          <input
            id="updateNotifications"
            type="checkbox"
            v-model="systemNotifications.update"
            @change="saveSystemNotifications"
            class="mr-2"
          />
        </div>
        <div class="flex items-center justify-between">
          <label for="maintenanceAlerts" class="text-sm font-medium text-gray-700">Maintenance Alerts</label>
          <input
            id="maintenanceAlerts"
            type="checkbox"
            v-model="systemNotifications.maintenance"
            @change="saveSystemNotifications"
            class="mr-2"
          />
        </div>
      </div>
    </section>

    <!-- Account Management -->
    <section>
      <h2 class="text-xl font-semibold text-gray-700 mb-4">Account Management</h2>
      <div class="space-y-4">
        <button
          @click="changePassword"
          class="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          Change Password
        </button>
        <button
          @click="deactivateAccount"
          class="w-full px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
        >
          Deactivate Account
        </button>
      </div>
    </section>

    <!-- Data Export/Deletion -->
    <section>
      <h2 class="text-xl font-semibold text-gray-700 mb-4">Data Export/Deletion</h2>
      <div class="space-y-4">
        <button
          @click="exportUserData"
          class="w-full px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
        >
          Export User Data
        </button>
        <button
          @click="requestAccountDeletion"
          class="w-full px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
        >
          Request Account Deletion
        </button>
      </div>
    </section>
  </div>
</template>

<script setup>
import { ref } from "vue";
import { getAuth, updateProfile } from "firebase/auth";
import { doc, updateDoc } from "firebase/firestore";
import { db } from "../../firebase";

const auth = getAuth();
const profile = ref({
  username: auth.currentUser?.displayName || "",
  email: auth.currentUser?.email || "",
});
const notifications = ref({
  email: true,
  sms: false,
  push: true,
});
const systemNotifications = ref({
  update: true,
  maintenance: false,
});

const handleProfileImageUpload = (event) => {
  const file = event.target.files[0];
  if (file) {
    // Handle file upload logic here
    console.log("Profile image uploaded:", file.name);
  }
};

const changePassword = () => {
  // Redirect to change password page or show modal
  console.log("Change password clicked");
};

const deactivateAccount = async () => {
  try {
    const userRef = doc(db, "users", auth.currentUser.uid);
    await updateDoc(userRef, { status: "deactivated" });
    console.log("Account deactivated");
  } catch (error) {
    console.error("Error deactivating account:", error);
  }
};

const saveSystemNotifications = async () => {
  try {
    const userRef = doc(db, "users", auth.currentUser.uid);
    await updateDoc(userRef, { systemNotifications: systemNotifications.value });
    console.log("System notifications updated:", systemNotifications.value);
  } catch (error) {
    console.error("Error saving system notifications:", error);
  }
};

const exportUserData = () => {
  // Simulate data export logic
  console.log("User data exported");
  alert("Your data has been exported successfully.");
};

const requestAccountDeletion = async () => {
  try {
    const userRef = doc(db, "users", auth.currentUser.uid);
    await updateDoc(userRef, { deletionRequested: true });
    console.log("Account deletion requested");
    alert("Your account deletion request has been submitted.");
  } catch (error) {
    console.error("Error requesting account deletion:", error);
  }
};
</script>

<style scoped>
.settings-container {
  max-width: 600px;
  margin: 0 auto;
  padding: 1.5rem;
  background: white;
  border-radius: 0.5rem;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}
</style>
