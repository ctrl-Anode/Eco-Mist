<template>
  <div class="min-h-screen bg-gray-50 flex flex-col">
    <!-- Top Navbar -->
    <EcoUser_TopNavBar
      :username="username"
      :profileImageUrl="profileImageUrl"
      :notificationCount="notificationCount"
      :userMenuOpen="userMenuOpen"
      @toggle-sidebar="toggleSidebar"
      @toggle-user-menu="toggleUserMenu"
      @open-feedback="showFeedbackModal = true"
      @confirm-logout="showLogoutModal = true"
      class="fixed top-0 left-0 right-0 z-50"
    />

    <!-- Main layout: Sidebar + MainContent -->
    <div class="flex flex-1 pt-16 overflow-hidden">
      <!-- Sidebar -->
      <div
        :class="[
          'flex flex-col fixed top-16 bottom-0 z-40 bg-white transition-transform duration-300',
          sidebarOpen ? 'translate-x-0' : '-translate-x-full',
          'w-64 md:translate-x-0'
        ]"
      >
        <EcoUser_SideBar
          :sidebarOpen="sidebarOpen"
          :navigationSections="navigationSections"
          :currentRoute="currentRoute"
          :role="role"
          :lastLogin="lastLogin"
          :status="status"
          @toggle-sidebar="toggleSidebar"
        />
      </div>

      <!-- Main Content -->
      <div class="flex-1 ml-0 md:ml-64 overflow-y-auto">
        <EcoUser_MainContent>
          <div class="mb-25 px-4 md:px-8">
            <h1 class="text-2xl font-bold text-gray-800">My Profile</h1>
            <p class="text-gray-600">View and manage your personal information.</p>
          </div>

          <EcoUser_ProfileHeader
            :username="username"
            :email="email"
            :cellphone="cellphone"
            :role="role"
            :profileImageUrl="profileImageUrl"
            :status="status"
          />

          <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 px-4 md:px-8">
            <EcoUser_PersonalInfo
              :completeName="completeName"
              :age="age"
              :birthday="birthday"
              :gender="gender"
            />
            <EcoUser_ContactInfo
              :email="email"
              :cellphone="cellphone"
              :address="address"
            />
          </div>
        </EcoUser_MainContent>
      </div>
    </div>

    <!-- Modals & Toast -->
    <EcoUser_Feedback
      :visible="showFeedbackModal"
      @close="showFeedbackModal = false"
      @submit-feedback="handleFeedbackSubmit"
    />
    <EcoUser_LogOut
      :visible="showLogoutModal"
      @cancel="showLogoutModal = false"
      @logout="logout"
    />
    <EcoUser_Toast :toast="toast" />
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { getAuth, signOut, onAuthStateChanged } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../../firebase';

import EcoUser_TopNavBar from '../EcoMist_User/EcoUser_TopNavBar.vue';
import EcoUser_SideBar from '../EcoMist_User/EcoUser_SideBar.vue';
import EcoUser_MainContent from '../EcoMist_User/EcoUser_MainContent.vue';
import EcoUser_ProfileHeader from '../EcoMist_User/EcoUser_ProfileHeader.vue';
import EcoUser_PersonalInfo from '../EcoMist_User/EcoUser_PersonalInfo.vue';
import EcoUser_ContactInfo from '../EcoMist_User/EcoUser_ContactInfo.vue';
import EcoUser_Feedback from '../EcoMist_User/EcoUser_Feedback.vue';
import EcoUser_LogOut from '../EcoMist_User/EcoUser_LogOut.vue';
import EcoUser_Toast from '../EcoMist_User/EcoUser_Toast.vue';

// Reactive states
const username = ref('');
const email = ref('');
const completeName = ref('');
const age = ref('');
const birthday = ref('');
const cellphone = ref('');
const gender = ref('');
const address = ref('');
const profileImageUrl = ref('');
const role = ref('user');
const status = ref('active');
const lastLogin = ref(new Date());

const sidebarOpen = ref(true);
const userMenuOpen = ref(false);
const notificationCount = ref(2);
const showFeedbackModal = ref(false);
const showLogoutModal = ref(false);
const toast = ref({ show: false, message: '', type: 'success' });

const route = useRoute();
const router = useRouter();
const currentRoute = computed(() => route.path);

const navigationSections = computed(() => [
  {
    title: 'GENERAL',
    routes: [
      { path: '/dashboard', name: 'Dashboard', meta: { requiresAuth: true } },
      { path: '/profile-display', name: 'Profile', meta: { requiresAuth: true } },
      { path: '/messenger', name: 'Messenger', meta: { requiresAuth: true } }
    ]
  },
  {
    title: 'USER MANAGEMENT',
    routes: [
      { path: '/edit-profile', name: 'Edit Profile', meta: { requiresAuth: true } },
      { path: '/reset-password', name: 'Reset Password', meta: { requiresAuth: true } }
    ]
  },
  {
    title: 'DATA & TOOLS',
    routes: [
      { path: '/financial-management', name: 'Financial Management', meta: { requiresAuth: true } },
      { path: '/sensor_data', name: 'Sensor Data', meta: { requiresAuth: true } },
      { path: '/model', name: 'Crop Analysis', meta: { requiresAuth: true } }
    ]
  },
  {
    title: 'ADMIN CONTROLS',
    routes: [
      { path: '/admin-dashboard', name: 'Admin Dashboard', meta: { requiresAuth: true, role: 'admin' } },
      { path: '/admin-management', name: 'Admin Management', meta: { requiresAuth: true, role: 'admin' } }
    ]
  }
]);

const toggleSidebar = () => {
  sidebarOpen.value = !sidebarOpen.value;
};

const toggleUserMenu = () => {
  userMenuOpen.value = !userMenuOpen.value;
};

const showToast = (message, type = 'success') => {
  toast.value = { show: true, message, type };
  setTimeout(() => {
    toast.value.show = false;
  }, 3000);
};

const handleFeedbackSubmit = (feedback) => {
  console.log('Feedback received:', feedback);
  showToast('Thank you for your feedback!', 'success');
};

const fetchUserProfile = async () => {
  try {
    const auth = getAuth();
    const user = auth.currentUser;
    if (!user) throw new Error('Please log in to view your profile');

    const userRef = doc(db, 'users', user.uid);
    const userSnap = await getDoc(userRef);
    if (userSnap.exists()) {
      const data = userSnap.data();
      username.value = data.username || user.displayName || 'User';
      email.value = data.email || user.email || '';
      completeName.value = data.completeName || '';
      age.value = data.age || '';
      birthday.value = data.birthday || '';
      cellphone.value = data.cellphone || '';
      gender.value = data.gender || '';
      address.value = data.address || '';
      profileImageUrl.value = data.profileImageUrl || user.photoURL || '';
      role.value = data.role || 'user';
      status.value = data.status || 'active';
      lastLogin.value = user.metadata.lastSignInTime ? new Date(user.metadata.lastSignInTime) : new Date();
    } else {
      throw new Error('User profile not found. Please complete your profile.');
    }
  } catch (err) {
    console.error(err);
    showToast(err.message || 'Failed to load profile information.', 'error');
  }
};

const logout = async () => {
  try {
    await signOut(getAuth());
    router.push('/auth');
  } catch (err) {
    console.error('Error logging out:', err);
    showToast('Failed to log out. Please try again.', 'error');
  }
};

onMounted(() => {
  fetchUserProfile();
  const unsubscribeAuth = onAuthStateChanged(getAuth(), (user) => {
    if (!user) router.push('/auth');
  });
});
</script>
