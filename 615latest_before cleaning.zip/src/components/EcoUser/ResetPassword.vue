<template>
  <div class="min-h-screen relative overflow-x-hidden">
    <!-- Agricultural Background -->
    <div class="fixed inset-0 bg-green-900 z-0">
      <!-- Static agricultural background with farm pattern -->
      <div class="absolute inset-0 bg-[url('/farm-pattern.png')] opacity-10"></div>
      <div class="absolute w-[600px] h-[600px] rounded-full filter blur-[40px] opacity-20 bg-gradient-to-br from-green-500 to-green-600 -top-[200px] -left-[200px]"></div>
      <div class="absolute w-[500px] h-[500px] rounded-full filter blur-[40px] opacity-20 bg-gradient-to-br from-green-700 to-green-800 -bottom-[150px] -right-[150px]"></div>
    </div>

    <!-- Reset Password Card -->
    <div class="flex items-center justify-center min-h-screen px-4 sm:px-6 py-8 sm:py-12 relative z-10">
      <div class="w-full max-w-md bg-white/95 rounded-2xl sm:rounded-3xl border border-green-100 shadow-xl overflow-hidden relative">
        <div class="absolute inset-0 bg-gradient-to-r from-transparent via-green-50/20 to-transparent animate-shine"></div>
        
        <div class="p-6 sm:p-8">
          <!-- Header -->
          <div class="text-center mb-8">
            <button @click="$router.push('/auth')" class="absolute top-6 left-6 text-green-700 hover:text-green-600 transition-colors">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-5 h-5"><path d="m15 18-6-6 6-6"/></svg>
            </button>
            
            <div class="flex justify-center mb-4">
              <img src="/eco-mist-logo.png" alt="Eco-Mist Logo" class="w-16 h-16 filter drop-shadow-[0_0_10px_rgba(22,163,74,0.5)]" />
            </div>
            <h1 class="text-2xl sm:text-3xl font-bold text-green-800 mb-2">Reset Password</h1>
            <p class="text-green-600 text-sm sm:text-base">Enter your email to receive password reset instructions</p>
          </div>
          
          <!-- Form -->
          <form @submit.prevent="resetPassword" class="space-y-6">
            <div class="relative">
              <input 
                type="email" 
                v-model="email" 
                :class="{ 'pt-6': email }"
                required
                :disabled="loading"
                class="w-full bg-white border border-green-200 rounded-lg px-4 py-3 text-gray-800 focus:border-green-500 focus:outline-none focus:ring-1 focus:ring-green-500 transition-all"
              />
              <label 
                :class="{ 'text-xs top-2': email, 'top-1/2 -translate-y-1/2': !email }"
                class="absolute left-4 text-gray-500 transition-all pointer-events-none"
              >
                Email Address
              </label>
              
              <div v-if="error" class="mt-2 text-sm text-red-600">
                {{ error }}
              </div>
              <div v-if="suggestedEmail && suggestedEmail !== email" class="mt-2 text-sm text-gray-600">
                Did you mean <span class="text-green-700 font-medium cursor-pointer" @click="email = suggestedEmail">{{ suggestedEmail }}</span>?
              </div>
            </div>
            
            <button 
              type="submit" 
              :disabled="loading || !isValidEmail || resendCooldown > 0"
              class="w-full bg-gradient-to-r from-green-700 to-green-600 text-white font-semibold px-6 py-3 rounded-lg hover:-translate-y-1 transition-transform shadow-lg shadow-green-600/20 active:scale-95 touch-manipulation disabled:opacity-70 disabled:hover:translate-y-0 disabled:active:scale-100"
            >
              <span v-if="resendCooldown > 0">Wait {{ resendCooldown }}s</span>
              <span v-else-if="!loading">Send Reset Link</span>
              <span v-else class="inline-block w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
            </button>
          </form>
          
          <!-- Success Message -->
          <div v-if="success" class="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg">
            <div class="flex items-start gap-3">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-green-600 mt-0.5"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
              <p class="text-green-700 text-sm">{{ success }}</p>
            </div>
          </div>
          
          <!-- Footer -->
          <div class="mt-8 text-center">
            <p class="text-gray-600">
              Remember your password? 
              <router-link to="/auth" class="text-green-700 hover:text-green-600 font-medium">Back to Login</router-link>
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Confirmation Dialog -->
  <div v-if="showConfirmation" class="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
    <div class="bg-white p-6 rounded-lg shadow-lg">
      <p class="text-gray-800 mb-4">Are you sure you want to send the reset link to <strong>{{ email }}</strong>?</p>
      <div class="flex justify-end gap-4">
        <button @click="showConfirmation = false" class="px-4 py-2 bg-gray-200 rounded hover:bg-gray-300">Cancel</button>
        <button @click="confirmReset" class="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700">Confirm</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, watch } from "vue";
import { getAuth, sendPasswordResetEmail } from "firebase/auth";
import { trackEvent } from "../../utils/analytics"; // Assuming you have a utility for tracking events

const email = ref("");
const suggestedEmail = ref("");
const loading = ref(false);
const error = ref("");
const success = ref("");
const showConfirmation = ref(false);
const resendCooldown = ref(0);
let cooldownInterval;

const commonDomains = ["gmail.com", "yahoo.com", "outlook.com", "hotmail.com"];
const isValidEmail = computed(() => {
  return /^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$/.test(email.value);
});

const suggestEmail = () => {
  const emailParts = email.value.split("@");
  if (emailParts.length === 2) {
    const [localPart, domainPart] = emailParts;
    const closestDomain = commonDomains.find(domain => {
      return domain.startsWith(domainPart.slice(0, 3)); // Simple heuristic
    });
    suggestedEmail.value = closestDomain ? `${localPart}@${closestDomain}` : "";
  } else {
    suggestedEmail.value = "";
  }
};

watch(email, suggestEmail);

const resetPassword = async () => {
  if (!isValidEmail.value) {
    error.value = "Please enter a valid email address";
    return;
  }

  try {
    loading.value = true;
    trackEvent("ResetPasswordInitiated", { email: email.value }); // Track the reset password initiation
    showConfirmation.value = true;
  } catch (err) {
    error.value = "An error occurred. Please try again.";
  } finally {
    loading.value = false;
  }
};

const startCooldown = () => {
  resendCooldown.value = 30; // 30 seconds cooldown
  cooldownInterval = setInterval(() => {
    if (resendCooldown.value > 0) {
      resendCooldown.value--;
    } else {
      clearInterval(cooldownInterval);
    }
  }, 1000);
};

const confirmReset = async () => {
  showConfirmation.value = false;
  loading.value = true;
  error.value = "";
  success.value = "";

  try {
    const auth = getAuth();
    await sendPasswordResetEmail(auth, email.value);
    success.value = "Password reset link has been sent to your email";
    trackEvent("ResetPasswordSuccess", { email: email.value }); // Track successful reset password request
    email.value = ""; // Clear the input
    startCooldown(); // Start cooldown after successful request
  } catch (err) {
    switch (err.code) {
      case 'auth/user-not-found':
        error.value = "No account found with this email address";
        trackEvent("ResetPasswordError", { email: email.value, error: "user-not-found" }); // Track error
        break;
      case 'auth/too-many-requests':
        error.value = "Too many attempts. Please try again later";
        trackEvent("ResetPasswordError", { email: email.value, error: "too-many-requests" }); // Track error
        break;
      default:
        error.value = "Failed to send reset link. Please try again";
        trackEvent("ResetPasswordError", { email: email.value, error: "unknown" }); // Track error
    }
  } finally {
    loading.value = false;
  }
};
</script>

<style>
@keyframes shine {
  0% { transform: translateX(-100%); }
  100% { transform: translateX(100%); }
}

.animate-shine {
  animation: shine 6s infinite linear;
}

/* For better touch interactions */
.touch-manipulation {
  touch-action: manipulation;
}

@media (prefers-reduced-motion: reduce) {
  .animate-shine {
    animation: none;
  }
  
  .active\:scale-95:active,
  .hover\:-translate-y-1:hover {
    transform: none;
  }
}
</style>