<template>
  <div class="min-h-screen bg-gray-50 flex flex-col">
    <!-- Top Navigation Bar -->
    <header class="bg-gradient-to-r from-emerald-700 to-green-600 shadow-lg z-10">
      <div class="container mx-auto px-4 py-3">
        <div class="flex items-center justify-between">
          <!-- Logo and Mobile Menu Button -->
          <div class="flex items-center">
            <button @click="toggleSidebar" class="mr-3 md:hidden text-white">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
            <div class="flex items-center">
              <img src="/eco-mist-logo.png" alt="Eco-Mist Logo" class="h-7 w-7 mr-3 rounded-lg shadow-md bg-white p-1.5" @error="handleLogoError">
              <div>
                <h1 class="text-xl font-bold text-white">Eco-Mist</h1>
                <p class="text-green-100 text-xs hidden sm:block">Messenger</p>
              </div>
            </div>
          </div>

          <!-- User Profile -->
          <div class="flex items-center space-x-3">
            <!-- Notification Bell with Dropdown -->
            <div class="relative">
              <button 
                class="text-white p-1 rounded-full hover:bg-white hover:bg-opacity-10 focus:outline-none"
                @click="toggleNotificationPanel"
              >
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                </svg>
                <span v-if="notificationCount > 0" class="absolute top-0 right-0 bg-red-500 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
                  {{ notificationCount }}
                </span>
              </button>
              
              <!-- Notification Panel -->
              <div 
                v-if="notificationPanelOpen" 
                class="absolute right-0 mt-2 w-80 bg-white rounded-md shadow-lg py-1 z-20 max-h-96 overflow-y-auto"
              >
                <div class="flex justify-between items-center px-4 py-2 border-b">
                  <h3 class="font-semibold text-gray-700">Notifications</h3>
                  <div class="flex gap-2">
                    <button 
                      @click="markAllNotificationsAsRead" 
                      class="text-xs text-emerald-600 hover:text-emerald-800"
                      v-if="hasUnreadNotifications"
                    >
                      Mark all as read
                    </button>
                    <button 
                      @click="clearAllNotifications" 
                      class="text-xs text-gray-500 hover:text-gray-700"
                      v-if="notifications.length > 0"
                    >
                      Clear all
                    </button>
                  </div>
                </div>
                
                <div v-if="notifications.length === 0" class="py-4 px-4 text-center text-gray-500">
                  No notifications
                </div>
                
                <div v-for="notification in notifications" :key="notification.id" 
                  :class="[
                    'px-4 py-3 border-b hover:bg-gray-50 transition-colors cursor-pointer',
                    !notification.read ? 'bg-emerald-50' : ''
                  ]"
                  @click="handleNotificationClick(notification)"
                >
                  <div class="flex items-start">
                    <div class="flex-shrink-0 mr-3">
                      <div 
                        :class="[
                          'h-8 w-8 rounded-full flex items-center justify-center',
                          getNotificationTypeClass(notification.type)
                        ]"
                      >
                        <svg v-if="notification.type === 'message'" xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                        </svg>
                        <svg v-else-if="notification.type === 'mention'" xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path d="M18 9a3 3 0 0 0-3-3H9a3 3 0 0 0-3 3v6a3 3 0 0 0 3 3h6a3 3 0 0 0 3-3V9Z"></path>
                          <path d="M13 15 9 9l10 2-3 1.5"></path>
                        </svg>
                        <svg v-else-if="notification.type === 'reaction'" xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <circle cx="12" cy="12" r="10"></circle>
                          <path d="M8 14s1.5 2 4 2 4-2 4-2"></path>
                          <line x1="9" y1="9" x2="9.01" y2="9"></line>
                          <line x1="15" y1="9" x2="15.01" y2="9"></line>
                        </svg>
                        <svg v-else xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"></path>
                          <path d="M12 8v4"></path>
                          <path d="M12 16h.01"></path>
                        </svg>
                      </div>
                    </div>
                    <div class="flex-1 min-w-0">
                      <p class="text-sm font-medium text-gray-900">
                        {{ notification.title }}
                        <span v-if="!notification.read" class="inline-block ml-1 w-2 h-2 bg-emerald-500 rounded-full"></span>
                      </p>
                      <p class="text-xs text-gray-500 truncate">{{ notification.message }}</p>
                      <p class="text-xs text-gray-400 mt-1">{{ formatTimestamp(notification.timestamp) }}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- User Profile Dropdown -->
            <div class="relative" ref="userMenuRef">
              <button @click="toggleUserMenu" class="flex items-center space-x-2 focus:outline-none">
                <div class="bg-white text-emerald-700 h-8 w-8 rounded-full flex items-center justify-center font-bold text-sm shadow">
                  <template v-if="!profileImageUrl">{{ getInitials(username) }}</template>
                  <img 
                    v-else 
                    :src="profileImageUrl" 
                    :alt="`${username}'s profile picture`" 
                    class="h-full w-full object-cover rounded-full"
                    @error="handleImageError"
                  />
                </div>
                <span class="text-white hidden md:block">{{ username }}</span>
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-white hidden md:block" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="m6 9 6 6 6-6"></path>
                </svg>
              </button>

              <!-- User Menu Dropdown -->
              <div v-if="userMenuOpen" class="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-20">
                <router-link to="/profile-display" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Profile</router-link>
                <router-link to="/settings" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Settings</router-link>
                <a @click="confirmLogout" href="#" class="block px-4 py-2 text-sm text-red-600 hover:bg-gray-100">Logout</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>

    <!-- Main Content Area with Sidebar -->
    <div class="flex flex-1 overflow-hidden">
      <!-- Sidebar Navigation -->
      <aside :class="[
        'bg-white shadow-lg z-20 transition-all duration-300 ease-in-out',
        sidebarOpen ? 'translate-x-0' : '-translate-x-full',
        'md:translate-x-0 fixed md:relative inset-y-0 left-0 w-64 overflow-y-auto'
      ]">
        <!-- Sidebar Header -->
        <div class="p-4 border-b">
          <div class="flex items-center justify-between">
            <h2 class="text-lg font-semibold text-gray-800">Navigation</h2>
            <button @click="toggleSidebar" class="md:hidden text-gray-500 hover:text-gray-700">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>

        

        <!-- Navigation Sections -->
        <nav class="p-4">
          <div v-for="(section, sectionIndex) in navigationSections" :key="sectionIndex" class="mb-6">
            <h3 class="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">{{ section.title }}</h3>
            <ul class="space-y-1">
              <li v-for="(route, routeIndex) in getFilteredRoutes(section)" :key="routeIndex">
                <router-link 
                  :to="route.path" 
                  :class="[
                    'flex items-center px-3 py-2 text-sm rounded-md',
                    currentRoute === route.path 
                      ? 'bg-emerald-100 text-emerald-700 font-medium' 
                      : 'text-gray-700 hover:bg-gray-100'
                  ]"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" :class="currentRoute === route.path ? 'text-emerald-600' : 'text-gray-500'" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path v-if="getIconForRoute(route) === 'layout-dashboard'" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM4 13a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6zM16 13a1 1 0 011-1h2a1 1 0 011 1v6a1 1 0 01-1 1h-2a1 1 0 01-1-1v-6z" />
                    <path v-else-if="getIconForRoute(route) === 'user'" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    <path v-else-if="getIconForRoute(route) === 'user-cog'" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5.121 17.804A13.937 13.937 0 0112 16c2.5 0 4.847.655 6.879 1.804M15 10a3 3 0 11-6 0 3 3 0 016 0zm6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    <path v-else-if="getIconForRoute(route) === 'cpu'" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z" />
                    <path v-else-if="getIconForRoute(route) === 'bar-chart'" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                    <path v-else-if="getIconForRoute(route) === 'message-circle'" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                    <path v-else-if="getIconForRoute(route) === 'microscope'" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                    <path v-else stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
                  </svg>
                  {{ route.name }}
                </router-link>
              </li>
            </ul>
          </div>
        </nav>

        <!-- System Info -->
        <div class="p-4 border-t">
          <div class="bg-gray-50 rounded-lg p-3">
            <div class="flex items-center justify-between mb-2">
              <span class="text-xs font-medium text-gray-500">System Status</span>
              <span class="bg-green-100 text-green-800 text-xs px-2 py-0.5 rounded-full">Online</span>
            </div>
            <div class="text-xs text-gray-500 flex flex-col space-y-1">
              <div class="flex justify-between">
                <span>Last Login:</span>
                <span class="font-medium text-gray-700">{{ formatDate(lastLogin) }}</span>
              </div>
              <div class="flex justify-between">
                <span>Online Users:</span>
                <span class="font-medium text-gray-700">{{ onlineUsers }}</span>
              </div>
            </div>
          </div>
        </div>
      </aside>

      <!-- Main Content -->
      <main class="flex-1 overflow-y-auto bg-gray-50 p-4 md:p-6">
        <!-- Page Header -->
        <div class="mb-6">
          <h1 class="text-2xl font-bold text-gray-800">Messenger</h1>
          <p class="text-gray-600">Chat with other Eco-Mist users.</p>
        </div>

        <!-- Connection Status Banner -->
        <div v-if="!isOnline" class="mb-4 bg-red-50 border border-red-200 rounded-lg p-4 flex items-center justify-between">
          <div class="flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-red-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <line x1="1" y1="1" x2="23" y2="23"></line>
              <path d="M16.72 11.06A10.94 10.94 0 0 1 19 12.55"></path>
              <path d="M5 12.55a10.94 10.94 0 0 1 5.17-2.39"></path>
              <path d="M10.71 5.05A16 16 0 0 1 22.58 9"></path>
              <path d="M1.42 9a15.91 15.91 0 0 1 4.7-2.88"></path>
              <path d="M8.53 16.11a6 6 0 0 1 6.95 0"></path>
              <line x1="12" y1="20" x2="12.01" y2="20"></line>
            </svg>
            <span class="text-red-700 font-medium">You are currently offline. Messages will be sent when you reconnect.</span>
          </div>
          <span class="text-xs text-red-600">{{ queuedMessages.length }} message(s) queued</span>
        </div>

        <!-- Pinned Messages -->
        <div v-if="pinnedMessages.length > 0" class="mb-4 bg-emerald-50 border border-emerald-200 rounded-lg p-4">
          <div class="flex justify-between items-center mb-2">
            <h3 class="text-emerald-700 font-bold flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <line x1="12" y1="17" x2="12" y2="22"></line>
                <path d="M5 17h14v-1.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V6h1a2 2 0 0 0 0-4H8a2 2 2 0 0 0 0 4h1v4.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24Z"></path>
              </svg>
              Pinned Messages
            </h3>
            <button 
              @click="collapsePinned = !collapsePinned" 
              class="text-emerald-700 hover:text-emerald-800"
              :aria-label="collapsePinned ? 'Expand pinned messages' : 'Collapse pinned messages'"
            >
              <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path v-if="collapsePinned" d="m6 9 6 6 6-6"/>
                <path v-else d="m18 15-6-6-6 6"/>
              </svg>
            </button>
          </div>
          <div v-if="!collapsePinned">
            <div v-for="msg in pinnedMessages" :key="msg.id" class="mb-2">
              <div class="flex justify-between items-center">
                <span class="text-sm text-gray-800">{{ msg.text }}</span>
                <button 
                  @click="unpinMessage(msg.id)" 
                  class="text-xs text-red-500 hover:underline"
                  aria-label="Unpin message"
                >
                  Unpin
                </button>
              </div>
              <div class="text-xs text-gray-500">{{ formatTimestamp(msg.timestamp) }}</div>
            </div>
          </div>
        </div>
        
        <!-- Search Bar -->
        <div class="mb-4">
          <div class="relative">
            <svg xmlns="http://www.w3.org/2000/svg" class="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <circle cx="11" cy="11" r="8"></circle>
              <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
            </svg>
            <input 
              v-model="searchQuery" 
              type="text" 
              placeholder="Search messages..." 
              class="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-colors"
              aria-label="Search Messages"
            />
            <button 
              v-if="searchQuery" 
              @click="searchQuery = ''" 
              class="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
              aria-label="Clear search"
            >
              <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
              </svg>
            </button>
          </div>
        </div>
        
        <!-- Chat Card -->
        <div class="bg-white rounded-lg shadow-sm overflow-hidden relative mb-6 flex flex-col h-[calc(100vh-280px)]">
          <!-- Chat Header -->
          <div class="p-4 border-b border-gray-100 flex justify-between items-center bg-white">
            <div class="flex items-center gap-3">
              <div class="bg-emerald-100 p-2 rounded-full">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-emerald-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                </svg>
              </div>
              <h2 class="text-xl font-bold text-gray-800">Eco-Mist Chat</h2>
            </div>
            <div class="flex items-center gap-2">
              <div class="flex items-center gap-2 text-sm text-gray-600">
                <span class="inline-block w-2 h-2 bg-emerald-500 rounded-full"></span>
                <span>{{ onlineUsers }} Online</span>
              </div>
              <button 
                @click="showChatInfo = !showChatInfo" 
                class="ml-2 p-2 rounded-full hover:bg-gray-100"
                aria-label="Chat information"
              >
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <circle cx="12" cy="12" r="10"></circle>
                  <line x1="12" y1="16" x2="12" y2="12"></line>
                  <line x1="12" y1="8" x2="12.01" y2="8"></line>
                </svg>
              </button>
            </div>
          </div>
          
          <!-- Chat Info Sidebar -->
          <div 
            v-if="showChatInfo" 
            class="absolute right-0 top-16 bottom-0 w-72 bg-white border-l border-gray-200 z-20 overflow-y-auto p-4 transform transition-transform"
            :class="{ 'translate-x-0': showChatInfo, 'translate-x-full': !showChatInfo }"
          >
            <div class="flex justify-between items-center mb-4">
              <h3 class="font-bold text-gray-800">Chat Information</h3>
              <button @click="showChatInfo = false" class="text-gray-500 hover:text-gray-700">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <line x1="18" y1="6" x2="6" y2="18"></line>
                  <line x1="6" y1="6" x2="18" y2="18"></line>
                </svg>
              </button>
            </div>
            
            <div class="mb-6">
              <h4 class="text-sm font-medium text-gray-500 mb-2">Active Users</h4>
              <ul class="space-y-2">
                <li v-for="(user, index) in activeUsers" :key="index" class="flex items-center gap-2">
                  <div class="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs font-bold">
                    {{ getInitials(user.name) }}
                  </div>
                  <div>
                    <div class="text-sm font-medium">{{ user.name }}</div>
                    <div class="text-xs text-gray-500">{{ user.status }}</div>
                  </div>
                </li>
              </ul>
            </div>
            
            <div class="mb-6">
              <h4 class="text-sm font-medium text-gray-500 mb-2">Shared Files</h4>
              <ul class="space-y-2">
                <li v-for="(file, index) in sharedFiles" :key="index" class="flex items-center gap-2">
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"></path>
                    <polyline points="14 2 14 8 20 8"></polyline>
                  </svg>
                  <a href="#" class="text-sm text-emerald-600 hover:underline truncate">{{ file.name }}</a>
                </li>
              </ul>
            </div>
            
            <div>
              <h4 class="text-sm font-medium text-gray-500 mb-2">Chat Settings</h4>
              <div class="space-y-3">
                <div class="flex items-center justify-between">
                  <span class="text-sm">Notifications</span>
                  <label class="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" v-model="chatSettings.notifications" class="sr-only peer" @change="toggleNotifications">
                    <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-emerald-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                  </label>
                </div>
                <div class="flex items-center justify-between">
                  <span class="text-sm">Sound Effects</span>
                  <label class="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" v-model="chatSettings.soundEffects" class="sr-only peer">
                    <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-emerald-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                  </label>
                </div>
                <div class="flex items-center justify-between">
                  <span class="text-sm">Read Receipts</span>
                  <label class="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" v-model="chatSettings.readReceipts" class="sr-only peer">
                    <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-emerald-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                  </label>
                </div>
              </div>
            </div>
          </div>
          
          <!-- Messages Container -->
          <div 
            class="flex-1 overflow-y-auto p-4 bg-gray-50" 
            ref="messagesContainer" 
            @scroll="handleScroll"
            aria-label="Messages Container"
          >
            <div v-if="loadingMessages" class="flex justify-center items-center py-4">
              <div class="spinner">
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
              </div>
              <span class="ml-2 text-gray-500">Loading messages...</span>
            </div>
            
            <div v-if="errorLoadingMessages" class="text-center p-4 bg-red-50 border border-red-200 rounded-lg text-red-500">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 mx-auto mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <circle cx="12" cy="12" r="10"></circle>
                <line x1="12" y1="8" x2="12" y2="12"></line>
                <line x1="12" y1="16" x2="12.01" y2="16"></line>
              </svg>
              Error loading messages. Please try again.
              <button @click="retryLoadMessages" class="mt-2 px-4 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200">
                Retry
              </button>
            </div>
            
            <div v-if="messages.length === 0 && !loadingMessages" class="h-full flex flex-col items-center justify-center text-gray-500">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12 mb-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
              </svg>
              <p>No messages yet. Start the conversation!</p>
            </div>
            
            <div v-for="(msg, index) in filteredMessages" :key="msg.id" 
                 class="mb-4" 
                 :class="{'mb-1': isGroupedMessage(msg, index)}">
              <div class="flex" :class="{'justify-end': msg.userId === user.uid}">
                <div v-if="msg.userId !== user.uid && !isGroupedMessage(msg, index)" 
                     class="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs font-bold mr-2 flex-shrink-0"
                     @click="openUserProfile(msg.userId)"
                >
                  {{ getInitials(msg.username) }}
                </div>
                <div v-if="msg.userId === user.uid && !isGroupedMessage(msg, index)" class="w-8 mr-2 flex-shrink-0"></div>
                
                <div class="max-w-[75%] relative">
                  <div v-if="!isGroupedMessage(msg, index)" class="text-xs text-gray-500 mb-1">
                    {{ msg.userId === user.uid ? 'You' : msg.username }}
                  </div>
                  <div 
                    class="rounded-lg px-4 py-2 inline-block relative" 
                    :class="msg.userId === user.uid ? 'bg-emerald-600 text-white' : 'bg-white border border-gray-200 text-gray-800'"
                    @contextmenu.prevent="showMessageOptions(msg, $event)"
                    @touchstart="startHold(msg)"
                    @touchend="clearHold"
                    @click.stop="msg.userId !== user.uid && showQuickReactions(msg, $event)"
                  >
                    <span v-if="editingMessage?.id !== msg.id">
                      {{ msg.text }}
                    </span>
                    <!-- Enhanced File Preview -->
                    <div v-if="msg.fileUrl" class="mt-2">
                      <template v-if="isImageFile(msg.fileUrl)">
                        <img 
                          :src="msg.fileUrl" 
                          alt="Uploaded Image" 
                          class="max-w-full h-auto rounded-lg border border-gray-300 shadow-md cursor-pointer"
                          @click="openLightbox(msg.fileUrl)"
                        />
                      </template>
                      <template v-else-if="isPdfFile(msg.fileUrl)">
                        <div class="border border-gray-300 rounded-lg shadow-md p-2 bg-gray-50">
                          <div class="flex items-center justify-between mb-2">
                            <div class="flex items-center">
                              <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-red-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"></path>
                                <polyline points="14 2 14 8 20 8"></polyline>
                              </svg>
                              <span class="text-sm font-medium">PDF Document</span>
                            </div>
                            <div class="flex gap-2">
                              <button @click="downloadFile(msg.fileUrl)" class="text-emerald-500 hover:text-emerald-700">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                                  <polyline points="7 10 12 15 17 10"></polyline>
                                  <line x1="12" y1="15" x2="12" y2="3"></line>
                                </svg>
                              </button>
                              <a :href="msg.fileUrl" target="_blank" rel="noopener noreferrer" class="text-emerald-500 hover:text-emerald-700">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                  <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
                                  <polyline points="15 3 21 3 21 9"></polyline>
                                  <line x1="10" y1="14" x2="21" y2="3"></line>
                                </svg>
                              </a>
                            </div>
                          </div>
                          <embed 
                            :src="msg.fileUrl" 
                            type="application/pdf" 
                            class="w-full h-64 border border-gray-300 rounded-lg"
                          />
                        </div>
                      </template>
                      <template v-else-if="isVideoFile(msg.fileUrl)">
                        <video 
                          controls 
                          :src="msg.fileUrl" 
                          class="w-full h-64 border border-gray-300 rounded-lg shadow-md"
                        >
                          Your browser does not support the video tag.
                        </video>
                      </template>
                      <template v-else>
                        <div class="border border-gray-300 rounded-lg shadow-md p-3 bg-gray-50 flex items-center justify-between">
                          <div class="flex items-center">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-gray-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"></path>
                              <polyline points="14 2 14 8 20 8"></polyline>
                            </svg>
                            <span class="text-sm">{{ getFileName(msg.fileUrl) }}</span>
                          </div>
                          <div class="flex gap-2">
                            <button @click="downloadFile(msg.fileUrl)" class="text-emerald-500 hover:text-emerald-700">
                              <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                                <polyline points="7 10 12 15 17 10"></polyline>
                                <line x1="12" y1="15" x2="12" y2="3"></line>
                              </svg>
                            </button>
                            <a :href="msg.fileUrl" target="_blank" rel="noopener noreferrer" class="text-emerald-500 hover:text-emerald-700">
                              <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
                                <polyline points="15 3 21 3 21 9"></polyline>
                                <line x1="10" y1="14" x2="21" y2="3"></line>
                              </svg>
                            </a>
                          </div>
                        </div>
                      </template>
                    </div>
                    <div v-if="msg.reactions && Object.keys(msg.reactions).length > 0" class="mt-2 flex flex-wrap gap-2">
                      <div v-for="(count, emoji) in msg.reactions" :key="emoji" 
                           class="flex items-center gap-1 text-sm rounded-full px-2 py-1"
                           :class="msg.userId === user.uid ? 'bg-emerald-100 text-emerald-800' : 'bg-gray-100 text-gray-800'">
                        <span>{{ emoji }}</span>
                        <span>{{ count }}</span>
                      </div>
                    </div>
                    <div 
                      class="fixed inset-0 flex items-center justify-center bg-black/50 z-50"
                      v-if="editingMessage?.id === msg.id" 
                      @click.stop
                    >
                      <div class="bg-white border border-gray-300 rounded-lg shadow-lg p-4 w-96 max-w-[90%]">
                        <h3 class="text-lg font-bold text-gray-700 mb-2">Edit Message</h3>
                        <textarea 
                          v-model="newMessage" 
                          class="border border-gray-300 rounded px-3 py-2 text-sm w-full min-h-[100px] focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                          placeholder="Edit your message..."
                        ></textarea>
                        <div class="flex justify-end mt-4 gap-2">
                          <button 
                            @click="cancelEditing()" 
                            class="px-4 py-2 bg-gray-300 text-gray-700 rounded text-sm hover:bg-gray-400"
                          >
                            Cancel
                          </button>
                          <button 
                            @click="saveEditedMessage()" 
                            class="px-4 py-2 bg-emerald-600 text-white rounded text-sm hover:bg-emerald-700"
                          >
                            Save
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div v-if="msgOptionsVisible && selectedMessage?.id === msg.id" 
                    class="absolute top-0 right-0 bg-white border border-gray-200 rounded-lg shadow-lg p-2 flex flex-col gap-1 z-10"
                  >
                    <button v-if="msg.userId === user.uid" @click="startEditingMessage(msg)" class="text-xs text-gray-500 hover:text-gray-800 p-2 hover:bg-gray-100 rounded">
                      <div class="flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                          <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                        </svg>
                        Edit
                      </div>
                    </button>
                    <button v-if="msg.userId === user.uid" @click="deleteMessage(msg.id)" class="text-xs text-red-500 hover:text-red-800 p-2 hover:bg-gray-100 rounded">
                      <div class="flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path d="M3 6h18"></path>
                          <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"></path>
                          <path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                        </svg>
                        Delete
                      </div>
                    </button>
                    <button @click="toggleThread(msg)" class="text-xs text-emerald-500 hover:text-emerald-800 p-2 hover:bg-gray-100 rounded">
                      <div class="flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path>
                        </svg>
                        Reply
                      </div>
                    </button>
                    <button @click="pinMessage(msg)" class="text-xs text-yellow-600 hover:text-yellow-800 p-2 hover:bg-gray-100 rounded">
                      <div class="flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <line x1="12" y1="17" x2="12" y2="22"></line>
                          <path d="M5 17h14v-1.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V6h1a2 2 0 0 0 0-4H8a2 2 2 0 0 0 0 4h1v4.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24Z"></path>
                        </svg>
                        Pin
                      </div>
                    </button>
                    <button @click="copyToClipboard(msg.text)" class="text-xs text-gray-500 hover:text-gray-800 p-2 hover:bg-gray-100 rounded">
                      <div class="flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                          <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                        </svg>
                        Copy
                      </div>
                    </button>
                    <button 
                      @click="() => { msgOptionsVisible = false; selectedMessage = null; }" 
                      class="text-xs text-gray-500 hover:text-gray-800 p-2 hover:bg-gray-100 rounded"
                    >
                      <div class="flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <line x1="18" y1="6" x2="6" y2="18"></line>
                          <line x1="6" y1="6" x2="18" y2="18"></line>
                        </svg>
                        Close
                      </div>
                    </button>
                    <div class="border-t border-gray-200 my-1"></div>
                    <div class="p-1">
                      <div class="text-xs text-gray-500 mb-1">Quick Reactions</div>
                      <div class="flex flex-wrap gap-2">
                        <button v-for="emoji in ['👍', '❤️', '😂', '😮', '😢', '👏']" :key="emoji" 
                                @click="addReaction(msg.id, emoji)" 
                                class="text-lg hover:bg-gray-100 rounded-full p-1 transition-transform hover:scale-110">
                          {{ emoji }}
                        </button>
                      </div>
                    </div>
                  </div>
                  <div class="text-xs text-gray-500 mt-1 text-right">
                    {{ formatTimestamp(msg.timestamp) }}
                    <span v-if="msg.edited" class="ml-1 italic">(edited)</span>
                    <span v-if="chatSettings.readReceipts && msg.read && msg.userId === user.uid" class="ml-1 text-emerald-500">✓</span>
                  </div>
                  <!-- Threaded Replies -->
                  <div v-if="msg.showThread" class="mt-4 ml-6 border-l-2 border-emerald-200 pl-4">
                    <div v-for="reply in msg.replies" :key="reply.id" class="mb-2">
                      <div class="text-xs text-gray-500">{{ reply.username }}</div>
                      <div class="bg-gray-100 rounded-lg px-3 py-2 text-sm text-gray-800">
                        {{ reply.text }}
                      </div>
                      <div class="text-xs text-gray-400 mt-1">{{ formatTimestamp(reply.timestamp) }}</div>
                    </div>
                    <div class="mt-2 flex gap-2">
                      <input 
                        v-model="msg.newReply" 
                        type="text" 
                        placeholder="Write a reply..." 
                        class="flex-1 px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                        @keyup.enter="addReply(msg)"
                      />
                      <button 
                        @click="addReply(msg)" 
                        class="px-4 py-2 bg-emerald-600 text-white rounded-lg text-sm hover:bg-emerald-700"
                      >
                        Reply
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div v-if="typingUsers.length > 0" class="mt-2">
              <div v-for="user in typingUsers" :key="user.id" class="flex items-center mb-2">
                <div class="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs font-bold mr-2 flex-shrink-0">
                  {{ user.initials }}
                </div>
                <div class="bg-white border border-gray-200 rounded-lg px-4 py-2 inline-flex items-center">
                  <span class="typing-dot"></span>
                  <span class="typing-dot"></span>
                  <span class="typing-dot"></span>
                  <span class="ml-2 text-sm text-gray-500">{{ user.name }} is typing...</span>
                </div>
              </div>
            </div>
          </div>
          <!-- Quick Reactions Popup -->
          <div 
            v-if="quickReactionsVisible && selectedMessage" 
            id="quick-reactions"
            class="fixed bg-white rounded-lg shadow-lg p-3 z-50 border border-gray-200"
            @click.stop
          >
            <div class="flex flex-col">
              <div class="text-sm text-gray-500 mb-2 font-medium">Quick Reactions</div>
              <div class="flex gap-3">
                <button 
                  v-for="emoji in ['👍', '❤️', '😂', '😮', '😢', '👏']" 
                  :key="emoji" 
                  @click="addReaction(selectedMessage.id, emoji); quickReactionsVisible = false; selectedMessage = null;" 
                  class="text-xl hover:bg-gray-100 rounded-full p-1.5 transition-transform hover:scale-110"
                >
                  {{ emoji }}
                </button>
              </div>
            </div>
          </div>
          <!-- Message Input -->
          <div class="p-4 border-t border-gray-100 bg-white">
            <div class="flex flex-col gap-2">
              <!-- File Preview -->
              <div v-if="fileToSend" class="bg-gray-50 border border-gray-200 rounded-lg p-2 flex items-center justify-between file-preview">
                <div class="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-emerald-600 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"></path>
                    <polyline points="14 2 14 8 20 8"></polyline>
                  </svg>
                  <span class="text-sm truncate max-w-[200px]">{{ getFileName(fileToSend) }}</span>
                </div>
                <button @click="fileToSend = null" class="text-gray-500 hover:text-gray-700">
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <line x1="18" y1="6" x2="6" y2="18"></line>
                    <line x1="6" y1="6" x2="18" y2="18"></line>
                  </svg>
                </button>
              </div>
              
              <div class="flex gap-2">
                <div class="relative flex-1">
                  <textarea 
                    v-model="newMessage" 
                    @keyup.enter.exact="editingMessage ? saveEditedMessage() : sendMessage()" 
                    @input="handleTyping"
                    @focus="handleFocus"
                    placeholder="Type a message..." 
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-colors resize-none"
                    :class="{'h-10': !isMultiline, 'h-20': isMultiline}"
                    aria-label="Message Input"
                  ></textarea>
                  <div class="absolute right-2 bottom-2 flex gap-1">
                    <button 
                      @click="showEmojiPicker = !showEmojiPicker"
                      class="text-gray-500 hover:text-gray-700 p-1 rounded-full hover:bg-gray-100"
                      aria-label="Add emoji"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <circle cx="12" cy="12" r="10"></circle>
                        <path d="M8 14s1.5 2 4 2 4-2 4-2"></path>
                        <line x1="9" y1="9" x2="9.01" y2="9"></line>
                        <line x1="15" y1="9" x2="15.01" y2="9"></line>
                      </svg>
                    </button>
                  </div>
                  <!-- Emoji Picker -->
                  <div v-if="showEmojiPicker" class="absolute bottom-12 right-0 bg-white border border-gray-200 rounded-lg shadow-lg p-2 z-10">
                    <div class="grid grid-cols-8 gap-1">
                      <button 
                        v-for="emoji in commonEmojis" 
                        :key="emoji" 
                        @click="addEmojiToMessage(emoji)"
                        class="text-xl p-1 hover:bg-gray-100 rounded"
                      >
                        {{ emoji }}
                      </button>
                    </div>
                  </div>
                </div>
                <input 
                  type="file" 
                  ref="fileInput" 
                  @change="handleFileUpload" 
                  class="hidden"
                />
                <button 
                  @click="triggerFileInput"
                  class="px-3 py-2 bg-gray-200 text-gray-600 rounded-lg hover:bg-gray-300 transition-colors"
                  aria-label="Attach File"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path d="M21.44 11.05a5.5 5.5 0 0 0-7.78 0L8.5 16.21a3.5 3.5 0 1 0 4.95 4.95l5.16-5.16a1.5 1.5 0 0 0-2.12-2.12l-5.16 5.16"></path>
                  </svg>
                </button>
                <button 
                  @click="sendMessage" 
                  :disabled="!newMessage.trim() && !fileToSend"
                  class="px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  aria-label="Send Message"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <line x1="22" y1="2" x2="11" y2="13"></line>
                    <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
                  </svg>
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>

    <!-- Logout Confirmation Modal -->
    <div v-if="showLogoutModal" class="fixed inset-0 z-50 flex items-center justify-center">
      <!-- Blurred backdrop -->
      <div class="absolute inset-0 backdrop-blur-sm bg-black bg-opacity-50" @click="showLogoutModal = false"></div>
      
      <!-- Modal content -->
      <div class="bg-white rounded-lg p-6 max-w-sm mx-auto w-full relative z-10 shadow-xl">
        <h3 class="text-lg font-semibold text-gray-900 mb-4">Confirm Logout</h3>
        <p class="text-gray-600 mb-6">Are you sure you want to log out of your account?</p>
        <div class="flex justify-end gap-3">
          <button 
            @click="showLogoutModal = false" 
            class="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 transition-colors"
          >
            Cancel
          </button>
          <button 
            @click="logout" 
            class="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors flex items-center justify-center"
            :disabled="loggingOut"
          >
            <span v-if="!loggingOut">Logout</span>
            <div v-else class="flex items-center">
              <div class="spinner spinner-sm mr-2">
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
              </div>
              <span>Logging out...</span>
            </div>
          </button>
        </div>
      </div>
    </div>

    <!-- Image Lightbox -->
    <div v-if="lightboxImage" class="fixed inset-0 bg-black/90 flex items-center justify-center p-4 z-50" @click="lightboxImage = null">
      <div class="relative max-w-4xl w-full">
        <button @click.stop="lightboxImage = null" class="absolute top-2 right-2 bg-white/20 rounded-full p-2 text-white hover:bg-white/40">
          <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
          </svg>
        </button>
        <img :src="lightboxImage" class="max-h-[80vh] max-w-full mx-auto object-contain" alt="Enlarged image" />
      </div>
    </div>

    <!-- Toast Notification -->
    <div 
      v-if="toast.show" 
      class="fixed bottom-4 right-4 px-4 py-3 rounded-lg shadow-lg z-50 flex items-center"
      :class="{
        'bg-emerald-100 text-emerald-800 border-l-4 border-emerald-500': toast.type === 'success',
        'bg-red-100 text-red-800 border-l-4 border-red-500': toast.type === 'error',
        'bg-blue-100 text-blue-800 border-l-4 border-blue-500': toast.type === 'info'
      }"
    >
      <svg 
        v-if="toast.type === 'success'" 
        class="h-5 w-5 mr-2" 
        xmlns="http://www.w3.org/2000/svg" 
        viewBox="0 0 20 20" 
        fill="currentColor"
      >
        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
      </svg>
      <svg 
        v-if="toast.type === 'error'" 
        class="h-5 w-5 mr-2" 
        xmlns="http://www.w3.org/2000/svg" 
        viewBox="0 0 20 20" 
        fill="currentColor"
      >
        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd" />
      </svg>
      <svg 
        v-if="toast.type === 'info'" 
        class="h-5 w-5 mr-2" 
        xmlns="http://www.w3.org/2000/svg" 
        viewBox="0 0 20 20" 
        fill="currentColor"
      >
        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-11a1 1 0 10-2 0v2H7a1 1 0 000 2h2v2a1 1 0 102 0v-2h2a1 1 0 100-2h-2V7z" clip-rule="evenodd" />
      </svg>
      <span>{{ toast.message }}</span>
    </div>

    <!-- Browser Notification Permission Request -->
    <div v-if="showNotificationPermissionRequest" class="fixed bottom-4 left-4 bg-white border border-gray-200 rounded-lg shadow-lg p-4 w-80 z-50">
      <div class="flex items-start">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-emerald-600 mr-2 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
        </svg>
        <div>
          <h3 class="font-medium text-gray-800 mb-1">Enable Notifications</h3>
          <p class="text-sm text-gray-600 mb-3">
            Stay updated with messages, mentions, and reactions by enabling browser notifications.
          </p>
          <div class="flex gap-2">
            <button @click="requestNotificationPermission" class="px-3 py-1.5 bg-emerald-600 text-white text-sm font-medium rounded-md hover:bg-emerald-700">
              Enable
            </button>
            <button @click="dismissPermissionRequest" class="px-3 py-1.5 bg-gray-200 text-gray-700 text-sm font-medium rounded-md hover:bg-gray-300">
              Not Now
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, watch, onMounted, nextTick, onBeforeUnmount } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { getAuth, signOut, onAuthStateChanged } from "firebase/auth";
import { getFirestore, collection, addDoc, query, orderBy, onSnapshot, endBefore, limit, getDocs, doc, updateDoc, deleteDoc } from 'firebase/firestore';
import { debounce } from 'lodash';
import { getStorage, ref as storageRef, uploadBytes, getDownloadURL } from "firebase/storage";

// Dashboard state
const role = ref("user");
const username = ref("");
const notificationCount = ref(3);
const showLogoutModal = ref(false);
const sidebarOpen = ref(true);
const userMenuOpen = ref(false);
const isMobile = ref(false);
const userMenuRef = ref(null);
const isDarkMode = ref(false);
const showChatInfo = ref(false);
const collapsePinned = ref(false);
const lightboxImage = ref(null);
const showEmojiPicker = ref(false);
const isMultiline = ref(false);
const profileImageUrl = ref("");
const status = ref("active");
const lastLogin = ref(new Date());
const loggingOut = ref(false);
const toast = ref({ show: false, message: '', type: 'success' });

// Notification state
const notificationPanelOpen = ref(false);
const notifications = ref([]);
const hasUnreadNotifications = computed(() => notifications.value.some(n => !n.read));
const showNotificationPermissionRequest = ref(false);
const notificationPermission = ref(null);

// Chat state
const db = getFirestore();
const auth = getAuth();
const user = ref(null); // Initialize user as a ref
const messages = ref([]);
const newMessage = ref("");
const editingMessage = ref(null);
const fileToSend = ref(null);
const typingUsers = ref([]);
const messagesContainer = ref(null);
const isTyping = ref(false);
const selectedMessage = ref(null);
const msgOptionsVisible = ref(false);
let holdTimeout = null;
const onlineUsers = ref(5);
const quickReactionsVisible = ref(false);

// Error handling states
const errorLoadingMessages = ref(false);
const loadingMessages = ref(true);

// Chat settings
const chatSettings = ref({
  notifications: true,
  soundEffects: true,
  readReceipts: true
});

// Active users
const activeUsers = ref([
  { name: "John Doe", status: "Active now" },
  { name: "Jane Smith", status: "Active now" },
  { name: "Robert Johnson", status: "Away" }
]);

// Shared files
const sharedFiles = ref([
  { name: "Project Report.pdf", url: "#" },
  { name: "Meeting Notes.docx", url: "#" },
  { name: "Budget Forecast.xlsx", url: "#" }
]);

// Common emojis
const commonEmojis = [
  "😊", "😂", "❤️", "👍", "🙏", "😍", "🔥", "👏",
  "🎉", "🤔", "😢", "😎", "🥳", "😁", "👌", "🤣",
  "😉", "🙄", "😘", "😇", "🤝", "🤗", "😋", "😮"
];

const router = useRouter();
const route = useRoute();
const currentRoute = computed(() => route.path);

// Toggle notification panel
const toggleNotificationPanel = () => {
  notificationPanelOpen.value = !notificationPanelOpen.value;
  if (notificationPanelOpen.value) {
    markNotificationsAsRead();
  }
};

// Mark all notifications as read
const markAllNotificationsAsRead = () => {
  notifications.value = notifications.value.map(n => ({ ...n, read: true }));
  updateNotificationBadge();
};

// Clear all notifications
const clearAllNotifications = () => {
  notifications.value = [];
  updateNotificationBadge();
};

// Update notification badge count
const updateNotificationBadge = () => {
  notificationCount.value = notifications.value.filter(n => !n.read).length;
};

// Mark notifications as read
const markNotificationsAsRead = () => {
  notifications.value.forEach(notification => {
    if (!notification.read) {
      notification.read = true;
    }
  });
  updateNotificationBadge();
};

// Handle notification click
const handleNotificationClick = (notification) => {
  // Mark as read
  notification.read = true;
  updateNotificationBadge();
  
  // Handle different notification types
  if (notification.type === 'message' && notification.messageId) {
    // Scroll to relevant message
    const messageElement = document.getElementById(`message-${notification.messageId}`);
    if (messageElement) {
      messageElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
      messageElement.classList.add('highlight-message');
      setTimeout(() => {
        messageElement.classList.remove('highlight-message');
      }, 2000);
    }
  }
  
  // Close notification panel
  notificationPanelOpen.value = false;
};

// Get notification type class
const getNotificationTypeClass = (type) => {
  switch (type) {
    case 'message':
      return 'bg-emerald-100 text-emerald-600';
    case 'mention':
      return 'bg-blue-100 text-blue-600';
    case 'reaction':
      return 'bg-yellow-100 text-yellow-600';
    default:
      return 'bg-gray-100 text-gray-600';
  }
};

// Toggle notifications setting
const toggleNotifications = (event) => {
  if (event.target.checked) {
    // If turned on, request permission if not already granted
    if (window.Notification && Notification.permission !== 'granted') {
      showNotificationPermissionRequest.value = true;
    }
  }
};

// Request notification permission
const requestNotificationPermission = async () => {
  if (!('Notification' in window)) {
    showToast('Browser does not support desktop notifications', 'error');
    return;
  }
  
  try {
    const permission = await Notification.requestPermission();
    notificationPermission.value = permission;
    
    if (permission === 'granted') {
      showToast('Notifications enabled!', 'success');
    } else {
      showToast('Notification permission denied', 'info');
    }
  } catch (error) {
    console.error('Error requesting notification permission:', error);
    showToast('Failed to request notification permission', 'error');
  }
  
  showNotificationPermissionRequest.value = false;
};

// Dismiss notification permission request
const dismissPermissionRequest = () => {
  showNotificationPermissionRequest.value = false;
  localStorage.setItem('notificationPermissionDismissed', 'true');
};

// Show browser notification
const showBrowserNotification = (title, body, icon = null) => {
  if (window.Notification && Notification.permission === 'granted' && chatSettings.value.notifications) {
    const notification = new Notification(title, {
      body,
      icon: icon || '/eco-mist-logo.png'
    });
    
    notification.onclick = function() {
      window.focus();
      this.close();
    };
  }
};

// Add a new notification
const addNotification = (notification) => {
  notifications.value.unshift(notification);
  updateNotificationBadge();
  
  // Show browser notification
  if (chatSettings.value.notifications && Notification.permission === 'granted') {
    showBrowserNotification(notification.title, notification.message);
  }
};

// Toggle user menu
const toggleUserMenu = () => {
  userMenuOpen.value = !userMenuOpen.value;
};

// Close user menu when clicking outside
const handleClickOutside = (event) => {
  if (userMenuRef.value && !userMenuRef.value.contains(event.target)) {
    userMenuOpen.value = false;
  }
  if (showEmojiPicker.value && !event.target.closest('.emoji-picker')) {
    showEmojiPicker.value = false;
  }
  if (notificationPanelOpen.value && !event.target.closest('.notification-panel') && !event.target.closest('.notification-bell')) {
    notificationPanelOpen.value = false;
  }
};

// Open user profile
const openUserProfile = (userId) => {
  // Typically you would navigate to user profile
  showToast(`Opening profile for user ID: ${userId}`, 'info');
};

// Group routes by section
const navigationSections = computed(() => {
  return [
    {
      title: 'GENERAL',
      routes: routes.filter(r => 
        r.path === '/dashboard' || 
        r.path === '/profile-display' ||
        r.path === '/messenger'
      )
    },
    {
      title: 'USER MANAGEMENT',
      routes: routes.filter(r => 
        r.path === '/edit-profile' || 
        r.path === '/reset-password'
      )
    },
    {
      title: 'DATA & TOOLS',
      routes: routes.filter(r => 
        r.path === '/financial-management' || 
        r.path === '/sensor_data' || 
        r.path === '/model'
      )
    },
    {
      title: 'ADMIN CONTROLS',
      routes: routes.filter(r => 
        r.path === '/admin-dashboard' || 
        r.path === '/admin-management'
      )
    }
  ];
});

// Get initials for avatar
const getInitials = (name) => {
  if (!name) return "U";
  return name.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2);
};

// Routes configuration
const routes = [
  { path: '/auth', name: 'Login', component: 'UserAuth' },
  { path: '/edit-profile', name: 'Edit Profile', component: 'EditUserProfile', meta: { requiresAuth: true, role: 'user' } },
  { path: '/dashboard', name: 'Dashboard', component: 'UserDashboard', meta: { requiresAuth: true } },
  { path: '/profile-display', name: 'Profile', component: 'UserProfileDisplay', meta: { requiresAuth: true, role: 'user' } },
  { path: '/admin-dashboard', name: 'Admin Dashboard', component: 'AdminDashboard', meta: { requiresAuth: true, role: 'admin' } },
  { path: '/reset-password', name: 'Reset Password', component: 'ResetPassword' },
  { path: "/admin-management", name: "Admin Management", component: 'AdminManagement', meta: { requiresAuth: true, role: "admin" } },
  { path: '/financial-management', name: 'Financial Management', component: 'FinancialManagement', meta: { requiresAuth: true, role: 'user' } },
  { path: '/messenger', name: 'Messenger', component: 'MessengerChat', meta: { requiresAuth: true } },
  { path: '/sensor_data', name: 'Sensor Data', component: 'SensorData', meta: { requiresAuth: true, role: 'user' } },
  { path: '/model', name: 'Crop Disease Detector', component: 'ModelComponent', meta: { requiresAuth: true, role: 'user' } },
  { path: '/settings', name: 'Settings', component: 'Settings', meta: { requiresAuth: true } },
];

// Check if route should be shown based on user role
const shouldShowRoute = (route) => {
  if (route.path === '/auth') {
    return false;
  }
  if (route.meta?.requiresAuth) {
    if (route.meta.role && route.meta.role !== role.value) {
      return false;
    }
  }
  return true;
};

// Get filtered routes for a section
const getFilteredRoutes = (section) => {
  return section.routes.filter(route => shouldShowRoute(route));
};

// Get icon class for each route
const getIconForRoute = (route) => {
  const iconMap = {
    '/dashboard': 'layout-dashboard',
    '/profile-display': 'user',
    '/edit-profile': 'user-cog',
    '/reset-password': 'key',
    '/admin-dashboard': 'shield',
    '/admin-management': 'users',
    '/financial-management': 'bar-chart',
    '/messenger': 'message-circle',
    '/sensor_data': 'cpu',
    '/model': 'microscope',
    '/settings': 'settings'
  };
  return iconMap[route.path] || 'link';
};

// Fetch messages in real-time
const fetchMessages = () => {
  loadingMessages.value = true;
  const q = query(collection(db, "messages"), orderBy("timestamp", "desc"), limit(50));
  return onSnapshot(q, (snapshot) => {
    const newMessages = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })).reverse();
    
    // Check for new messages from others to create notifications
    if (messages.value.length > 0) {
      const lastKnownMsgTime = messages.value[messages.value.length - 1].timestamp?.seconds || 0;
      
      newMessages.forEach(msg => {
        const msgTimestamp = msg.timestamp?.seconds || 0;
        if (
          msgTimestamp > lastKnownMsgTime && 
          msg.userId !== user.value?.uid && 
          !messages.value.some(m => m.id === msg.id)
        ) {
          // Create notification for new message
          addNotification({
            id: Date.now(),
            type: 'message',
            title: `New message from ${msg.username}`,
            message: msg.text.length > 30 ? msg.text.substring(0, 30) + '...' : msg.text,
            timestamp: new Date(),
            read: false,
            messageId: msg.id
          });
          
          // Play sound for new message if enabled
          if (chatSettings.value.soundEffects) {
            playMessageSound('receive');
          }
        }
      });
    }
    
    messages.value = newMessages;
    
    // Mark messages as read if read receipts enabled
    if (chatSettings.value.readReceipts) {
      markMessagesAsRead(newMessages);
    }
    
    loadingMessages.value = false;
    nextTick(() => scrollToBottom());
  }, (error) => {
    console.error("Error fetching messages:", error);
    errorLoadingMessages.value = true;
    loadingMessages.value = false;
  });
};

// Mark messages as read
const markMessagesAsRead = async (msgs) => {
  if (!user.value) return;
  
  for (const msg of msgs) {
    if (msg.userId !== user.value.uid && !msg.read) {
      try {
        const docRef = doc(db, "messages", msg.id);
        await updateDoc(docRef, { read: true });
      } catch (error) {
        console.error("Error marking message as read:", error);
      }
    }
  }
};

// Retry loading messages
const retryLoadMessages = () => {
  errorLoadingMessages.value = false;
  loadingMessages.value = true;
  setTimeout(() => {
    fetchMessages();
  }, 1000);
};

// Lazy loading for messages
const handleScroll = debounce(() => {
  if (!messagesContainer.value) return;
  const { scrollTop, scrollHeight, clientHeight } = messagesContainer.value;
  if (scrollTop === 0 && !loadingMessages.value) {
    loadMoreMessages();
  }
}, 200);

const loadMoreMessages = async () => {
  if (messages.value.length === 0) return;
  
  loadingMessages.value = true;
  try {
    // Fetch older messages logic here
    const oldestMessage = messages.value[0];
    const q = query(
      collection(db, "messages"),
      orderBy("timestamp"),
      endBefore(oldestMessage.timestamp),
      limit(20)
    );
    const snapshot = await getDocs(q);
    const olderMessages = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    messages.value = [...olderMessages, ...messages.value];
  } catch (error) {
    console.error("Error loading more messages:", error);
    errorLoadingMessages.value = true;
  } finally {
    loadingMessages.value = false;
  }
};

// Send message with optional file
const sendMessage = async () => {
  if (!newMessage.value.trim() && !fileToSend.value) return;
  
  if (!user.value) {
    showToast("You must be logged in to send messages", "error");
    return;
  }
  
  const message = {
    text: newMessage.value,
    fileUrl: fileToSend.value || null,
    userId: user.value.uid,
    username: username.value || user.value.displayName || "Anonymous",
    timestamp: new Date(),
    edited: false,
    read: false
  };
  
  if (isOnline.value) {
    try {
      const docRef = await addDoc(collection(db, "messages"), message);
      
      // Update the message with its ID
      message.id = docRef.id;
      
      if (chatSettings.value.soundEffects) {
        playMessageSound('send');
      }
      
      // Check if message contains mentions
      const mentionRegex = /@(\w+)/g;
      const mentions = newMessage.value.match(mentionRegex);
      
      if (mentions && mentions.length > 0) {
        // Process mentions and notify mentioned users
        mentions.forEach(mention => {
          const username = mention.substring(1);
          // In a real app, you would have a user database to match usernames
          console.log(`User ${username} mentioned in a message`);
        });
      }
    } catch (error) {
      console.error("Error sending message:", error);
      showToast("Failed to send message. Please try again.", "error");
    }
  } else {
    queueMessage(message);
    showToast("You are offline. Your message has been queued and will be sent when you reconnect.", "info");
  }
  
  newMessage.value = "";
  fileToSend.value = null;
  isMultiline.value = false;
  showEmojiPicker.value = false;
};

// Play message sound
const playMessageSound = (type) => {
  if (!chatSettings.value.soundEffects) return;
  
  const audio = new Audio();
  if (type === 'send') {
    audio.src = '/sounds/message-sent.mp3';
  } else if (type === 'receive') {
    audio.src = '/sounds/message-received.mp3';
  }
  audio.play().catch(e => console.log('Error playing sound:', e));
};

// Scroll to bottom of messages
const scrollToBottom = () => {
  setTimeout(() => {
    if (messagesContainer.value) {
      messagesContainer.value.scrollTo({ 
        top: messagesContainer.value.scrollHeight, 
        behavior: 'smooth' 
      });
    }
  }, 100);
};

// Format timestamp
const formatTimestamp = (timestamp) => {
  if (!timestamp) return "";
  
  const date = timestamp.seconds ? new Date(timestamp.seconds * 1000) : new Date(timestamp);
  const now = new Date();
  const diff = Math.floor((now - date) / 1000);
  
  if (diff < 60) return "Just now";
  if (diff < 3600) return `${Math.floor(diff / 60)} min ago`;
  if (diff < 86400) return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  return date.toLocaleDateString();
};

// Format date for profile display
const formatDate = (date, includeTime = false) => {
  if (!date) return '';
  
  const now = new Date();
  const diff = now - new Date(date);
  
  if (!includeTime) {
    // Less than a minute
    if (diff < 60000) {
      return 'Just now';
    }
    
    // Less than an hour
    if (diff < 3600000) {
      return `${Math.floor(diff / 60000)}m ago`;
    }
    
    // Less than a day
    if (diff < 86400000) {
      return `${Math.floor(diff / 3600000)}h ago`;
    }
    
    // Less than a week
    if (diff < 604800000) {
      return `${Math.floor(diff / 86400000)}d ago`;
    }
  }
  
  // Format as date with time if includeTime is true
  const options = {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    ...(includeTime && { hour: '2-digit', minute: '2-digit' })
  };
  
  return new Date(date).toLocaleDateString('en-US', options);
};

// Check if message should be grouped with previous message
const isGroupedMessage = (message, index) => {
  if (index === 0) return false;
  
  const prevMessage = messages.value[index - 1];
  const timeDiff = message.timestamp.seconds - prevMessage.timestamp.seconds;
  
  // Group if same user and less than 2 minutes apart
  return message.userId === prevMessage.userId && timeDiff < 120;
};

// Handle typing indicator
const handleTyping = debounce(() => {
  isTyping.value = true;
  // Check if message has multiple lines
  isMultiline.value = newMessage.value.includes('\n') || newMessage.value.length > 100;
  
  // Simulate sending typing status to server
  setTimeout(() => {
    isTyping.value = false;
  }, 3000);
}, 300);

// Typing indicator simulation
const handleFocus = () => {
  simulateTypingUsers();
};

// Check if device is mobile
const checkIfMobile = () => {
  isMobile.value = window.innerWidth < 768;
  if (isMobile.value) {
    sidebarOpen.value = false;
  } else {
    // Get saved sidebar state or default to open on desktop
    const savedState = localStorage.getItem('sidebarOpen');
    sidebarOpen.value = savedState !== null ? savedState === 'true' : true;
  }
};

// Toggle sidebar
const toggleSidebar = () => {
  sidebarOpen.value = !sidebarOpen.value;
  localStorage.setItem('sidebarOpen', sidebarOpen.value.toString());
  
  if (isMobile.value && sidebarOpen.value) {
    document.body.style.overflow = 'hidden';
  } else {
    document.body.style.overflow = '';
  }
};

const confirmLogout = () => {
  showLogoutModal.value = true;
};

const logout = async () => {
  loggingOut.value = true;
  try {
    sessionStorage.removeItem('lastSessionTime');
    await signOut(auth);
    
    // Simulate a delay to show the spinner
    setTimeout(() => {
      router.push('/auth');
      loggingOut.value = false;
      showLogoutModal.value = false;
    }, 1000);
  } catch (error) {
    console.error("Error logging out:", error);
    loggingOut.value = false;
    showToast("Error logging out. Please try again.", "error");
  }
};

// Watch for route changes to close sidebar on mobile
watch(currentRoute, () => {
  if (isMobile.value) {
    sidebarOpen.value = false;
    document.body.style.overflow = '';
  }
  // Close user menu when route changes
  userMenuOpen.value = false;
});

// Handle window resize
const handleResize = () => {
  checkIfMobile();
};

// Handle image error
const handleImageError = (e) => {
  e.target.style.display = 'none';
  e.target.parentNode.classList.add('bg-emerald-600');
  const initials = document.createElement('div');
  initials.className = 'flex items-center justify-center h-full w-full text-white text-3xl font-bold';
  initials.textContent = getInitials(username.value);
  e.target.parentNode.appendChild(initials);
};

// Handle logo error
const handleLogoError = (e) => {
  e.target.src = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="%2316a34a" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12a10 10 0 1 1 20 0 10 10 0 0 1-20 0Z"/><path d="M2 12h20"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>';
};

// Initialize component
let unsubscribeMessages = null;
onMounted(async () => {
  // Check if mobile on initial load
  checkIfMobile();
  // Add resize event listener
  window.addEventListener('resize', handleResize);
  // Add click outside listener for user menu
  document.addEventListener('click', handleClickOutside);
  
  // Check notification permission
  if (window.Notification) {
    notificationPermission.value = Notification.permission;
    
    // Show permission request if not already granted or denied
    if (
      Notification.permission !== 'granted' && 
      Notification.permission !== 'denied' &&
      !localStorage.getItem('notificationPermissionDismissed')
    ) {
      setTimeout(() => {
        showNotificationPermissionRequest.value = true;
      }, 3000);
    }
  }
  
  // Add sample notifications for demo
  setTimeout(() => {
    notifications.value = [
      {
        id: 1,
        type: 'message',
        title: 'New message from John Doe',
        message: 'Hey, do you have a minute to chat?',
        timestamp: new Date(Date.now() - 1000 * 60 * 5), // 5 minutes ago
        read: false
      },
      {
        id: 2,
        type: 'mention',
        title: 'You were mentioned',
        message: 'Jane Smith mentioned you in a message.',
        timestamp: new Date(Date.now() - 1000 * 60 * 15), // 15 minutes ago
        read: false
      },
      {
        id: 3,
        type: 'reaction',
        title: 'New reaction',
        message: 'Robert Johnson reacted with 👍 to your message.',
        timestamp: new Date(Date.now() - 1000 * 60 * 60), // 1 hour ago
        read: true
      }
    ];
    updateNotificationBadge();
  }, 1000);
  
  // Get current user
  onAuthStateChanged(auth, (currentUser) => {
    if (currentUser) {
      user.value = currentUser;
      username.value = currentUser.displayName || "User";
      profileImageUrl.value = currentUser.photoURL || "";
    } else {
      // Redirect to login if no user is authenticated
      router.push('/auth');
    }
  });
  
  // Subscribe to messages
  unsubscribeMessages = fetchMessages();
});

// Cleanup on component unmount
onBeforeUnmount(() => {
  window.removeEventListener('resize', handleResize);
  document.removeEventListener('click', handleClickOutside);
  if (unsubscribeMessages) {
    unsubscribeMessages();
  }
});

// Start editing a message
const startEditingMessage = (msg) => {
  editingMessage.value = { ...msg };
  newMessage.value = msg.text;
  msgOptionsVisible.value = false;
};

// Save edited message and hide options
const saveEditedMessage = async () => {
  if (!editingMessage.value) return;
  try {
    const docRef = doc(db, "messages", editingMessage.value.id);
    await updateDoc(docRef, { 
      text: newMessage.value,
      edited: true
    });
    const index = messages.value.findIndex((msg) => msg.id === editingMessage.value.id);
    if (index !== -1) {
      messages.value[index].text = newMessage.value;
      messages.value[index].edited = true;
    }
    editingMessage.value = null;
    newMessage.value = "";
    msgOptionsVisible.value = false;
    selectedMessage.value = null;
    showToast("Message updated successfully", "success");
  } catch (error) {
    console.error("Error editing message:", error);
    showToast("Failed to update message", "error");
  }
};

// Cancel editing and hide options
const cancelEditing = () => {
  editingMessage.value = null;
  newMessage.value = "";
  msgOptionsVisible.value = false;
  selectedMessage.value = null;
};

// Delete a message
const deleteMessage = async (messageId) => {
  try {
    const docRef = doc(db, "messages", messageId);
    await deleteDoc(docRef);
    msgOptionsVisible.value = false;
    selectedMessage.value = null;
    showToast("Message deleted", "success");
  } catch (error) {
    console.error("Error deleting message:", error);
    showToast("Failed to delete message", "error");
  }
};

// Handle file upload
const handleFileUpload = async (event) => {
  const file = event.target.files[0];
  if (!file) return;
  
  // Show loading indicator
  const loadingToast = showToast('Uploading file...', 'loading');
  
  try {
    const storage = getStorage();
    const storageReference = storageRef(storage, `uploads/${Date.now()}_${file.name}`);
    await uploadBytes(storageReference, file);
    const fileUrl = await getDownloadURL(storageReference);
    fileToSend.value = fileUrl;
    
    // Hide loading indicator and show success
    hideToast(loadingToast);
    showToast('File uploaded successfully!', 'success');
  } catch (error) {
    console.error("Error uploading file:", error);
    hideToast(loadingToast);
    showToast('Failed to upload file. Please try again.', 'error');
  }
};

// Simple toast notification system
const showToast = (message, type = 'info') => {
  if (type === 'loading') {
    // For loading toasts, return a unique ID
    const id = Date.now();
    toast.value = { show: true, message, type };
    return id;
  } else {
    // For regular toasts, show for 3 seconds
    toast.value = { show: true, message, type };
    setTimeout(() => {
      toast.value.show = false;
    }, 3000);
    return null;
  }
};

const hideToast = (id) => {
  if (id) {
    toast.value.show = false;
  }
};

// Trigger file input
const triggerFileInput = () => {
  if (fileInput.value) {
    fileInput.value.click();
  } else {
    console.error("File input reference is not defined.");
  }
};

// Show message options on right-click or hold
const showMessageOptions = (msg, event) => {
  selectedMessage.value = msg;
  msgOptionsVisible.value = true;
  event.stopPropagation();
};

// Start hold for touch devices
const startHold = (msg) => {
  holdTimeout = setTimeout(() => {
    selectedMessage.value = msg;
    msgOptionsVisible.value = true;
  }, 500); // 500ms hold duration
};

// Clear hold timeout
const clearHold = () => {
  clearTimeout(holdTimeout);
};

// Hide message options and reset editing state
const hideMessageOptions = (event) => {
  // Ensure the click is outside the pop-up menu and the selected message
  if (
    (msgOptionsVisible.value || quickReactionsVisible.value) &&
    !event.target.closest('.absolute') && 
    !event.target.closest('.relative') &&
    !event.target.closest('#quick-reactions')
  ) {
    msgOptionsVisible.value = false;
    quickReactionsVisible.value = false;
    selectedMessage.value = null;
  }
};

// Show quick reactions for other users' messages
const showQuickReactions = (msg, event) => {
  if (msg.userId === user.value?.uid) return; // Don't show for own messages
  selectedMessage.value = msg;
  msgOptionsVisible.value = false; // Hide other options
  quickReactionsVisible.value = true;
  // Position the reactions near the message
  nextTick(() => {
    const reactionsEl = document.getElementById('quick-reactions');
    if (reactionsEl) {
      const rect = event.target.getBoundingClientRect();
      reactionsEl.style.top = `${rect.bottom + 10}px`;
      reactionsEl.style.left = `${rect.left}px`;
    }
  });
  event.stopPropagation();
};

// Define the file input reference
const fileInput = ref(null);

// Add reaction to a message
const addReaction = async (messageId, emoji) => {
  try {
    const docRef = doc(db, "messages", messageId);
    const message = messages.value.find((msg) => msg.id === messageId);
    if (!message) return;

    const reactions = message.reactions || {};
    reactions[emoji] = (reactions[emoji] || 0) + 1;

    await updateDoc(docRef, { reactions });
    
    // Update message locally
    message.reactions = reactions;
    
    // Notify original author
    if (message.userId !== user.value?.uid) {
      addNotification({
        id: Date.now(),
        type: 'reaction',
        title: 'New reaction',
        message: `${username.value} reacted with ${emoji} to your message.`,
        timestamp: new Date(),
        read: false,
        messageId: messageId
      });
    }
    
    msgOptionsVisible.value = false;
    selectedMessage.value = null;
  } catch (error) {
    console.error("Error adding reaction:", error);
    showToast("Failed to add reaction", "error");
  }
};

// Add emoji to message input
const addEmojiToMessage = (emoji) => {
  newMessage.value += emoji;
  showEmojiPicker.value = false;
};

// Search query state
const searchQuery = ref("");

// Computed property to filter messages based on the search query
const filteredMessages = computed(() => {
  if (!searchQuery.value.trim()) {
    return messages.value;
  }
  const query = searchQuery.value.toLowerCase();
  return messages.value.filter(msg => 
    msg.text?.toLowerCase().includes(query) || 
    msg.username?.toLowerCase().includes(query)
  );
});

// Pinned messages state
const pinnedMessages = ref([]);

// Pin a message
const pinMessage = (msg) => {
  if (!pinnedMessages.value.find(pinned => pinned.id === msg.id)) {
    pinnedMessages.value.push(msg);
    showToast(`Message pinned successfully!`, 'success');
  }
  msgOptionsVisible.value = false;
  selectedMessage.value = null;
};

// Unpin a message
const unpinMessage = (messageId) => {
  pinnedMessages.value = pinnedMessages.value.filter(msg => msg.id !== messageId);
  showToast(`Message unpinned`, 'info');
};

// Simulate typing indicators for multiple users
const simulateTypingUsers = () => {
  typingUsers.value = [
    { id: 1, name: "Jane Smith", initials: "JS" }
  ];
  setTimeout(() => {
    typingUsers.value = [];
  }, 3000); // Clear typing indicators after 3 seconds
};

// Toggle thread visibility for a message
const toggleThread = (msg) => {
  msg.showThread = !msg.showThread;
  if (!msg.replies) {
    msg.replies = [];
  }
  if (!msg.newReply) {
    msg.newReply = "";
  }
  msgOptionsVisible.value = false;
  selectedMessage.value = null;
};

// Add a reply to a message thread
const addReply = async (msg) => {
  if (!msg.newReply.trim()) return;
  try {
    const docRef = doc(db, "messages", msg.id);
    const reply = {
      id: Date.now().toString(),
      text: msg.newReply,
      username: username.value || "Anonymous",
      timestamp: new Date(),
    };
    const updatedReplies = [...(msg.replies || []), reply];
    await updateDoc(docRef, { replies: updatedReplies });
    msg.replies = updatedReplies; // Update locally
    msg.newReply = "";
    
    // Create notification for thread reply
    if (msg.userId !== user.value?.uid) {
      addNotification({
        id: Date.now(),
        type: 'message',
        title: 'New reply',
        message: `${username.value} replied to your message: "${reply.text.substring(0, 30)}${reply.text.length > 30 ? '...' : ''}"`,
        timestamp: new Date(),
        read: false,
        messageId: msg.id
      });
    }
    
    showToast("Reply added", "success");
  } catch (error) {
    console.error("Error adding reply:", error);
    showToast("Failed to add reply", "error");
  }
};

// Helper function to check if a file is an image
const isImageFile = (fileUrl) => {
  return /\.(jpg|jpeg|png|gif|bmp|webp)$/i.test(fileUrl);
};

// Helper function to check if a file is a PDF
const isPdfFile = (fileUrl) => {
  return /\.pdf$/i.test(fileUrl);
};

// Helper function to check if a file is a video
const isVideoFile = (fileUrl) => {
  return /\.(mp4|webm|ogg)$/i.test(fileUrl);
};

// Get file name from URL
const getFileName = (fileUrl) => {
  if (!fileUrl) return "";
  const parts = fileUrl.split('/');
  let fileName = parts[parts.length - 1];
  // Remove query parameters if any
  fileName = fileName.split('?')[0];
  // Decode URI components
  return decodeURIComponent(fileName);
};

// Open image in lightbox
const openLightbox = (imageUrl) => {
  lightboxImage.value = imageUrl;
};

// Offline Mode
const isOnline = ref(navigator.onLine);
const queuedMessages = ref([]);

const queueMessage = (message) => {
  queuedMessages.value.push(message);
  localStorage.setItem("queuedMessages", JSON.stringify(queuedMessages.value));
};

const sendQueuedMessages = async () => {
  if (queuedMessages.value.length === 0) return;
  
  const loadingToast = showToast(`Sending ${queuedMessages.value.length} queued message(s)...`, 'loading');
  
  const queued = [...queuedMessages.value];
  queuedMessages.value = [];
  localStorage.removeItem("queuedMessages");

  try {
    for (const message of queued) {
      await addDoc(collection(db, "messages"), message);
    }
    hideToast(loadingToast);
    showToast('All queued messages sent successfully!', 'success');
  } catch (error) {
    console.error("Error sending queued messages:", error);
    hideToast(loadingToast);
    showToast('Failed to send some queued messages', 'error');
    
    // Put failed messages back in queue
    queuedMessages.value = queued;
    localStorage.setItem("queuedMessages", JSON.stringify(queuedMessages.value));
  }
};

// Handle online/offline events
const handleOnlineStatus = () => {
  isOnline.value = navigator.onLine;
  if (isOnline.value) {
    sendQueuedMessages();
  }
};

// Initialize offline mode
onMounted(() => {
  window.addEventListener("online", handleOnlineStatus);
  window.addEventListener("offline", handleOnlineStatus);
  
  isOnline.value = navigator.onLine;
  
  const queued = localStorage.getItem("queuedMessages");
  if (queued) {
    queuedMessages.value = JSON.parse(queued);
  }
});

// Copy text to clipboard
const copyToClipboard = (text) => {
  navigator.clipboard.writeText(text).then(() => {
    showToast("Text copied to clipboard!", "success");
    msgOptionsVisible.value = false;
    selectedMessage.value = null;
  }).catch((err) => {
    console.error("Failed to copy text: ", err);
    showToast("Failed to copy text", "error");
  });
};

// Download file
const downloadFile = (fileUrl) => {
  const link = document.createElement('a');
  link.href = fileUrl;
  link.download = getFileName(fileUrl);
  link.click();
};
</script>

<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');

/* Base Styles */
.min-h-screen {
  min-height: 100vh;
}

/* Spinner Animation */
.spinner {
  width: 44px;
  height: 44px;
  animation: spinner-rotation 2s infinite ease;
  transform-style: preserve-3d;
}

.spinner > div {
  background-color: rgba(16, 185, 129, 0.2);
  height: 100%;
  position: absolute;
  width: 100%;
  border: 2px solid #10b981;
}

.spinner div:nth-of-type(1) {
  transform: translateZ(-22px) rotateY(180deg);
}

.spinner div:nth-of-type(2) {
  transform: rotateY(-270deg) translateX(50%);
  transform-origin: top right;
}

.spinner div:nth-of-type(3) {
  transform: rotateY(270deg) translateX(-50%);
  transform-origin: center left;
}

.spinner div:nth-of-type(4) {
  transform: rotateX(90deg) translateY(-50%);
  transform-origin: top center;
}

.spinner div:nth-of-type(5) {
  transform: rotateX(-90deg) translateY(50%);
  transform-origin: bottom center;
}

.spinner div:nth-of-type(6) {
  transform: translateZ(22px);
}

/* Smaller spinner for buttons */
.spinner-sm {
  width: 24px;
  height: 24px;
}

@keyframes spinner-rotation {
  0% {
    transform: rotate(45deg) rotateX(-25deg) rotateY(25deg);
  }

  50% {
    transform: rotate(45deg) rotateX(-385deg) rotateY(25deg);
  }

  100% {
    transform: rotate(45deg) rotateX(-385deg) rotateY(385deg);
  }
}

/* Typing indicator */
.typing-dot {
  display: inline-block;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background-color: #10b981;
  margin: 0 2px;
  animation: typing 1.4s infinite ease-in-out both;
}

.typing-dot:nth-child(1) {
  animation-delay: 0s;
}

.typing-dot:nth-child(2) {
  animation-delay: 0.2s;
}

.typing-dot:nth-child(3) {
  animation-delay: 0.4s;
}

@keyframes typing {
  0%, 80%, 100% {
    transform: scale(0.6);
    opacity: 0.4;
  }
  40% {
    transform: scale(1);
    opacity: 1;
  }
}

/* Focus styles for accessibility */
button:focus-visible,
a:focus-visible {
  outline: 2px solid #10b981;
  outline-offset: 2px;
}

/* Highlight a message (for navigation from notifications) */
.highlight-message {
  animation: highlight-pulse 2s ease-in-out;
}

@keyframes highlight-pulse {
  0%, 100% {
    background-color: transparent;
  }
  50% {
    background-color: rgba(16, 185, 129, 0.2);
  }
}

/* Responsive Styles */
@media (prefers-reduced-motion: reduce) {
  .spinner, .spinner-sm {
    animation-duration: 0.001ms !important;
    animation-iteration-count: 1 !important;
  }
  
  .transition-all, .transition-colors {
    transition-duration: 0.001ms !important;
  }
  
  .typing-dot {
    animation: none !important;
  }
  
  .highlight-message {
    animation: none !important;
    background-color: rgba(16, 185, 129, 0.1);
  }
}
</style>