<template>
  <div class="min-h-screen bg-gray-50 flex flex-col">
    <!-- Top Navigation Bar -->
    <header class="bg-gradient-to-r from-emerald-700 to-green-600 shadow-lg z-10">
      <div class="container mx-auto px-4 py-3">
        <div class="flex items-center justify-between">
          <!-- Logo and Mobile Menu Button -->
          <div class="flex items-center">
            <button @click="toggleSidebar" class="mr-3 md:hidden text-white">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
            <div class="flex items-center">
              <div class="bg-white p-1.5 rounded-lg shadow-md mr-3">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-7 w-7 text-emerald-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M12 2v8"></path>
                  <path d="M4.93 10.93l1.41 1.41"></path>
                  <path d="M2 18h2"></path>
                  <path d="M20 18h2"></path>
                  <path d="M19.07 10.93l-1.41 1.41"></path>
                  <path d="M22 22H2"></path>
                  <path d="M16 16a4 4 0 0 1-8 0"></path>
                  <path d="M12 12a2 2 0 0 0-2 2"></path>
                </svg>
              </div>
              <div>
                <h1 class="text-xl font-bold text-white">Eco-Mist</h1>
                <p class="text-green-100 text-xs hidden sm:block">Crop Disease Detection</p>
              </div>
            </div>
          </div>

          <!-- System Status and User Profile -->
          <div class="flex items-center space-x-3">
            <!-- System Status Badge -->
            <div v-if="result" :class="[getStatusClass(), 'px-2 py-1 rounded-full text-xs font-medium hidden sm:block']">
              {{ result ? result.prediction : 'No Analysis' }}
            </div>

            <!-- Theme Toggle -->
            <button @click="toggleTheme" class="text-white p-1 rounded-full hover:bg-white hover:bg-opacity-10 focus:outline-none">
              <svg v-if="isDarkMode" xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
              </svg>
              <svg v-else xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
              </svg>
            </button>

            <!-- User Profile Dropdown -->
            <div class="relative" ref="userMenuRef">
              <button @click="toggleUserMenu" class="flex items-center space-x-2 focus:outline-none">
                <div class="bg-white text-emerald-700 h-8 w-8 rounded-full flex items-center justify-center font-bold text-sm shadow">
                  {{ user ? getInitials(user.email) : 'G' }}
                </div>
                <span class="text-white hidden md:block">{{ user ? user.email.split('@')[0] : 'Guest' }}</span>
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-white hidden md:block" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="m6 9 6 6 6-6"></path>
                </svg>
              </button>

              <!-- User Menu Dropdown -->
              <div v-if="userMenuOpen" class="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-20">
                <a href="/profile-display" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Profile</a>
                <a href="/dashboard" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Dashboard</a>
                <a v-if="user" @click="logout" href="#" class="block px-4 py-2 text-sm text-red-600 hover:bg-gray-100">Logout</a>
                <a v-else @click="authMode = 'login'; showAuthModal = true" href="#" class="block px-4 py-2 text-sm text-emerald-600 hover:bg-gray-100">Login</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>

    <!-- Main Content Area with Sidebar -->
    <div class="flex flex-1 overflow-hidden">
      <!-- Sidebar Navigation -->
      <aside :class="[
        'bg-white shadow-lg z-20 transition-all duration-300 ease-in-out',
        sidebarOpen ? 'translate-x-0' : '-translate-x-full',
        'md:translate-x-0 fixed md:relative inset-y-0 left-0 w-64 overflow-y-auto'
      ]">
        <!-- Sidebar Header -->
        <div class="p-4 border-b">
          <div class="flex items-center justify-between">
            <h2 class="text-lg font-semibold text-gray-800">Navigation</h2>
            <button @click="toggleSidebar" class="md:hidden text-gray-500 hover:text-gray-700">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>

        <!-- Navigation Sections -->
        <nav class="p-4">
          <div v-for="(section, sectionIndex) in navigationSections" :key="sectionIndex" class="mb-6">
            <h3 class="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">{{ section.title }}</h3>
            <ul class="space-y-1">
              <li v-for="(route, routeIndex) in getFilteredRoutes(section)" :key="routeIndex">
                <a 
                  :href="route.path" 
                  :class="[
                    'flex items-center px-3 py-2 text-sm rounded-md',
                    currentRoute === route.path 
                      ? 'bg-emerald-100 text-emerald-700 font-medium' 
                      : 'text-gray-700 hover:bg-gray-100'
                  ]"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" :class="currentRoute === route.path ? 'text-emerald-600' : 'text-gray-500'" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path v-if="getIconForRoute(route) === 'layout-dashboard'" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM4 13a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6zM16 13a1 1 0 011-1h2a1 1 0 011 1v6a1 1 0 01-1 1h-2a1 1 0 01-1-1v-6z" />
                    <path v-else-if="getIconForRoute(route) === 'user'" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    <path v-else-if="getIconForRoute(route) === 'cpu'" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z" />
                    <path v-else stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
                  </svg>
                  {{ route.name }}
                </a>
              </li>
            </ul>
          </div>
        </nav>

        <!-- System Info -->
        <div class="p-4 border-t">
          <div class="bg-gray-50 rounded-lg p-3">
            <div class="flex items-center justify-between mb-2">
              <span class="text-xs font-medium text-gray-500">Analysis Status</span>
              <span :class="[
                result ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800',
                'text-xs px-2 py-0.5 rounded-full'
              ]">
                {{ result ? 'Analyzed' : 'Ready' }}
              </span>
            </div>
            <div class="text-xs text-gray-500 flex flex-col space-y-1">
              <div class="flex justify-between">
                <span>Total Analyses:</span>
                <span class="font-medium text-gray-700">{{ analysisHistory.length }}</span>
              </div>
              <div class="flex justify-between">
                <span>Last Analysis:</span>
                <span class="font-medium text-gray-700">{{ analysisHistory.length > 0 ? formatDate(analysisHistory[0].date) : 'None' }}</span>
              </div>
              <div class="flex justify-between">
                <span>Healthy Plants:</span>
                <span class="font-medium text-gray-700">{{ analyticsSummary.healthy }}</span>
              </div>
            </div>
          </div>
        </div>
      </aside>

      <!-- Main Content -->
      <main class="flex-1 overflow-y-auto bg-gray-50 p-4 md:p-6">
        <!-- Page Header -->
        <div class="mb-6">
          <h1 class="text-2xl font-bold text-gray-800">Crop Disease Detector</h1>
          <p class="text-gray-600">Analyze plant images to detect diseases and maintain crop health</p>
        </div>

        <!-- View Mode Selector -->
        <div class="bg-white rounded-lg shadow-sm p-4 mb-6">
          <div class="flex flex-wrap items-center justify-between gap-4">
            <div class="flex items-center space-x-2">
              <button 
                @click="activeTab = 'detector'" 
                :class="[
                  'px-3 py-1.5 text-sm rounded-md',
                  activeTab === 'detector' 
                    ? 'bg-emerald-100 text-emerald-700 font-medium' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                ]"
              >
                <span class="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                  Disease Detector
                </span>
              </button>
              <button 
                @click="activeTab = 'history'" 
                :class="[
                  'px-3 py-1.5 text-sm rounded-md',
                  activeTab === 'history' 
                    ? 'bg-emerald-100 text-emerald-700 font-medium' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                ]"
              >
                <span class="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  History
                </span>
              </button>
              <button 
                @click="activeTab = 'analytics'" 
                :class="[
                  'px-3 py-1.5 text-sm rounded-md',
                  activeTab === 'analytics' 
                    ? 'bg-emerald-100 text-emerald-700 font-medium' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                ]"
                :disabled="analysisHistory.length === 0"
              >
                <span class="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                  </svg>
                  Analytics
                </span>
              </button>
            </div>
            <div class="flex items-center space-x-2">
              <button 
                v-if="activeTab === 'detector'"
                @click="clearFile" 
                class="px-3 py-1.5 text-sm rounded-md bg-white border border-gray-300 text-gray-700 hover:bg-gray-50"
              >
                <span class="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                  </svg>
                  Clear
                </span>
              </button>
              <button 
                v-if="activeTab === 'analytics' && analysisHistory.length > 0"
                @click="exportAnalytics" 
                class="px-3 py-1.5 text-sm rounded-md bg-white border border-gray-300 text-gray-700 hover:bg-gray-50"
              >
                <span class="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                  </svg>
                  Export
                </span>
              </button>
              <button 
                v-if="activeTab === 'history' && analysisHistory.length > 0"
                @click="exportToCSV" 
                class="px-3 py-1.5 text-sm rounded-md bg-white border border-gray-300 text-gray-700 hover:bg-gray-50"
              >
                <span class="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                  </svg>
                  Export CSV
                </span>
              </button>
            </div>
          </div>
        </div>

        <!-- Disease Detector Tab -->
        <div v-if="activeTab === 'detector'" class="space-y-6">
          <!-- Image Upload Section -->
          <div class="bg-white rounded-lg shadow-sm p-6">
            <div class="flex flex-col md:flex-row gap-6">
              <!-- Upload Area -->
              <div class="flex-1">
                <h3 class="text-lg font-medium text-gray-800 mb-4">Upload Plant Image</h3>
                
                <div 
                  @dragover.prevent="isDragging = true"
                  @dragleave.prevent="isDragging = false"
                  @drop.prevent="onFileDrop"
                  :class="[
                    'border-2 border-dashed rounded-lg p-6 text-center',
                    isDragging ? 'border-emerald-500 bg-emerald-50' : 'border-gray-300 hover:border-emerald-400',
                    imagePreview ? 'bg-gray-50' : ''
                  ]"
                >
                  <div v-if="!imagePreview" class="space-y-4">
                    <svg xmlns="http://www.w3.org/2000/svg" class="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                    <p class="text-gray-600">Drag and drop your image here, or click to browse</p>
                    <input 
                      type="file" 
                      accept="image/*" 
                      @change="onFileChange" 
                      class="hidden" 
                      ref="fileInput"
                    >
                    <button 
                      @click="$refs.fileInput.click()" 
                      class="px-4 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700 transition-colors"
                    >
                      Browse Files
                    </button>
                    <div class="flex justify-center mt-4">
                      <button 
                        v-if="hasCameraSupport" 
                        @click="startCamera" 
                        class="flex items-center text-emerald-600 hover:text-emerald-700"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                        </svg>
                        Use Camera
                      </button>
                    </div>
                  </div>
                  
                  <div v-else class="relative">
                    <img :src="imagePreview" alt="Plant image preview" class="max-h-64 mx-auto rounded-lg">
                    <button 
                      @click="clearFile" 
                      class="absolute top-2 right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    </button>
                  </div>
                </div>
                
                <div class="mt-4 flex justify-center">
                  <button 
                    @click="predictImage" 
                    :disabled="!file || loading" 
                    :class="[
                      'px-6 py-2 rounded-md text-white font-medium flex items-center',
                      !file || loading ? 'bg-gray-400 cursor-not-allowed' : 'bg-emerald-600 hover:bg-emerald-700'
                    ]"
                  >
                    <svg v-if="loading" class="animate-spin -ml-1 mr-2 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                      <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    <svg v-else xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                    </svg>
                    {{ loading ? 'Analyzing...' : 'Analyze Image' }}
                  </button>
                </div>
                
                <!-- Camera View -->
                <div v-if="showCamera" class="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
                  <div class="bg-white rounded-lg p-4 max-w-lg w-full">
                    <div class="flex justify-between items-center mb-4">
                      <h3 class="text-lg font-medium">Camera Capture</h3>
                      <button @click="stopCamera" class="text-gray-500 hover:text-gray-700">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                        </svg>
                      </button>
                    </div>
                    <div class="relative bg-black rounded-lg overflow-hidden">
                      <video ref="videoElement" autoplay playsinline class="w-full"></video>
                    </div>
                    <div class="mt-4 flex justify-center">
                      <button 
                        @click="captureImage" 
                        class="px-6 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700 transition-colors flex items-center"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                        </svg>
                        Capture Photo
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              
              <!-- Results Section -->
              <div class="flex-1">
                <h3 class="text-lg font-medium text-gray-800 mb-4">Analysis Results</h3>
                
                <div v-if="error" class="bg-red-50 border border-red-200 rounded-lg p-4 mb-4">
                  <div class="flex items-start">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-red-500 mt-0.5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <div>
                      <h4 class="text-sm font-medium text-red-800">Error</h4>
                      <p class="text-sm text-red-700 mt-1">{{ error }}</p>
                      <button 
                        v-if="isConnectionError" 
                        @click="retryConnection" 
                        class="mt-2 text-sm text-red-700 hover:text-red-800 font-medium flex items-center"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                        </svg>
                        Retry Connection
                      </button>
                    </div>
                  </div>
                </div>
                
                <div v-if="!result && !error" class="bg-gray-50 border border-gray-200 rounded-lg p-6 text-center h-64 flex flex-col items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12 text-gray-400 mb-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                  <p class="text-gray-600">Upload an image and click "Analyze Image" to see results</p>
                </div>
                
                <div v-if="result" class="results-section bg-white border border-gray-200 rounded-lg overflow-hidden">
                  <div :class="[
                    'p-4 text-white font-medium',
                    result.prediction === 'Healthy' ? 'bg-green-600' : 
                    result.prediction === 'Bacterial' ? 'bg-red-600' : 
                    result.prediction === 'Fungal' ? 'bg-yellow-600' : 'bg-blue-600'
                  ]">
                    <div class="flex items-center">
                      <svg v-if="result.prediction === 'Healthy'" xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                      <svg v-else-if="result.prediction === 'Bacterial'" xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                      </svg>
                      <svg v-else xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                      <span>{{ result.prediction }} Plant Detected</span>
                    </div>
                  </div>
                  
                  <div class="p-4">
                    <div class="mb-4">
                      <div class="flex justify-between items-center mb-1">
                        <span class="text-sm font-medium text-gray-700">Confidence Level</span>
                        <span class="text-sm font-medium">{{ Math.round(result.confidence * 100) }}%</span>
                      </div>
                      <div class="w-full bg-gray-200 rounded-full h-2.5">
                        <div :class="[
                          'h-2.5 rounded-full',
                          result.prediction === 'Healthy' ? 'bg-green-600' : 
                          result.prediction === 'Bacterial' ? 'bg-red-600' : 
                          result.prediction === 'Fungal' ? 'bg-yellow-600' : 'bg-blue-600'
                        ]" :style="{ width: `${result.confidence * 100}%` }"></div>
                      </div>
                    </div>
                    
                    <div class="space-y-3">
                      <div v-if="result.prediction === 'Healthy'" class="text-green-800 bg-green-50 p-3 rounded-lg">
                        <h4 class="font-medium">Healthy Plant</h4>
                        <p class="text-sm mt-1">This plant appears to be healthy with no signs of disease. Continue with regular care and monitoring.</p>
                      </div>
                      
                      <div v-if="result.prediction === 'Bacterial'" class="text-red-800 bg-red-50 p-3 rounded-lg">
                        <h4 class="font-medium">Bacterial Disease Detected</h4>
                        <p class="text-sm mt-1">This plant shows signs of bacterial infection. Consider removing affected leaves and applying appropriate treatments.</p>
                      </div>
                      
                      <div v-if="result.prediction === 'Fungal'" class="text-yellow-800 bg-yellow-50 p-3 rounded-lg">
                        <h4 class="font-medium">Fungal Disease Detected</h4>
                        <p class="text-sm mt-1">This plant shows signs of fungal infection. Reduce humidity around the plant and consider applying fungicide.</p>
                      </div>
                      
                      <div class="text-gray-800 bg-gray-50 p-3 rounded-lg">
                        <h4 class="font-medium">Analysis Details</h4>
                        <div class="grid grid-cols-2 gap-2 mt-2 text-sm">
                          <div>
                            <span class="text-gray-500">Date:</span>
                            <span class="ml-1">{{ new Date().toLocaleString() }}</span>
                          </div>
                          <div>
                            <span class="text-gray-500">Model:</span>
                            <span class="ml-1">EcoMist v1.0</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div class="mt-4 flex justify-end">
                      <button 
                        @click="exportResults" 
                        class="px-3 py-1.5 text-sm bg-gray-100 text-gray-700 rounded hover:bg-gray-200 flex items-center"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                        </svg>
                        Export Report
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <!-- Recommendations Section -->
          <div v-if="result" class="bg-white rounded-lg shadow-sm p-6">
            <h3 class="text-lg font-medium text-gray-800 mb-4">Recommendations</h3>
            
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div v-if="result.prediction === 'Healthy'" class="bg-green-50 border border-green-100 rounded-lg p-4">
                <div class="flex items-start">
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-green-600 mt-0.5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                  </svg>
                  <div>
                    <h4 class="text-sm font-medium text-green-800">Maintain Regular Care</h4>
                    <p class="text-xs text-green-700 mt-1">Continue with regular watering, fertilizing, and sunlight exposure.</p>
                  </div>
                </div>
              </div>
              
              <div v-if="result.prediction === 'Healthy'" class="bg-green-50 border border-green-100 rounded-lg p-4">
                <div class="flex items-start">
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-green-600 mt-0.5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                  </svg>
                  <div>
                    <h4 class="text-sm font-medium text-green-800">Preventative Measures</h4>
                    <p class="text-xs text-green-700 mt-1">Monitor for early signs of disease and maintain good air circulation.</p>
                  </div>
                </div>
              </div>
              
              <div v-if="result.prediction === 'Healthy'" class="bg-green-50 border border-green-100 rounded-lg p-4">
                <div class="flex items-start">
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-green-600 mt-0.5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <div>
                    <h4 class="text-sm font-medium text-green-800">Regular Monitoring</h4>
                    <p class="text-xs text-green-700 mt-1">Continue to monitor your plant regularly for any changes in appearance.</p>
                  </div>
                </div>
              </div>
              
              <div v-if="result.prediction === 'Bacterial'" class="bg-red-50 border border-red-100 rounded-lg p-4">
                <div class="flex items-start">
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-red-600 mt-0.5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                  </svg>
                  <div>
                    <h4 class="text-sm font-medium text-red-800">Remove Infected Parts</h4>
                    <p class="text-xs text-red-700 mt-1">Carefully remove and dispose of infected leaves and stems.</p>
                  </div>
                </div>
              </div>
              
              <div v-if="result.prediction === 'Bacterial'" class="bg-red-50 border border-red-100 rounded-lg p-4">
                <div class="flex items-start">
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-red-600 mt-0.5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
                  </svg>
                  <div>
                    <h4 class="text-sm font-medium text-red-800">Apply Bactericide</h4>
                    <p class="text-xs text-red-700 mt-1">Use an appropriate copper-based bactericide following product instructions.</p>
                  </div>
                </div>
              </div>
              
              <div v-if="result.prediction === 'Bacterial'" class="bg-red-50 border border-red-100 rounded-lg p-4">
                <div class="flex items-start">
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-red-600 mt-0.5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 11.5V14m0-2.5v-6a1.5 1.5 0 113 0m-3 6a1.5 1.5 0 00-3 0v2a7.5 7.5 0 0015 0v-5a1.5 1.5 0 00-3 0m-6-3V11m0-5.5v-1a1.5 1.5 0 013 0v1m0 0V11m0-5.5a1.5 1.5 0 013 0v3m0 0V11" />
                  </svg>
                  <div>
                    <h4 class="text-sm font-medium text-red-800">Improve Air Circulation</h4>
                    <p class="text-xs text-red-700 mt-1">Ensure adequate spacing between plants to improve air flow.</p>
                  </div>
                </div>
              </div>
              
              <div v-if="result.prediction === 'Fungal'" class="bg-yellow-50 border border-yellow-100 rounded-lg p-4">
                <div class="flex items-start">
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-yellow-600 mt-0.5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <div>
                    <h4 class="text-sm font-medium text-yellow-800">Reduce Humidity</h4>
                    <p class="text-xs text-yellow-700 mt-1">Decrease humidity around plants and avoid overhead watering.</p>
                  </div>
                </div>
              </div>
              
              <div v-if="result.prediction === 'Fungal'" class="bg-yellow-50 border border-yellow-100 rounded-lg p-4">
                <div class="flex items-start">
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-yellow-600 mt-0.5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
                  </svg>
                  <div>
                    <h4 class="text-sm font-medium text-yellow-800">Apply Fungicide</h4>
                    <p class="text-xs text-yellow-700 mt-1">Use an appropriate fungicide according to product instructions.</p>
                  </div>
                </div>
              </div>
              
              <div v-if="result.prediction === 'Fungal'" class="bg-yellow-50 border border-yellow-100 rounded-lg p-4">
                <div class="flex items-start">
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-yellow-600 mt-0.5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 21v-4m0 0V5a2 2 0 012-2h6.5l1 1H21l-3 6 3 6h-8.5l-1-1H5a2 2 0 00-2 2zm9-13.5V9" />
                  </svg>
                  <div>
                    <h4 class="text-sm font-medium text-yellow-800">Remove Debris</h4>
                    <p class="text-xs text-yellow-700 mt-1">Clear fallen leaves and plant debris to reduce fungal spore spread.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- History Tab -->
        <div v-if="activeTab === 'history'" class="space-y-6">
          <div class="bg-white rounded-lg shadow-sm p-6">
            <h3 class="text-lg font-medium text-gray-800 mb-4">Analysis History</h3>
            
            <div v-if="!user" class="bg-blue-50 border border-blue-100 rounded-lg p-4 mb-4">
              <div class="flex items-start">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-blue-600 mt-0.5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <div>
                  <h4 class="text-sm font-medium text-blue-800">Login to Save History</h4>
                  <p class="text-sm text-blue-700 mt-1">Sign in to save your analysis history and access it across devices.</p>
                  <button 
                    @click="authMode = 'login'; showAuthModal = true" 
                    class="mt-2 text-sm text-blue-700 hover:text-blue-800 font-medium"
                  >
                    Login or Create Account
                  </button>
                </div>
              </div>
            </div>
            
            <div v-if="analysisHistory.length === 0" class="text-center py-8">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12 text-gray-400 mx-auto mb-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <p class="text-gray-600">No analysis history found</p>
              <p class="text-gray-500 text-sm mt-1">Analyze some plant images to build your history</p>
            </div>
            
            <div v-else class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div 
                v-for="(item, index) in analysisHistory" 
                :key="index" 
                class="border rounded-lg overflow-hidden hover:shadow-md transition-shadow cursor-pointer"
                @click="loadHistoryItem(item)"
              >
                <div :class="[
                  'h-2',
                  item.result.prediction === 'Healthy' ? 'bg-green-500' : 
                  item.result.prediction === 'Bacterial' ? 'bg-red-500' : 
                  item.result.prediction === 'Fungal' ? 'bg-yellow-500' : 'bg-blue-500'
                ]"></div>
                <div class="p-3">
                  <div class="flex justify-between items-start">
                    <div>
                      <h4 class="font-medium text-gray-800">{{ item.result.prediction }}</h4>
                      <p class="text-xs text-gray-500 mt-1">{{ formatDate(item.date) }}</p>
                    </div>
                    <div :class="[
                      'text-xs px-2 py-0.5 rounded-full',
                      item.result.prediction === 'Healthy' ? 'bg-green-100 text-green-800' : 
                      item.result.prediction === 'Bacterial' ? 'bg-red-100 text-red-800' : 
                      item.result.prediction === 'Fungal' ? 'bg-yellow-100 text-yellow-800' : 'bg-blue-100 text-blue-800'
                    ]">
                      {{ Math.round(item.result.confidence * 100) }}%
                    </div>
                  </div>
                  <div class="mt-2 flex justify-between items-center">
                    <div class="w-16 h-16 bg-gray-100 rounded overflow-hidden">
                      <img 
                        :src="item.imagePreview || item.imageUrl" 
                        alt="Analysis thumbnail" 
                        class="w-full h-full object-cover"
                      >
                    </div>
                    <button 
                      @click.stop="confirmDeleteHistoryItem(item)" 
                      class="text-gray-400 hover:text-red-500"
                      title="Delete"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                      </svg>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Analytics Tab -->
        <div v-if="activeTab === 'analytics'" class="space-y-6 analytics-content">
          <div v-if="analysisHistory.length === 0" class="bg-white rounded-lg shadow-sm p-6 text-center">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12 text-gray-400 mx-auto mb-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
            </svg>
            <p class="text-gray-600">No data available for analytics</p>
            <p class="text-gray-500 text-sm mt-1">Analyze some plant images to generate analytics</p>
          </div>
          
          <div v-else>
            <!-- Summary Cards -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              <div class="bg-white rounded-lg shadow-sm p-4">
                <div class="flex items-center">
                  <div class="p-3 rounded-full bg-emerald-100 text-emerald-600 mr-4">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
                    </svg>
                  </div>
                  <div>
                    <p class="text-gray-500 text-sm">Total Analyses</p>
                    <p class="text-2xl font-semibold text-gray-800">{{ analysisHistory.length }}</p>
                  </div>
                </div>
              </div>
              
              <div class="bg-white rounded-lg shadow-sm p-4">
                <div class="flex items-center">
                  <div class="p-3 rounded-full bg-green-100 text-green-600 mr-4">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <div>
                    <p class="text-gray-500 text-sm">Healthy Plants</p>
                    <p class="text-2xl font-semibold text-gray-800">{{ analyticsSummary.healthy }}</p>
                  </div>
                </div>
              </div>
              
              <div class="bg-white rounded-lg shadow-sm p-4">
                <div class="flex items-center">
                  <div class="p-3 rounded-full bg-red-100 text-red-600 mr-4">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                    </svg>
                  </div>
                  <div>
                    <p class="text-gray-500 text-sm">Bacterial Diseases</p>
                    <p class="text-2xl font-semibold text-gray-800">{{ analyticsSummary.bacterial }}</p>
                  </div>
                </div>
              </div>
              
              <div class="bg-white rounded-lg shadow-sm p-4">
                <div class="flex items-center">
                  <div class="p-3 rounded-full bg-yellow-100 text-yellow-600 mr-4">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <div>
                    <p class="text-gray-500 text-sm">Fungal Diseases</p>
                    <p class="text-2xl font-semibold text-gray-800">{{ analyticsSummary.fungal }}</p>
                  </div>
                </div>
              </div>
            </div>
            
            <!-- Charts -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
              <div class="bg-white rounded-lg shadow-sm p-4">
                <h3 class="text-lg font-medium text-gray-800 mb-4">Disease Distribution</h3>
                <div class="h-64">
                  <canvas ref="diseaseDistributionChart"></canvas>
                </div>
              </div>
              
              <div class="bg-white rounded-lg shadow-sm p-4">
                <h3 class="text-lg font-medium text-gray-800 mb-4">Confidence Levels</h3>
                <div class="h-64">
                  <canvas ref="confidenceLevelsChart"></canvas>
                </div>
              </div>
              
              <div class="bg-white rounded-lg shadow-sm p-4">
                <h3 class="text-lg font-medium text-gray-800 mb-4">Disease Trend</h3>
                <div class="h-64">
                  <canvas ref="diseaseTrendChart"></canvas>
                </div>
              </div>
              
              <div class="bg-white rounded-lg shadow-sm p-4">
                <h3 class="text-lg font-medium text-gray-800 mb-4">Average Confidence by Disease</h3>
                <div class="h-64">
                  <canvas ref="avgConfidenceChart"></canvas>
                </div>
              </div>
            </div>
            
            <!-- Insights -->
            <div class="bg-white rounded-lg shadow-sm p-6">
              <h3 class="text-lg font-medium text-gray-800 mb-4">Insights</h3>
              
              <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 class="text-sm font-medium text-gray-700 mb-3">Key Metrics</h4>
                  <div class="space-y-4">
                    <div class="flex items-center justify-between">
                      <span class="text-gray-600">Healthy Rate</span>
                      <div class="flex items-center">
                        <div class="w-32 h-2 bg-gray-200 rounded-full mr-2">
                          <div class="h-full bg-green-500 rounded-full" :style="{
                            width: `${analysisHistory.length > 0 ? (analyticsSummary.healthy / analysisHistory.length) * 100 : 0}%`
                          }"></div>
                        </div>
                        <span class="text-sm font-medium">{{ analysisHistory.length > 0 ? Math.round((analyticsSummary.healthy / analysisHistory.length) * 100) : 0 }}%</span>
                      </div>
                    </div>
                    <div class="flex items-center justify-between">
                      <span class="text-gray-600">Disease Rate</span>
                      <div class="flex items-center">
                        <div class="w-32 h-2 bg-gray-200 rounded-full mr-2">
                          <div class="h-full bg-red-500 rounded-full" :style="{
                            width: `${analysisHistory.length > 0 ? ((analyticsSummary.bacterial + analyticsSummary.fungal) / analysisHistory.length) * 100 : 0}%`
                          }"></div>
                        </div>
                        <span class="text-sm font-medium">{{ analysisHistory.length > 0 ? Math.round(((analyticsSummary.bacterial + analyticsSummary.fungal) / analysisHistory.length) * 100) : 0 }}%</span>
                      </div>
                    </div>
                    <div class="flex items-center justify-between">
                      <span class="text-gray-600">Bacterial vs Fungal</span>
                      <div class="flex items-center">
                        <div class="w-32 h-2 bg-gray-200 rounded-full mr-2">
                          <div class="h-full bg-red-500 rounded-full" :style="{
                            width: `${(analyticsSummary.bacterial + analyticsSummary.fungal) > 0 ? (analyticsSummary.bacterial / (analyticsSummary.bacterial + analyticsSummary.fungal)) * 100 : 0}%`
                          }"></div>
                        </div>
                        <span class="text-sm font-medium">{{ (analyticsSummary.bacterial + analyticsSummary.fungal) > 0 ? Math.round((analyticsSummary.bacterial / (analyticsSummary.bacterial + analyticsSummary.fungal)) * 100) : 0 }}% Bacterial</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div>
                  <h4 class="text-sm font-medium text-gray-700 mb-3">Recommendations</h4>
                  <div class="space-y-2">
                    <div v-if="analyticsSummary.bacterial > analyticsSummary.fungal && analyticsSummary.bacterial > 0" class="p-2 rounded-md text-sm bg-red-50 text-red-800">
                      <div class="font-medium">Bacterial Disease Prevention</div>
                      <div>Focus on improving sanitation and using copper-based treatments.</div>
                    </div>
                    <div v-if="analyticsSummary.fungal > analyticsSummary.bacterial && analyticsSummary.fungal > 0" class="p-2 rounded-md text-sm bg-yellow-50 text-yellow-800">
                      <div class="font-medium">Fungal Disease Prevention</div>
                      <div>Reduce humidity and improve air circulation around plants.</div>
                    </div>
                    <div v-if="analyticsSummary.healthy > (analyticsSummary.bacterial + analyticsSummary.fungal)" class="p-2 rounded-md text-sm bg-green-50 text-green-800">
                      <div class="font-medium">Maintain Healthy Practices</div>
                      <div>Continue your current care routine as it's working well.</div>
                    </div>
                    <div v-if="analysisHistory.length < 5" class="p-2 rounded-md text-sm bg-blue-50 text-blue-800">
                      <div class="font-medium">More Data Needed</div>
                      <div>Analyze more plants to get more accurate insights and trends.</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>

    <!-- Authentication Modal -->
    <div v-if="showAuthModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div class="bg-white rounded-lg p-6 max-w-md w-full">
        <div class="flex justify-between items-center mb-4">
          <h3 class="text-lg font-medium">{{ authMode === 'login' ? 'Login' : 'Create Account' }}</h3>
          <button @click="showAuthModal = false" class="text-gray-500 hover:text-gray-700">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        
        <div v-if="authError" class="bg-red-50 border border-red-200 rounded-lg p-3 mb-4 text-sm text-red-700">
          {{ authError }}
        </div>
        
        <form @submit.prevent="handleAuth" class="space-y-4">
          <div>
            <label for="email" class="block text-sm font-medium text-gray-700 mb-1">Email</label>
            <input 
              type="email" 
              id="email" 
              v-model="email" 
              required 
              class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
          </div>
          <div>
            <label for="password" class="block text-sm font-medium text-gray-700 mb-1">Password</label>
            <input 
              type="password" 
              id="password" 
              v-model="password" 
              required 
              class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
          </div>
          <div>
            <button 
              type="submit" 
              class="w-full px-4 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700 transition-colors"
            >
              {{ authMode === 'login' ? 'Login' : 'Create Account' }}
            </button>
          </div>
        </form>
        
        <div class="mt-4 text-center text-sm">
          <p v-if="authMode === 'login'">
            Don't have an account? 
            <button @click="authMode = 'signup'" class="text-emerald-600 hover:text-emerald-700 font-medium">
              Sign up
            </button>
          </p>
          <p v-else>
            Already have an account? 
            <button @click="authMode = 'login'" class="text-emerald-600 hover:text-emerald-700 font-medium">
              Login
            </button>
          </p>
        </div>
      </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div v-if="showDeleteConfirmation" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div class="bg-white rounded-lg p-6 max-w-md w-full">
        <h3 class="text-lg font-medium text-gray-900 mb-4">Confirm Deletion</h3>
        <p class="text-gray-500 mb-4">Are you sure you want to delete this analysis? This action cannot be undone.</p>
        <div class="flex justify-end gap-2">
          <button @click="cancelDelete" class="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300">
            Cancel
          </button>
          <button @click="deleteHistoryItem" class="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700">
            Delete
          </button>
        </div>
      </div>
    </div>

    <!-- Notification Toast -->
    <div v-if="showNotification" class="fixed bottom-4 right-4 max-w-md z-50">
      <div :class="[
        'rounded-lg shadow-lg p-4 flex items-start',
        notificationData.type === 'success' ? 'bg-green-100 text-green-800 border-l-4 border-green-500' :
        notificationData.type === 'warning' ? 'bg-yellow-100 text-yellow-800 border-l-4 border-yellow-500' :
        notificationData.type === 'error' ? 'bg-red-100 text-red-800 border-l-4 border-red-500' :
        'bg-blue-100 text-blue-800 border-l-4 border-blue-500'
      ]">
        <div class="flex-shrink-0 mr-3">
          <svg v-if="notificationData.type === 'success'" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
          </svg>
          <svg v-else-if="notificationData.type === 'warning' || notificationData.type === 'error'" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd" />
          </svg>
          <svg v-else class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd" />
          </svg>
        </div>
        <div>
          <h3 class="font-medium">{{ notificationData.title }}</h3>
          <p class="text-sm mt-1">{{ notificationData.message }}</p>
        </div>
        <button @click="showNotification = false" class="ml-auto">
          <svg class="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
            <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd" />
          </svg>
        </button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, watch, onMounted, onBeforeUnmount, nextTick } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { getAuth, signOut, onAuthStateChanged, signInWithEmailAndPassword, createUserWithEmailAndPassword } from "firebase/auth";
import { getStorage, ref as storageRef, uploadBytes, getDownloadURL } from "firebase/storage";
import { getFirestore, collection, addDoc, getDocs } from "firebase/firestore";
import { db } from "../../../firebase";
import axios from 'axios';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';
import Chart from 'chart.js/auto';
import debounce from 'lodash.debounce';

// State variables
const file = ref(null);
const imagePreview = ref(null);
const result = ref(null);
const loading = ref(false);
const error = ref(null);
const isDragging = ref(false);
const showCamera = ref(false);
const hasCameraSupport = ref(false);
const videoStream = ref(null);
const apiUrl = ref(import.meta.env.VITE_API_URL || 'http://127.0.0.1:5000');
const isDarkMode = ref(localStorage.getItem('theme') === 'dark' || false);
const analysisHistory = ref(JSON.parse(localStorage.getItem('analysisHistory') || '[]'));
const activeTab = ref('detector');
const charts = ref({
  diseaseDistribution: null,
  confidenceLevels: null,
  diseaseTrend: null,
  avgConfidence: null
});
const showDeleteConfirmation = ref(false);
const itemToDelete = ref(null);
const user = ref(null);
const authError = ref(null);
const authMode = ref('login'); // 'login' or 'signup'
const email = ref('');
const password = ref('');
const sidebarOpen = ref(true);
const isMobile = ref(false);
const theme = ref(localStorage.getItem('theme') || 'light');
const collapsedSections = ref(JSON.parse(localStorage.getItem('collapsedSections') || '[]'));
const userMenuOpen = ref(false);
const userMenuRef = ref(null);
const showAuthModal = ref(false);
const showNotification = ref(false);
const notificationData = ref({ title: '', message: '', type: 'info' });
const fileInput = ref(null);
const videoElement = ref(null);
const canvas = ref(null);
const clone = ref(null);

const route = useRoute();
const currentRoute = ref(route.path);

// Computed properties
const analyticsSummary = computed(() => {
  const summary = {
    healthy: 0,
    bacterial: 0,
    fungal: 0,
    unknown: 0
  };
  
  analysisHistory.value.forEach(item => {
    const prediction = item.result.prediction.toLowerCase();
    if (summary.hasOwnProperty(prediction)) {
      summary[prediction]++;
    } else {
      summary.unknown++;
    }
  });
  
  return summary;
});

const isConnectionError = computed(() => {
  return error.value && error.value.includes('connect');
});

const navigationSections = computed(() => {
  return [
    {
      title: 'GENERAL',
      routes: [
        { path: '/dashboard', name: 'Dashboard' },
        { path: '/profile-display', name: 'Profile' },
      ],
    },
    {
      title: 'TOOLS',
      routes: [
        { path: '/model', name: 'Crop Disease Detector' },
      ],
    },
  ];
});

// Methods
const onFileChange = (event) => {
  file.value = event.target.files[0];
  processFile();
};

const onFileDrop = (event) => {
  isDragging.value = false;
  const files = event.dataTransfer.files;
  if (files.length) {
    file.value = files[0];
    processFile();
  }
};

const processFile = () => {
  result.value = null;
  error.value = null;
  
  // Validate file type
  if (file.value && !file.value.type.startsWith('image/')) {
    error.value = "Please select a valid image file";
    file.value = null;
    return;
  }
  
  // Create image preview
  if (file.value) {
    const reader = new FileReader();
    reader.onload = (e) => {
      imagePreview.value = e.target.result;
    };
    reader.readAsDataURL(file.value);
  } else {
    imagePreview.value = null;
  }
};

const clearFile = () => {
  file.value = null;
  imagePreview.value = null;
  result.value = null;
  error.value = null;
};

const predictImage = async () => {
  if (!file.value) {
    error.value = "Please select an image first";
    return;
  }

  loading.value = true;
  error.value = null;
  
  const formData = new FormData();
  formData.append('file', file.value);

  try {
    const response = await axios.post(`${apiUrl.value}/predict`, formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      },
      timeout: 30000 // 30 second timeout
    });
    
    if (response.data.status === 'success') {
      result.value = response.data;
      
      // Save to history
      saveToHistory();
    } else {
      error.value = response.data.error || "An unknown error occurred";
    }
  } catch (error) {
    console.error("Error during prediction", error);
    if (error.code === 'ECONNABORTED') {
      error.value = "Request timed out. The server might be busy or offline.";
    } else {
      error.value = error.response?.data?.error || "Failed to connect to the server";
    }
  } finally {
    loading.value = false;
  }
};

const retryConnection = () => {
  predictImage();
};

const checkCameraSupport = () => {
  hasCameraSupport.value = !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia);
};

const startCamera = async () => {
  try {
    videoStream.value = await navigator.mediaDevices.getUserMedia({ 
      video: { facingMode: 'environment' } 
    });
    showCamera.value = true;
    
    // Wait for DOM update then set video source
    nextTick(() => {
      if (videoElement.value) {
        videoElement.value.srcObject = videoStream.value;
      }
    });
  } catch (err) {
    console.error("Error accessing camera:", err);
    error.value = "Could not access camera. Please check permissions.";
  }
};

const stopCamera = () => {
  if (videoStream.value) {
    videoStream.value.getTracks().forEach(track => track.stop());
    videoStream.value = null;
  }
  showCamera.value = false;
};

const captureImage = () => {
  if (!videoElement.value) return;
  
  const canvasElement = document.createElement('canvas');
  const video = videoElement.value;
  canvasElement.width = video.videoWidth;
  canvasElement.height = video.videoHeight;
  
  const ctx = canvasElement.getContext('2d');
  ctx.drawImage(video, 0, 0, canvasElement.width, canvasElement.height);
  
  // Convert to file
  canvasElement.toBlob((blob) => {
    file.value = new File([blob], "camera-capture.jpg", { type: "image/jpeg" });
    imagePreview.value = canvasElement.toDataURL('image/jpeg');
    stopCamera();
  }, 'image/jpeg', 0.95);
};

const toggleTheme = () => {
  isDarkMode.value = !isDarkMode.value;
  localStorage.setItem('theme', isDarkMode.value ? 'dark' : 'light');
  applyTheme();
  
  // Reinitialize charts if on analytics tab
  if (activeTab.value === 'analytics' && analysisHistory.value.length > 0) {
    destroyCharts();
    nextTick(() => {
      initCharts();
    });
  }
};

const applyTheme = () => {
  if (isDarkMode.value) {
    document.documentElement.classList.add('dark-theme');
  } else {
    document.documentElement.classList.remove('dark-theme');
  }
};

const exportResults = async () => {
  if (!result.value) return;
  
  try {
    const resultsElement = document.querySelector('.results-section');
    if (!resultsElement) return;
    
    // Create a clone to avoid modifying the original DOM
    const clonedElement = resultsElement.cloneNode(true);
    clonedElement.style.width = '600px';
    clonedElement.style.padding = '20px';
    clonedElement.style.background = isDarkMode.value ? '#0f172a' : '#ffffff';
    clonedElement.style.color = isDarkMode.value ? '#ffffff' : '#000000';
    clonedElement.style.position = 'absolute';
    clonedElement.style.left = '-9999px';
    document.body.appendChild(clonedElement);
    
    // Add image to the PDF
    const canvasElement = await html2canvas(clonedElement, {
      scale: 2,
      backgroundColor: isDarkMode.value ? '#0f172a' : '#ffffff'
    });
    
    const imgData = canvasElement.toDataURL('image/png');
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });
    
    // Add title
    pdf.setFontSize(20);
    pdf.setTextColor(isDarkMode.value ? 255 : 0);
    pdf.text('Eco-Mist Analysis Report', 105, 20, { align: 'center' });
    
    // Add date
    pdf.setFontSize(12);
    pdf.text(`Date: ${new Date().toLocaleString()}`, 105, 30, { align: 'center' });
    
    // Add image
    const imgWidth = 190;
    const imgHeight = canvasElement.height * imgWidth / canvasElement.width;
    pdf.addImage(imgData, 'PNG', 10, 40, imgWidth, imgHeight);
    
    // Save PDF
    pdf.save(`ecomist-analysis-${new Date().toISOString().slice(0, 10)}.pdf`);
    
    // Clean up
    document.body.removeChild(clonedElement);
  } catch (err) {
    console.error("Error generating PDF:", err);
    error.value = "Failed to generate PDF. Please try again.";
  }
};

const exportAnalytics = async () => {
  if (analysisHistory.value.length === 0) return;
  
  try {
    const analyticsElement = document.querySelector('.analytics-content');
    if (!analyticsElement) return;
    
    // Create a clone to avoid modifying the original DOM
    const clonedElement = analyticsElement.cloneNode(true);
    clonedElement.style.width = '700px';
    clonedElement.style.padding = '20px';
    clonedElement.style.background = isDarkMode.value ? '#0f172a' : '#ffffff';
    clonedElement.style.color = isDarkMode.value ? '#ffffff' : '#000000';
    clonedElement.style.position = 'absolute';
    clonedElement.style.left = '-9999px';
    document.body.appendChild(clonedElement);
    
    // Add analytics to the PDF
    const canvasElement = await html2canvas(clonedElement, {
      scale: 1.5,
      backgroundColor: isDarkMode.value ? '#0f172a' : '#ffffff',
      windowWidth: 1200,
      windowHeight: 1600
    });
    
    const imgData = canvasElement.toDataURL('image/png');
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });
    
    // Add title
    pdf.setFontSize(20);
    pdf.setTextColor(isDarkMode.value ? 255 : 0);
    pdf.text('Eco-Mist Analytics Report', 105, 20, { align: 'center' });
    
    // Add date
    pdf.setFontSize(12);
    pdf.text(`Generated: ${new Date().toLocaleString()}`, 105, 30, { align: 'center' });
    
    // Add image
    const imgWidth = 190;
    const imgHeight = canvasElement.height * imgWidth / canvasElement.width;
    pdf.addImage(imgData, 'PNG', 10, 40, imgWidth, imgHeight);
    
    // Save PDF
    pdf.save(`ecomist-analytics-${new Date().toISOString().slice(0, 10)}.pdf`);
    
    // Clean up
    document.body.removeChild(clonedElement);
  } catch (err) {
    console.error("Error generating analytics PDF:", err);
    error.value = "Failed to generate analytics PDF. Please try again.";
  }
};

const saveToHistory = async () => {
  if (!result.value || !imagePreview.value) return;

  try {
    // If user is logged in, save to Firebase
    if (user.value) {
      const storage = getStorage();
      const imageRef = storageRef(storage, `analysisHistory/${user.value.uid}/${Date.now()}.jpg`);

      // Convert imagePreview (data URL) to Blob
      const response = await fetch(imagePreview.value);
      const blob = await response.blob();

      // Upload the image to Firebase Storage
      const snapshot = await uploadBytes(imageRef, blob);
      const imageUrl = await getDownloadURL(snapshot.ref);

      const historyItem = {
        date: new Date().toISOString(),
        imageUrl,
        result: result.value,
        userId: user.value.uid
      };

      // Add to Firestore
      const db = getFirestore();
      const analysisCollection = collection(db, "analysisHistory");
      await addDoc(analysisCollection, historyItem);

      // Add to local state
      analysisHistory.value.unshift(historyItem);
    } else {
      // Save locally if not logged in
      const historyItem = {
        date: new Date().toISOString(),
        imagePreview: imagePreview.value,
        result: result.value
      };
      
      analysisHistory.value.unshift(historyItem);
    }
    
    // Limit history size
    if (analysisHistory.value.length > 50) {
      analysisHistory.value = analysisHistory.value.slice(0, 50);
    }
    
    // Save to localStorage
    localStorage.setItem('analysisHistory', JSON.stringify(analysisHistory.value));
    
    // Show success notification
    showNotification.value = true;
    notificationData.value = {
      title: 'Analysis Saved',
      message: 'The analysis has been saved to your history',
      type: 'success'
    };
    
    // Auto-hide notification after 3 seconds
    setTimeout(() => {
      showNotification.value = false;
    }, 3000);
  } catch (error) {
    console.error("Error saving to history:", error);
    showNotification.value = true;
    notificationData.value = {
      title: 'Save Failed',
      message: 'Failed to save analysis to history',
      type: 'error'
    };
  }
};

const loadHistoryItem = (item) => {
  imagePreview.value = item.imagePreview || item.imageUrl;
  result.value = item.result;
  file.value = null; // Clear the file since it's loaded from history
  activeTab.value = 'detector'; // Switch to detector tab
};

const formatDate = (dateString) => {
  const date = new Date(dateString);
  return date.toLocaleDateString();
};

const getStatusClass = () => {
  if (!result.value) return 'bg-gray-100 text-gray-800';
  
  switch(result.value.prediction) {
    case 'Healthy': return 'bg-green-100 text-green-800';
    case 'Bacterial': return 'bg-red-100 text-red-800';
    case 'Fungal': return 'bg-yellow-100 text-yellow-800';
    default: return 'bg-blue-100 text-blue-800';
  }
};

const confirmDeleteHistoryItem = (item) => {
  itemToDelete.value = item;
  showDeleteConfirmation.value = true;
};

const cancelDelete = () => {
  showDeleteConfirmation.value = false;
  itemToDelete.value = null;
};

const deleteHistoryItem = async () => {
  if (!itemToDelete.value) return;
  
  try {
    // Find the index of the item to delete
    const index = analysisHistory.value.findIndex(item => 
      item.date === itemToDelete.value.date && 
      item.result.prediction === itemToDelete.value.result.prediction
    );
    
    if (index !== -1) {
      // If user is logged in, delete from Firebase
      if (user.value && itemToDelete.value.userId === user.value.uid) {
        // Delete from Firestore would go here
        // This is simplified - in a real app you'd need the document ID
      }
      
      // Remove the item from the array
      analysisHistory.value.splice(index, 1);
      
      // Update localStorage
      localStorage.setItem('analysisHistory', JSON.stringify(analysisHistory.value));
      
      // If the deleted item is the current result, clear it
      if (result.value && itemToDelete.value.date === result.value.date) {
        clearFile();
      }
      
      // Reinitialize charts if on analytics tab
      if (activeTab.value === 'analytics' && analysisHistory.value.length > 0) {
        nextTick(() => {
          initCharts();
        });
      }
      
      // Show success notification
      showNotification.value = true;
      notificationData.value = {
        title: 'Item Deleted',
        message: 'The analysis has been removed from your history',
        type: 'success'
      };
      
      // Auto-hide notification after 3 seconds
      setTimeout(() => {
        showNotification.value = false;
      }, 3000);
    }
  } catch (error) {
    console.error("Error deleting history item:", error);
    showNotification.value = true;
    notificationData.value = {
      title: 'Delete Failed',
      message: 'Failed to delete analysis from history',
      type: 'error'
    };
  } finally {
    // Close the confirmation dialog
    showDeleteConfirmation.value = false;
    itemToDelete.value = null;
  }
};

const initCharts = () => {
  destroyCharts();
  
  // Set chart colors based on theme
  const textColor = isDarkMode.value ? 'rgba(255, 255, 255, 0.8)' : 'rgba(15, 23, 42, 0.8)';
  const gridColor = isDarkMode.value ? 'rgba(255, 255, 255, 0.1)' : 'rgba(15, 23, 42, 0.1)';
  
  // Common chart options
  const commonOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        labels: {
          color: textColor
        }
      }
    },
    scales: {
      x: {
        ticks: {
          color: textColor
        },
        grid: {
          color: gridColor
        }
      },
      y: {
        ticks: {
          color: textColor
        },
        grid: {
          color: gridColor
        }
      }
    }
  };
  
  // 1. Disease Distribution Chart (Pie Chart)
  const diseaseDistributionChart = document.getElementById('diseaseDistributionChart');
  if (diseaseDistributionChart) {
    const ctx = diseaseDistributionChart.getContext('2d');
    charts.value.diseaseDistribution = new Chart(ctx, {
      type: 'pie',
      data: {
        labels: ['Healthy', 'Bacterial', 'Fungal', 'Unknown'],
        datasets: [{
          data: [
            analyticsSummary.value.healthy,
            analyticsSummary.value.bacterial,
            analyticsSummary.value.fungal,
            analyticsSummary.value.unknown
          ],
          backgroundColor: [
            '#22c55e',
            '#ef4444',
            '#eab308',
            '#3b82f6'
          ],
          borderColor: isDarkMode.value ? '#0f172a' : '#ffffff',
          borderWidth: 2
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'right',
            labels: {
              color: textColor
            }
          }
        }
      }
    });
  }
  
  // 2. Confidence Levels Chart (Line Chart)
  const confidenceLevelsChart = document.getElementById('confidenceLevelsChart');
  if (confidenceLevelsChart) {
    const confidenceData = analysisHistory.value
      .slice(0, 10)
      .reverse()
      .map(item => ({
        date: new Date(item.date),
        confidence: item.result.confidence,
        prediction: item.result.prediction
      }));
    
    const ctx = confidenceLevelsChart.getContext('2d');
    charts.value.confidenceLevels = new Chart(ctx, {
      type: 'line',
      data: {
        labels: confidenceData.map(item => formatDate(item.date)),
        datasets: [{
          label: 'Confidence Level',
          data: confidenceData.map(item => item.confidence * 100),
          borderColor: '#22c55e',
          backgroundColor: 'rgba(34, 197, 94, 0.2)',
          tension: 0.3,
          fill: true
        }]
      },
      options: {
        ...commonOptions,
        scales: {
          ...commonOptions.scales,
          y: {
            ...commonOptions.scales.y,
            min: 0,
            max: 100,
            title: {
              display: true,
              text: 'Confidence (%)',
              color: textColor
            }
          }
        }
      }
    });
  }
  
  // 3. Disease Trend Chart (Bar Chart)
  const diseaseTrendChart = document.getElementById('diseaseTrendChart');
  if (diseaseTrendChart) {
    const trendData = analysisHistory.value
      .slice(0, 10)
      .reverse();
    
    const ctx = diseaseTrendChart.getContext('2d');
    charts.value.diseaseTrend = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: trendData.map(item => formatDate(item.date)),
        datasets: [{
          label: 'Disease Type',
          data: trendData.map(item => {
            switch(item.result.prediction) {
              case 'Healthy': return 1;
              case 'Bacterial': return 2;
              case 'Fungal': return 3;
              default: return 4;
            }
          }),
          backgroundColor: trendData.map(item => {
            switch(item.result.prediction) {
              case 'Healthy': return 'rgba(34, 197, 94, 0.7)';
              case 'Bacterial': return 'rgba(239, 68, 68, 0.7)';
              case 'Fungal': return 'rgba(234, 179, 8, 0.7)';
              default: return 'rgba(59, 130, 246, 0.7)';
            }
          })
        }]
      },
      options: {
        ...commonOptions,
        scales: {
          ...commonOptions.scales,
          y: {
            ...commonOptions.scales.y,
            min: 0,
            max: 5,
            ticks: {
              color: textColor,
              callback: function(value) {
                switch(value) {
                  case 1: return 'Healthy';
                  case 2: return 'Bacterial';
                  case 3: return 'Fungal';
                  case 4: return 'Unknown';
                  default: return '';
                }
              }
            }
          }
        },
        plugins: {
          ...commonOptions.plugins,
          legend: {
            display: false
          },
          tooltip: {
            callbacks: {
              label: function(context) {
                const value = context.raw;
                switch(value) {
                  case 1: return 'Healthy';
                  case 2: return 'Bacterial';
                  case 3: return 'Fungal';
                  case 4: return 'Unknown';
                  default: return '';
                }
              }
            }
          }
        }
      }
    });
  }
  
  // 4. Average Confidence by Disease (Horizontal Bar Chart)
  const avgConfidenceChart = document.getElementById('avgConfidenceChart');
  if (avgConfidenceChart) {
    // Calculate average confidence by disease type
    const confidenceByDisease = {
      Healthy: { total: 0, count: 0 },
      Bacterial: { total: 0, count: 0 },
      Fungal: { total: 0, count: 0 },
      Unknown: { total: 0, count: 0 }
    };
    
    analysisHistory.value.forEach(item => {
      const prediction = item.result.prediction;
      const confidence = item.result.confidence;
      
      if (confidenceByDisease[prediction]) {
        confidenceByDisease[prediction].total += confidence;
        confidenceByDisease[prediction].count += 1;
      } else {
        confidenceByDisease.Unknown.total += confidence;
        confidenceByDisease.Unknown.count += 1;
      }
    });
    
    const avgConfidence = Object.keys(confidenceByDisease).map(key => {
      const { total, count } = confidenceByDisease[key];
      return count > 0 ? (total / count) * 100 : 0;
    });
    
    const ctx = avgConfidenceChart.getContext('2d');
    charts.value.avgConfidence = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: Object.keys(confidenceByDisease),
        datasets: [{
          label: 'Average Confidence (%)',
          data: avgConfidence,
          backgroundColor: [
            'rgba(34, 197, 94, 0.7)',
            'rgba(239, 68, 68, 0.7)',
            'rgba(234, 179, 8, 0.7)',
            'rgba(59, 130, 246, 0.7)'
          ],
          borderColor: [
            '#22c55e',
            '#ef4444',
            '#eab308',
            '#3b82f6'
          ],
          borderWidth: 1
        }]
      },
      options: {
        ...commonOptions,
        indexAxis: 'y',
        scales: {
          ...commonOptions.scales,
          x: {
            ...commonOptions.scales.x,
            min: 0,
            max: 100,
            title: {
              display: true,
              text: 'Confidence (%)',
              color: textColor
            }
          }
        }
      }
    });
  }
};

const destroyCharts = () => {
  Object.values(charts.value).forEach(chart => {
    if (chart) {
      chart.destroy();
    }
  });
};

const handleAuth = async () => {
  const auth = getAuth();
  authError.value = null;

  try {
    if (authMode.value === 'login') {
      await signInWithEmailAndPassword(auth, email.value, password.value);
    } else {
      await createUserWithEmailAndPassword(auth, email.value, password.value);
    }
    email.value = '';
    password.value = '';
    showAuthModal.value = false;
    
    // Show success notification
    showNotification.value = true;
    notificationData.value = {
      title: authMode.value === 'login' ? 'Login Successful' : 'Account Created',
      message: authMode.value === 'login' ? 'You have been logged in successfully' : 'Your account has been created successfully',
      type: 'success'
    };
    
    // Auto-hide notification after 3 seconds
    setTimeout(() => {
      showNotification.value = false;
    }, 3000);
  } catch (error) {
    authError.value = error.message;
  }
};

const logout = async () => {
  const auth = getAuth();
  try {
    await signOut(auth);
    
    // Show success notification
    showNotification.value = true;
    notificationData.value = {
      title: 'Logout Successful',
      message: 'You have been logged out successfully',
      type: 'success'
    };
    
    // Auto-hide notification after 3 seconds
    setTimeout(() => {
      showNotification.value = false;
    }, 3000);
  } catch (error) {
    console.error("Error logging out:", error);
  }
};

const loadUserHistory = async () => {
  try {
    if (!user.value) return;
    
    const db = getFirestore();
    const analysisCollection = collection(db, "analysisHistory");
    const querySnapshot = await getDocs(analysisCollection);

    const userHistory = [];
    querySnapshot.forEach((doc) => {
      const data = doc.data();
      if (data.userId === user.value.uid) {
        userHistory.push(data);
      }
    });

    // Sort by date (newest first)
    userHistory.sort((a, b) => new Date(b.date) - new Date(a.date));
    
    // Update the analysis history
    analysisHistory.value = userHistory;
    
    // Save to localStorage for offline access
    localStorage.setItem('analysisHistory', JSON.stringify(analysisHistory.value));
  } catch (error) {
    console.error("Error loading user history from Firestore:", error);
  }
};

const exportToCSV = () => {
  if (analysisHistory.value.length === 0) return;
  
  try {
    const rows = [["Date", "Prediction", "Confidence"]];
    
    analysisHistory.value.forEach(item => {
      rows.push([
        new Date(item.date).toLocaleString(),
        item.result.prediction,
        (item.result.confidence * 100).toFixed(2) + "%"
      ]);
    });
    
    const csvContent = "data:text/csv;charset=utf-8," + rows.map(row => row.join(",")).join("\n");
    const encodedUri = encodeURI(csvContent);
    
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `eco-mist-analysis-history-${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    // Show success notification
    showNotification.value = true;
    notificationData.value = {
      title: 'Export Successful',
      message: 'Analysis history has been exported to CSV',
      type: 'success'
    };
    
    // Auto-hide notification after 3 seconds
    setTimeout(() => {
      showNotification.value = false;
    }, 3000);
  } catch (error) {
    console.error("Error exporting to CSV:", error);
    showNotification.value = true;
    notificationData.value = {
      title: 'Export Failed',
      message: 'Failed to export analysis history to CSV',
      type: 'error'
    };
  }
};

const toggleSidebar = () => {
  sidebarOpen.value = !sidebarOpen.value;
  localStorage.setItem('sidebarOpen', sidebarOpen.value.toString());
  
  if (isMobile.value && sidebarOpen.value) {
    document.body.style.overflow = 'hidden';
  } else {
    document.body.style.overflow = '';
  }
};

const toggleUserMenu = () => {
  userMenuOpen.value = !userMenuOpen.value;
};

const handleClickOutside = (event) => {
  if (userMenuRef.value && !userMenuRef.value.contains(event.target)) {
    userMenuOpen.value = false;
  }
};

const getInitials = (name) => {
  if (!name) return "G";
  return name.split('@')[0].substring(0, 2).toUpperCase();
};

const getFilteredRoutes = (section) => {
  return section.routes;
};

const getIconForRoute = (route) => {
  const iconMap = {
    '/dashboard': 'layout-dashboard',
    '/profile-display': 'user',
    '/model': 'cpu',
  };
  return iconMap[route.path] || 'link';
};

const checkIfMobile = () => {
  isMobile.value = window.innerWidth < 768;
  if (isMobile.value) {
    sidebarOpen.value = false;
  } else {
    // Get saved sidebar state or default to open on desktop
    const savedState = localStorage.getItem('sidebarOpen');
    sidebarOpen.value = savedState !== null ? savedState === 'true' : true;
  }
};

// Watch for changes
watch(activeTab, (newTab) => {
  if (newTab === 'analytics' && analysisHistory.value.length > 0) {
    nextTick(() => {
      initCharts();
    });
  }
});

// Initialize component
onMounted(() => {
  // Check for camera support
  checkCameraSupport();
  
  // Apply theme
  applyTheme();
  
  // Check if mobile on initial load
  checkIfMobile();
  
  // Add resize event listener
  window.addEventListener('resize', debounce(checkIfMobile, 300));
  
  // Add click outside listener for user menu
  document.addEventListener('click', handleClickOutside);
  
  // Initialize Firebase Authentication
  const auth = getAuth();
  onAuthStateChanged(auth, (currentUser) => {
    user.value = currentUser;
    if (currentUser) {
      loadUserHistory();
    }
  });
  
  // Initialize charts if on analytics tab
  if (activeTab.value === 'analytics' && analysisHistory.value.length > 0) {
    nextTick(() => {
      initCharts();
    });
  }
  
  // Cleanup on component unmount
  onBeforeUnmount(() => {
    // Clean up
    stopCamera();
    window.removeEventListener('resize', checkIfMobile);
    document.removeEventListener('click', handleClickOutside);
    destroyCharts();
  });
});
</script>

<style>
/* Base styles */
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');

:root {
  --primary-color: #16a34a;
  --primary-hover: #15803d;
  --primary-light: #dcfce7;
  --danger-color: #ef4444;
  --warning-color: #eab308;
  --info-color: #3b82f6;
  --text-color: #1f2937;
  --text-light: #6b7280;
  --bg-color: #f9fafb;
  --card-bg: #ffffff;
  --border-color: #e5e7eb;
}

.dark-theme {
  --primary-color: #22c55e;
  --primary-hover: #16a34a;
  --primary-light: #064e3b;
  --text-color: #f9fafb;
  --text-light: #9ca3af;
  --bg-color: #0f172a;
  --card-bg: #1e293b;
  --border-color: #334155;
}

body {
  font-family: 'Inter', sans-serif;
  color: var(--text-color);
  background-color: var(--bg-color);
}

/* Status colors */
.healthy {
  --status-color: #22c55e;
  --status-bg: #dcfce7;
}

.bacterial {
  --status-color: #ef4444;
  --status-bg: #fee2e2;
}

.fungal {
  --status-color: #eab308;
  --status-bg: #fef3c7;
}

.unknown {
  --status-color: #3b82f6;
  --status-bg: #dbeafe;
}

/* Animations */
@keyframes fadeIn {
  from { opacity: 0; transform: translateY(-10px); }
  to { opacity: 1; transform: translateY(0); }
}

.animate-fade-in {
  animation: fadeIn 0.3s ease-out;
}

@keyframes spin {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

.animate-spin {
  animation: spin 1s linear infinite;
}

/* Responsive adjustments */
@media (max-width: 767px) {
  .main-content {
    padding: 1rem;
  }
}

/* Accessibility improvements */
@media (prefers-reduced-motion: reduce) {
  *,
  *::before,
  *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
    scroll-behavior: auto !important;
  }
}
</style>