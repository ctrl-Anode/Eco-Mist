<template>
  <div class="min-h-screen bg-gray-50 flex flex-col">
    <!-- Top Navigation Bar -->
    <header class="bg-gradient-to-r from-emerald-700 to-green-600 shadow-lg z-10">
      <div class="container mx-auto px-4 py-3">
        <div class="flex items-center justify-between">
          <!-- Logo and Mobile Menu Button -->
          <div class="flex items-center">
            <button @click="toggleSidebar" class="mr-3 md:hidden text-white">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
            <div class="flex items-center">
              <img src="/eco-mist-logo.png" alt="Eco-Mist Logo" class="h-7 w-7 mr-3 rounded-lg shadow-md bg-white p-1.5">
              <div>
                <h1 class="text-xl font-bold text-white">Eco-Mist</h1>
                <p class="text-green-100 text-xs hidden sm:block">User Dashboard</p>
              </div>
            </div>
          </div>

          <!-- User Profile -->
          <div class="flex items-center space-x-3">
            <!-- Feedback Button -->
           <button @click="openFeedbackModal" class="text-white p-2 rounded-full hover:bg-white hover:bg-opacity-10 focus:outline-none hidden md:flex items-center">
    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 8h10M7 12h4m1 8l-4-4H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4z" />
    </svg>
  </button>
            <!-- Notification Bell -->
            <div class="relative">
              <button class="text-white p-1 rounded-full hover:bg-white hover:bg-opacity-10 focus:outline-none">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                </svg>
                <span v-if="notificationCount > 0" class="absolute top-0 right-0 bg-red-500 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
                  {{ notificationCount }}
                </span>
              </button>
            </div>

            <!-- User Profile Dropdown -->
            <div class="relative" ref="userMenuRef">
              <button @click="toggleUserMenu" class="flex items-center space-x-2 focus:outline-none">
                <div class="bg-white text-emerald-700 h-8 w-8 rounded-full flex items-center justify-center font-bold text-sm shadow">
                  {{ getInitials(username) }}
                </div>
                <span class="text-white hidden md:block">{{ username }}</span>
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-white hidden md:block" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="m6 9 6 6 6-6"></path>
                </svg>
              </button>

              <!-- User Menu Dropdown -->
              <div v-if="userMenuOpen" class="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-20">
                <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Profile</a>
                <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Settings</a>
                <a @click="confirmLogout" href="#" class="block px-4 py-2 text-sm text-red-600 hover:bg-gray-100">Logout</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>

    <!-- Main Content Area with Sidebar -->
    <div class="flex flex-1 overflow-hidden">
      <!-- Sidebar Navigation -->
      <aside :class="[
        'bg-white shadow-lg z-20 transition-all duration-300 ease-in-out',
        sidebarOpen ? 'translate-x-0' : '-translate-x-full',
        'md:translate-x-0 fixed md:relative inset-y-0 left-0 w-64 overflow-y-auto'
      ]">
        <!-- Sidebar Header -->
        <div class="p-4 border-b">
          <div class="flex items-center justify-between">
            <h2 class="text-lg font-semibold text-gray-800">Navigation</h2>
            <button @click="toggleSidebar" class="md:hidden text-gray-500 hover:text-gray-700">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>

        <!-- Navigation Sections -->
        <nav class="p-4">
          <div v-for="(section, sectionIndex) in navigationSections" :key="sectionIndex" class="mb-6">
            <h3 class="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">{{ section.title }}</h3>
            <ul class="space-y-1">
              <li v-for="(route, routeIndex) in getFilteredRoutes(section)" :key="routeIndex">
                <a 
                  :href="route.path" 
                  :class="[
                    'flex items-center px-3 py-2 text-sm rounded-md',
                    currentRoute === route.path 
                      ? 'bg-emerald-100 text-emerald-700 font-medium' 
                      : 'text-gray-700 hover:bg-gray-100'
                  ]"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" :class="currentRoute === route.path ? 'text-emerald-600' : 'text-gray-500'" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path v-if="getIconForRoute(route) === 'layout-dashboard'" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM4 13a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6zM16 13a1 1 0 011-1h2a1 1 0 011 1v6a1 1 0 01-1 1h-2a1 1 0 01-1-1v-6z" />
                    <path v-else-if="getIconForRoute(route) === 'user'" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    <path v-else-if="getIconForRoute(route) === 'user-cog'" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5.121 17.804A13.937 13.937 0 0112 16c2.5 0 4.847.655 6.879 1.804M15 10a3 3 0 11-6 0 3 3 0 016 0zm6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    <path v-else-if="getIconForRoute(route) === 'cpu'" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z" />
                    <path v-else-if="getIconForRoute(route) === 'bar-chart'" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                    <path v-else-if="getIconForRoute(route) === 'message-circle'" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                    <path v-else-if="getIconForRoute(route) === 'microscope'" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                    <path v-else stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
                  </svg>
                  {{ route.name }}
                </a>
              </li>
            </ul>
          </div>
        </nav>

        <!-- System Info -->
        <div class="p-4 border-t">
          <div class="bg-gray-50 rounded-lg p-3">
            <div class="flex items-center justify-between mb-2">
              <span class="text-xs font-medium text-gray-500">System Status</span>
              <span class="bg-green-100 text-green-800 text-xs px-2 py-0.5 rounded-full">
                Online
              </span>
            </div>
            <div class="text-xs text-gray-500 flex flex-col space-y-1">
              <div class="flex justify-between">
                <span>Last Login:</span>
                <span class="font-medium text-gray-700">{{ formatDate(lastLogin) }}</span>
              </div>
              <div class="flex justify-between">
                <span>Account Type:</span>
                <span class="font-medium text-gray-700">{{ role }}</span>
              </div>
            </div>
          </div>
        </div>
      </aside>

      <!-- Main Content -->
      <main class="flex-1 overflow-y-auto bg-gray-50 p-4 md:p-6">
        <!-- Page Header -->
        <div class="mb-6">
          <h1 class="text-2xl font-bold text-gray-800">Dashboard Overview</h1>
          <p class="text-gray-600">Welcome back, {{ username }}! Here's your system overview.</p>
        </div>

        <!-- Overview Cards -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <div 
            v-for="(feature, index) in features" 
            :key="index" 
            class="bg-white rounded-lg shadow-sm p-4 border-l-4"
            :class="feature.color"
          >
            <div class="flex justify-between items-start">
              <div>
                <p class="text-sm font-medium text-gray-500">{{ feature.name }}</p>
                <h3 class="text-xl font-bold text-gray-800 mt-1">{{ feature.value }}</h3>
                <p class="text-gray-600 text-xs mt-1">{{ feature.description }}</p>
              </div>
              <div class="p-2 rounded-lg" :class="feature.bgColor">
                <svg :class="feature.iconClass" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" :d="feature.iconPath" />
                </svg>
              </div>
            </div>
          </div>
        </div>

        <!-- Main Content Tabs -->
        <div class="bg-white rounded-lg shadow-sm mb-6">
          <div class="border-b">
            <nav class="flex -mb-px">
              <button 
                v-for="tab in dashboardTabs" 
                :key="tab.id"
                @click="currentDashboardTab = tab.id" 
                :class="[
                  'py-4 px-6 font-medium text-sm border-b-2 focus:outline-none',
                  currentDashboardTab === tab.id 
                    ? 'border-emerald-500 text-emerald-600' 
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                ]"
              >
                {{ tab.name }}
              </button>
            </nav>
          </div>

          <!-- Tab Content -->
          <div class="p-6">
            <!-- Quick Access Tab -->
            <div v-if="currentDashboardTab === 'quick-access'">
              <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div 
                  v-for="(functionality, index) in functionalities" 
                  :key="index" 
                  class="bg-gray-100 rounded-lg p-4 flex items-center space-x-4 hover:bg-gray-200 cursor-pointer transition-colors relative"
                  @click="navigateTo(functionality.route)"
                >
                  <div class="p-3 rounded-lg" :class="functionality.bgColor">
                    <svg :class="functionality.iconClass" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" :d="functionality.iconPath" />
                    </svg>
                  </div>
                  <div>
                    <h3 class="text-lg font-medium text-gray-800">{{ functionality.name }}</h3>
                    <p class="text-sm text-gray-600">{{ functionality.description }}</p>
                  </div>
                  
                  <!-- Loading Spinner (shown when loading) -->
                  <div v-if="functionality.loading" class="absolute inset-0 flex items-center justify-center bg-white bg-opacity-80 rounded-lg">
                    <div class="spinner">
                      <div></div>
                      <div></div>
                      <div></div>
                      <div></div>
                      <div></div>
                      <div></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Recent Activity Tab -->
            <div v-if="currentDashboardTab === 'recent-activity'">
              <div class="space-y-4">
                <div v-if="recentActivities.length === 0" class="text-center py-8 text-gray-500">
                  No recent activities to display
                </div>
                <div 
                  v-for="(activity, index) in recentActivities" 
                  :key="index" 
                  class="bg-gray-50 rounded-lg p-4 flex items-start space-x-4"
                >
                  <div :class="[
                    'p-2 rounded-full',
                    activity.type === 'login' ? 'bg-blue-100 text-blue-600' :
                    activity.type === 'data' ? 'bg-green-100 text-green-600' :
                    activity.type === 'system' ? 'bg-purple-100 text-purple-600' :
                    'bg-gray-100 text-gray-600'
                  ]">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path 
                        stroke-linecap="round" 
                        stroke-linejoin="round" 
                        stroke-width="2" 
                        :d="activity.type === 'login' ? 'M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1' :
                            activity.type === 'data' ? 'M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z' :
                            activity.type === 'system' ? 'M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z' :
                            'M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z'"
                      />
                    </svg>
                  </div>
                  <div class="flex-1">
                    <div class="flex justify-between">
                      <p class="font-medium text-gray-800">{{ activity.title }}</p>
                      <span class="text-xs text-gray-500">{{ formatDate(activity.timestamp) }}</span>
                    </div>
                    <p class="text-sm text-gray-600 mt-1">{{ activity.description }}</p>
                  </div>
                </div>
              </div>
            </div>

            <!-- System Status Tab -->
            <div v-if="currentDashboardTab === 'system-status'">
              <div class="space-y-6">
                <!-- System Health -->
                <div>
                  <h3 class="text-lg font-medium text-gray-800 mb-4">System Health</h3>
                  <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div v-for="(metric, index) in systemMetrics" :key="index" class="bg-gray-50 rounded-lg p-4">
                      <div class="flex justify-between items-center mb-2">
                        <span class="text-sm font-medium text-gray-700">{{ metric.name }}</span>
                        <span :class="[
                          'text-xs px-2 py-0.5 rounded-full',
                          metric.status === 'good' ? 'bg-green-100 text-green-800' :
                          metric.status === 'warning' ? 'bg-yellow-100 text-yellow-800' :
                          'bg-red-100 text-red-800'
                        ]">
                          {{ metric.statusText }}
                        </span>
                      </div>
                      <div class="w-full bg-gray-200 rounded-full h-2.5">
                        <div 
                          class="h-2.5 rounded-full" 
                          :class="[
                            metric.status === 'good' ? 'bg-green-600' :
                            metric.status === 'warning' ? 'bg-yellow-500' : 'bg-red-600'
                          ]"
                          :style="{ width: `${metric.value}%` }"
                        ></div>
                      </div>
                      <p class="text-xs text-gray-500 mt-2">{{ metric.description }}</p>
                    </div>
                  </div>
                </div>

                <!-- Upcoming Maintenance -->
                <div>
                  <h3 class="text-lg font-medium text-gray-800 mb-4">Upcoming Maintenance</h3>
                  <div class="bg-gray-50 rounded-lg p-4">
                    <div v-if="maintenanceEvents.length === 0" class="text-center py-4 text-gray-500">
                      No scheduled maintenance events
                    </div>
                    <div v-else class="space-y-4">
                      <div v-for="(event, index) in maintenanceEvents" :key="index" class="flex items-start space-x-4">
                        <div class="bg-blue-100 text-blue-600 p-2 rounded-full">
                          <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                          </svg>
                        </div>
                        <div class="flex-1">
                          <div class="flex justify-between">
                            <p class="font-medium text-gray-800">{{ event.title }}</p>
                            <span class="text-xs text-gray-500">{{ formatDate(event.date) }}</span>
                          </div>
                          <p class="text-sm text-gray-600 mt-1">{{ event.description }}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Quick Links -->
        <div class="bg-white rounded-lg shadow-sm p-6">
          <h2 class="text-xl font-bold text-gray-800 mb-4">Quick Links</h2>
          <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            <a 
              v-for="(link, index) in quickLinks" 
              :key="index" 
              href="#"
              @click.prevent="handleQuickLink(link)"
              class="flex flex-col items-center justify-center p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors relative"
            >
              <div :class="[link.iconBg, 'p-3 rounded-full mb-2']">
                <svg :class="link.iconColor" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" :d="link.iconPath" />
                </svg>
              </div>
              <span class="text-sm font-medium text-gray-700 text-center">{{ link.name }}</span>
              
              <!-- Loading Spinner (shown when loading) -->
              <div v-if="link.loading" class="absolute inset-0 flex items-center justify-center bg-white bg-opacity-80 rounded-lg">
                <div class="spinner">
                  <div></div>
                  <div></div>
                  <div></div>
                  <div></div>
                  <div></div>
                  <div></div>
                </div>
              </div>
            </a>
          </div>
        </div>
      </main>
    </div>

    <!-- Feedback Modal with Blurred Background -->
    <div v-if="showFeedbackModal" class="fixed inset-0 z-50 flex items-center justify-center">
      <!-- Blurred backdrop -->
      <div class="absolute inset-0 backdrop-blur-sm" @click="closeFeedbackModal"></div>
      
      <!-- Modal content -->
      <div class="bg-white rounded-lg p-6 max-w-md mx-auto w-full relative z-10 shadow-xl">
        <h3 class="text-lg font-medium text-gray-900 mb-4">Give Feedback</h3>
        <p class="text-gray-500 mb-4">We value your feedback! Please let us know how we can improve your experience.</p>
        <div class="space-y-4">
          <div>
            <label for="feedback-type" class="block text-sm font-medium text-gray-700 mb-1">Feedback Type</label>
            <select 
              id="feedback-type" 
              v-model="feedbackType"
              class="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm"
            >
              <option value="suggestion">Suggestion</option>
              <option value="bug">Bug Report</option>
              <option value="question">Question</option>
              <option value="other">Other</option>
            </select>
          </div>
          <div>
            <label for="feedback-message" class="block text-sm font-medium text-gray-700 mb-1">Your Feedback</label>
            <textarea 
              id="feedback-message" 
              v-model="feedbackMessage" 
              rows="4"
              class="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm"
              placeholder="Please describe your feedback in detail..."
            ></textarea>
          </div>
        </div>
        <div class="flex justify-end gap-2 mt-6">
          <button @click="closeFeedbackModal" class="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300">
            Cancel
          </button>
          <button 
            @click="submitFeedback" 
            class="px-4 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700 relative"
            :disabled="submittingFeedback"
          >
            <span v-if="!submittingFeedback">Submit Feedback</span>
            <div v-else class="flex items-center justify-center">
              <div class="spinner spinner-sm">
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
              </div>
              <span class="ml-2">Submitting...</span>
            </div>
          </button>
        </div>

        <!-- Feedback Notifications Section -->
        <div class="feedback-notifications mt-6">
          <h2 class="text-lg font-bold text-gray-800">Feedback Notifications</h2>
          <p class="text-gray-600 mb-4">View responses and updates from the admin regarding your feedback.</p>
          <div v-if="loadingNotifications" class="text-gray-600">Loading notifications...</div>
          <div v-else-if="notifications.length === 0" class="text-gray-500">No notifications available.</div>
          <div v-else class="space-y-4">
            <div v-for="notification in notifications" :key="notification.id" class="p-4 border border-gray-200 rounded-lg">
              <div class="flex justify-between items-center mb-2">
                <h3 class="text-gray-800 font-medium">{{ notification.title }}</h3>
                <span class="text-sm text-gray-500">{{ formatDate(notification.timestamp) }}</span>
              </div>
              <p class="text-gray-600">{{ notification.message }}</p>
              <div v-if="notification.reply" class="mt-2 p-3 bg-green-50 border border-green-200 rounded-lg">
                <h4 class="text-sm font-medium text-green-700">Admin Reply:</h4>
                <p class="text-gray-700">{{ notification.reply }}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <!-- Logout Confirmation Modal -->
    <div v-if="showLogoutModal" class="fixed inset-0 z-50 flex items-center justify-center">
      <!-- Blurred backdrop -->
      <div class="absolute inset-0 backdrop-blur-sm" @click="showLogoutModal = false"></div>
      
      <!-- Modal content -->
      <div class="bg-white rounded-lg p-6 max-w-sm mx-auto relative z-10 shadow-xl">
        <h3 class="text-lg font-medium text-gray-900 mb-4">Confirm Logout</h3>
        <p class="text-gray-500 mb-4">Are you sure you want to log out of your account?</p>
        <div class="flex justify-end gap-2">
          <button @click="showLogoutModal = false" class="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300">
            Cancel
          </button>
          <button 
            @click="logout" 
            class="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 relative"
            :disabled="loggingOut"
          >
            <span v-if="!loggingOut">Logout</span>
            <div v-else class="flex items-center justify-center">
              <div class="spinner spinner-sm">
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
              </div>
              <span class="ml-2">Logging out...</span>
            </div>
          </button>
        </div>
      </div>
    </div>

    <!-- Toast Notification -->
    <div 
      v-if="toast.show" 
      class="fixed bottom-4 right-4 px-4 py-3 rounded-lg shadow-lg z-50 flex items-center"
      :class="{
        'bg-green-100 text-green-800 border-l-4 border-green-500': toast.type === 'success',
        'bg-red-100 text-red-800 border-l-4 border-red-500': toast.type === 'error'
      }"
    >
      <svg 
        v-if="toast.type === 'success'" 
        class="h-5 w-5 mr-2" 
        xmlns="http://www.w3.org/2000/svg" 
        viewBox="0 0 20 20" 
        fill="currentColor"
      >
        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
      </svg>
      <svg 
        v-if="toast.type === 'error'" 
        class="h-5 w-5 mr-2" 
        xmlns="http://www.w3.org/2000/svg" 
        viewBox="0 0 20 20" 
        fill="currentColor"
      >
        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd" />
      </svg>
      <span>{{ toast.message }}</span>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, watch, onMounted, onBeforeUnmount } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { getAuth, signOut, onAuthStateChanged } from "firebase/auth";
import { getFirestore, addDoc } from "firebase/firestore"; 
import { collection, query, where, orderBy, onSnapshot } from 'firebase/firestore';

// Router
const router = useRouter();
const route = useRoute();
const currentRoute = computed(() => route.path);

// State variables
const username = ref("John Doe");
const role = ref("user");
const lastLogin = ref(new Date());
const sidebarOpen = ref(true);
const userMenuOpen = ref(false);
const notificationCount = ref(2);
const isMobile = ref(false);
const userMenuRef = ref(null);
const showLogoutModal = ref(false);
const showFeedbackModal = ref(false);
const feedbackType = ref('suggestion');
const feedbackMessage = ref('');
const currentDashboardTab = ref('quick-access');
const toast = ref({ show: false, message: '', type: 'success' });
const submittingFeedback = ref(false);
const loggingOut = ref(false);
const notifications = ref([]);
const loadingNotifications = ref(true);

// Dashboard tabs
const dashboardTabs = [
  { id: 'quick-access', name: 'Quick Access' },
  { id: 'recent-activity', name: 'Recent Activity' },
  { id: 'system-status', name: 'System Status' }
];

// Feature cards
const features = [
  { 
    name: "Sensor Readings", 
    value: "24", 
    description: "Active sensors monitoring your system", 
    color: "border-blue-500", 
    bgColor: "bg-blue-100", 
    iconClass: "text-blue-600", 
    iconPath: "M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z" 
  },
  { 
    name: "System Health", 
    value: "98%", 
    description: "Overall system performance", 
    color: "border-green-500", 
    bgColor: "bg-green-100", 
    iconClass: "text-green-600", 
    iconPath: "M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" 
  },
  { 
    name: "Crop Analysis", 
    value: "3", 
    description: "Pending crop analyses", 
    color: "border-purple-500", 
    bgColor: "bg-purple-100", 
    iconClass: "text-purple-600", 
    iconPath: "M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" 
  },
  { 
    name: "Alerts", 
    value: "0", 
    description: "No active alerts in your system", 
    color: "border-yellow-500", 
    bgColor: "bg-yellow-100", 
    iconClass: "text-yellow-600", 
    iconPath: "M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" 
  }
];

// System functionalities with loading state
const functionalities = ref([
  { 
    name: "Financial Management", 
    description: "Manage your finances effectively", 
    route: "/financial-management", 
    bgColor: "bg-green-100", 
    iconClass: "text-green-600", 
    iconPath: "M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-5 0a4 4 0 11-8 0 4 4 0 018 0z",
    loading: false
  },
  { 
    name: "Sensor Data", 
    description: "View and analyze sensor data", 
    route: "/sensor_data", 
    bgColor: "bg-blue-100", 
    iconClass: "text-blue-600", 
    iconPath: "M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z",
    loading: false
  },
  { 
    name: "Crop Disease Detector", 
    description: "Detect crop diseases using AI", 
    route: "/model", 
    bgColor: "bg-purple-100", 
    iconClass: "text-purple-600", 
    iconPath: "M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z",
    loading: false
  },
  { 
    name: "User Profile", 
    description: "View and edit your profile", 
    route: "/profile-display", 
    bgColor: "bg-indigo-100", 
    iconClass: "text-indigo-600", 
    iconPath: "M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z",
    loading: false
  },
  { 
    name: "Messenger", 
    description: "Chat with support and team", 
    route: "/messenger", 
    bgColor: "bg-pink-100", 
    iconClass: "text-pink-600", 
    iconPath: "M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z",
    loading: false
  },
  { 
    name: "Settings", 
    description: "Configure system settings", 
    route: "/settings", 
    bgColor: "bg-gray-100", 
    iconClass: "text-gray-600", 
    iconPath: "M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z",
    loading: false
  }
]);

// Recent activities
const recentActivities = ref([
  {
    type: 'login',
    title: 'System Login',
    description: 'You logged in to the system',
    timestamp: new Date(Date.now() - 1000 * 60 * 30) // 30 minutes ago
  },
  {
    type: 'data',
    title: 'Sensor Data Updated',
    description: 'Sensor data was successfully updated',
    timestamp: new Date(Date.now() - 1000 * 60 * 120) // 2 hours ago
  },
  {
    type: 'system',
    title: 'System Update',
    description: 'System was updated to version 2.4.1',
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24) // 1 day ago
  }
]);

// System metrics
const systemMetrics = ref([
  {
    name: 'CPU Usage',
    value: 32,
    status: 'good',
    statusText: 'Normal',
    description: 'Current CPU usage is within normal range'
  },
  {
    name: 'Memory Usage',
    value: 68,
    status: 'warning',
    statusText: 'Moderate',
    description: 'Memory usage is higher than usual'
  },
  {
    name: 'Disk Space',
    value: 45,
    status: 'good',
    statusText: 'Normal',
    description: 'Plenty of disk space available'
  },
  {
    name: 'Network',
    value: 92,
    status: 'good',
    statusText: 'Excellent',
    description: 'Network connectivity is excellent'
  }
]);

// Maintenance events
const maintenanceEvents = ref([
  {
    title: 'System Update',
    description: 'Scheduled system update for performance improvements',
    date: new Date(Date.now() + 1000 * 60 * 60 * 24 * 3) // 3 days from now
  },
  {
    title: 'Database Maintenance',
    description: 'Routine database optimization and cleanup',
    date: new Date(Date.now() + 1000 * 60 * 60 * 24 * 7) // 7 days from now
  }
]);

// Quick links with loading state
const quickLinks = ref([
  {
    name: 'Documentation',
    url: '#',
    iconBg: 'bg-blue-100',
    iconColor: 'text-blue-600',
    iconPath: 'M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253',
    loading: false
  },
  {
    name: 'Support',
    url: '#',
    iconBg: 'bg-green-100',
    iconColor: 'text-green-600',
    iconPath: 'M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192l-3.536 3.536M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-5 0a4 4 0 11-8 0 4 4 0 018 0z',
    loading: false
  },
  {
    name: 'Reports',
    url: '#',
    iconBg: 'bg-purple-100',
    iconColor: 'text-purple-600',
    iconPath: 'M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z',
    loading: false
  },
  {
    name: 'Analytics',
    url: '#',
    iconBg: 'bg-yellow-100',
    iconColor: 'text-yellow-600',
    iconPath: 'M16 8v8m-4-5v5m-4-2v2m-2 4h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z',
    loading: false
  },
  {
    name: 'Settings',
    url: '#',
    iconBg: 'bg-gray-100',
    iconColor: 'text-gray-600',
    iconPath: 'M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z',
    loading: false
  },
  {
    name: 'Help',
    url: '#',
    iconBg: 'bg-pink-100',
    iconColor: 'text-pink-600',
    iconPath: 'M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-5 0a4 4 0 11-8 0 4 4 0 018 0z',
    loading: false
  }
]);

// Navigation sections
const navigationSections = computed(() => {
  return [
    {
      title: 'GENERAL',
      routes: routes.filter(r => 
        r.path === '/dashboard' || 
        r.path === '/profile-display' ||
        r.path === '/messenger'
      )
    },
    {
      title: 'USER MANAGEMENT',
      routes: routes.filter(r => 
        r.path === '/edit-profile' || 
        r.path === '/reset-password'
      )
    },
    {
      title: 'DATA & TOOLS',
      routes: routes.filter(r => 
        r.path === '/financial-management' || 
        r.path === '/sensor_data' || 
        r.path === '/model'
      )
    },
    {
      title: 'ADMIN CONTROLS',
      routes: routes.filter(r => 
        r.path === '/admin-dashboard' || 
        r.path === '/admin-management'
      )
    }
  ];
});

// Routes configuration
const routes = [
  { path: '/auth', name: 'Login', component: 'UserAuth' },
  { path: '/edit-profile', name: 'Edit Profile', component: 'EditUserProfile', meta: { requiresAuth: true, role: 'user' } },
  { path: '/dashboard', name: 'Dashboard', component: 'UserDashboard', meta: { requiresAuth: true } },
  { path: '/profile-display', name: 'Profile', component: 'UserProfileDisplay', meta: { requiresAuth: true, role: 'user' } },
  { path: '/admin-dashboard', name: 'Admin Dashboard', component: 'AdminDashboard', meta: { requiresAuth: true, role: 'admin' } },
  { path: '/reset-password', name: 'Reset Password', component: 'ResetPassword' },
  { path: "/admin-management", name: "Admin Management", component: 'AdminManagement', meta: { requiresAuth: true, role: "admin" } },
  { path: '/financial-management', name: 'Financial Management', component: 'FinancialManagement', meta: { requiresAuth: true, role: 'user' } },
  { path: '/messenger', name: 'Messenger', component: 'MessengerChat', meta: { requiresAuth: true } },
  { path: '/sensor_data', name: 'Sensor Data', component: 'SensorData', meta: { requiresAuth: true, role: 'user' } },
  { path: '/model', name: 'Crop Disease Detector', component: 'CropDiseaseDetector', meta: { requiresAuth: true, role: 'user' } },
  { path: '/settings', name: 'Settings', component: 'Settings', meta: { requiresAuth: true } },
];

// Firestore setup
const db = getFirestore();

// Methods
const getInitials = (name) => {
  if (!name) return "U";
  return name.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2);
};

// const formatDate = (date) => {
//   if (!date) return '';
  
//   const now = new Date();
//   const diff = now - new Date(date);
  
//   // Less than a minute
//   if (diff < 60000) {
//     return 'Just now';
//   }
  
//   // Less than an hour
//   if (diff < 3600000) {
//     return `${Math.floor(diff / 60000)}m ago`;
//   }
  
//   // Less than a day
//   if (diff < 86400000) {
//     return `${Math.floor(diff / 3600000)}h ago`;
//   }
  
//   // Less than a week
//   if (diff < 604800000) {
//     return `${Math.floor(diff / 86400000)}d ago`;
//   }
  
//   // Format as date
//   return new Date(date).toLocaleDateString('en-US', {
//     year: 'numeric',
//     month: 'short',
//     day: 'numeric'
//   });
// };

const toggleUserMenu = () => {
  userMenuOpen.value = !userMenuOpen.value;
};

const handleClickOutside = (event) => {
  if (userMenuRef.value && !userMenuRef.value.contains(event.target)) {
    userMenuOpen.value = false;
  }
};

const checkIfMobile = () => {
  isMobile.value = window.innerWidth < 768;
  if (isMobile.value) {
    sidebarOpen.value = false;
  } else {
    // Get saved sidebar state or default to open on desktop
    const savedState = localStorage.getItem('sidebarOpen');
    sidebarOpen.value = savedState !== null ? savedState === 'true' : true;
  }
};

const toggleSidebar = () => {
  sidebarOpen.value = !sidebarOpen.value;
  localStorage.setItem('sidebarOpen', sidebarOpen.value.toString());
  
  if (isMobile.value && sidebarOpen.value) {
    document.body.style.overflow = 'hidden';
  } else {
    document.body.style.overflow = '';
  }
};

const getFilteredRoutes = (section) => {
  return section.routes.filter(route => shouldShowRoute(route));
};

const shouldShowRoute = (route) => {
  if (route.path === '/auth') {
    return false;
  }
  
  if (route.meta?.requiresAuth) {
    if (route.meta.role && route.meta.role !== role.value) {
      return false;
    }
  }
  
  return true;
};

const getIconForRoute = (route) => {
  const iconMap = {
    '/': 'home',
    '/dashboard': 'layout-dashboard',
    '/profile-display': 'user',
    '/edit-profile': 'user-cog',
    '/reset-password': 'key',
    '/admin-dashboard': 'shield',
    '/admin-management': 'users',
    '/financial-management': 'bar-chart',
    '/messenger': 'message-circle',
    '/sensor_data': 'cpu',
    '/model': 'microscope',
    '/settings': 'settings'
  };
  
  return iconMap[route.path] || 'link';
};

const confirmLogout = () => {
  showLogoutModal.value = true;
};

const logout = async () => {
  loggingOut.value = true;
  try {
    const auth = getAuth();
    await signOut(auth);
    
    // Simulate a delay to show the spinner
    setTimeout(() => {
      router.push('/auth');
      loggingOut.value = false;
    }, 1000);
  } catch (error) {
    console.error("Error logging out:", error);
    loggingOut.value = false;
  }
};

const navigateTo = (route) => {
  // Find the functionality and set its loading state
  const functionality = functionalities.value.find(f => f.route === route);
  if (functionality) {
    functionality.loading = true;
    
    // Simulate a delay to show the spinner
    setTimeout(() => {
      router.push(route);
      functionality.loading = false;
    }, 1000);
  } else {
    router.push(route);
  }
};

const handleQuickLink = (link) => {
  // Set the loading state for this link
  link.loading = true;
  
  // Simulate a delay to show the spinner
  setTimeout(() => {
    // Here you would typically navigate to the link or perform an action
    console.log(`Clicked on ${link.name}`);
    showToast(`${link.name} link clicked`, 'success');
    link.loading = false;
  }, 1500);
};

const showToast = (message, type = 'success') => {
  toast.value = { show: true, message, type };
  setTimeout(() => {
    toast.value.show = false;
  }, 3000);
};

const openFeedbackModal = () => {
  showFeedbackModal.value = true;
};

const closeFeedbackModal = () => {
  showFeedbackModal.value = false;
  feedbackMessage.value = '';
  feedbackType.value = 'suggestion';
};

const submitFeedback = async () => {
  if (!feedbackMessage.value.trim()) {
    showToast('Please enter your feedback message', 'error');
    return;
  }

  submittingFeedback.value = true;

  try {
    // Save feedback to Firestore
    await addDoc(collection(db, "feedback"), {
      type: feedbackType.value,
      message: feedbackMessage.value,
      username: username.value,
      timestamp: new Date()
    });

    showToast('Thank you for your feedback!', 'success');
    closeFeedbackModal();
  } catch (error) {
    console.error("Error submitting feedback:", error);
    showToast('Failed to submit feedback. Please try again.', 'error');
  } finally {
    submittingFeedback.value = false;
  }
};

// Fetch notifications for the user
const fetchNotifications = () => {
  loadingNotifications.value = true;
  const userId = "currentUserId"; // Replace with actual user ID logic
  const notificationsQuery = query(
    collection(db, 'feedback_notifications'),
    where('userId', '==', userId),
    orderBy('timestamp', 'desc')
  );

  onSnapshot(notificationsQuery, (snapshot) => {
    notifications.value = snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    }));
    loadingNotifications.value = false;
  }, (error) => {
    console.error("Error fetching notifications:", error);
    loadingNotifications.value = false;
  });
};

// Format date utility
const formatDate = (timestamp) => {
  if (!timestamp) return 'Unknown';
  const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
  return new Intl.DateTimeFormat('en-US', {
    dateStyle: 'medium',
    timeStyle: 'short'
  }).format(date);
};

// Initialize component
onMounted(() => {
  // Check if mobile on initial load
  checkIfMobile();
  
  // Add resize event listener
  window.addEventListener('resize', handleResize);
  
  // Add click outside listener for user menu
  document.addEventListener('click', handleClickOutside);
  
  // Fetch the logged-in user's name
  const auth = getAuth();
  onAuthStateChanged(auth, (user) => {
    if (user) {
      username.value = user.displayName || "User";
      // Set last login time
      lastLogin.value = new Date();
    } else {
      username.value = "Guest";
    }
  });

  fetchNotifications();
});

// Handle window resize
const handleResize = () => {
  checkIfMobile();
};

// Watch for route changes to close sidebar on mobile
watch(currentRoute, () => {
  if (isMobile.value) {
    sidebarOpen.value = false;
    document.body.style.overflow = '';
  }
  // Close user menu when route changes
  userMenuOpen.value = false;
});
</script>

<style scoped>
/* Custom styles for the user dashboard */
.bg-pattern {
  background-image: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.2'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
}

/* Focus styles for accessibility */
button:focus-visible,
a:focus-visible {
  outline: 2px solid #10b981;
  outline-offset: 2px;
}

/* 3D Cube Spinner */
.spinner {
  width: 44px;
  height: 44px;
  animation: spinner-y0fdc1 2s infinite ease;
  transform-style: preserve-3d;
}

.spinner > div {
  background-color: rgba(16, 185, 129, 0.2);
  height: 100%;
  position: absolute;
  width: 100%;
  border: 2px solid #10b981;
}

.spinner div:nth-of-type(1) {
  transform: translateZ(-22px) rotateY(180deg);
}

.spinner div:nth-of-type(2) {
  transform: rotateY(-270deg) translateX(50%);
  transform-origin: top right;
}

.spinner div:nth-of-type(3) {
  transform: rotateY(270deg) translateX(-50%);
  transform-origin: center left;
}

.spinner div:nth-of-type(4) {
  transform: rotateX(90deg) translateY(-50%);
  transform-origin: top center;
}

.spinner div:nth-of-type(5) {
  transform: rotateX(-90deg) translateY(50%);
  transform-origin: bottom center;
}

.spinner div:nth-of-type(6) {
  transform: translateZ(22px);
}

/* Smaller spinner for buttons */
.spinner-sm {
  width: 24px;
  height: 24px;
}

@keyframes spinner-y0fdc1 {
  0% {
    transform: rotate(45deg) rotateX(-25deg) rotateY(25deg);
  }

  50% {
    transform: rotate(45deg) rotateX(-385deg) rotateY(25deg);
  }

  100% {
    transform: rotate(45deg) rotateX(-385deg) rotateY(385deg);
  }
}
</style>