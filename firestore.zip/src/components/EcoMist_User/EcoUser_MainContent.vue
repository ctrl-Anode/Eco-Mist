<template>
  <main class="flex-1 overflow-y-auto bg-gray-50 p-4 md:p-6">
    <slot />
  </main>
</template>

<script setup>
// This is a simple layout component that just provides a slot for main content.
// No props or events needed.
</script>

<style scoped>
/* No additional styles needed as Tailwind CSS handles the layout */
</style>
