<template>
  <svg xmlns="http://www.w3.org/2000/svg" class="w-8 h-8 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
    <path d="M12 10V5a3 3 0 1 1 3 3H5a3 3 0 0 1 3-3v5"/>
    <path d="M12 14a3 3 0 1 0 3 3"/>
    <path d="M12 14a3 3 0 1 1-3 3"/>
    <path d="M7 21h10"/>
  </svg>
</template>

<script setup></script>
